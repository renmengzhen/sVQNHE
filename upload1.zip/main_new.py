#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 15 06:39:15 2025
main
@author: Mengzhen
"""
import numpy as np
import pandas as pd
import math
import cmath
import tensorcircuit as tc
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
from qiskit_nature.drivers import UnitsType, Molecule
from qiskit_nature.drivers.second_quantization import (
    ElectronicStructureDriverType,
    ElectronicStructureMoleculeDriver,
)
from qiskit_nature.problems.second_quantization import ElectronicStructureProblem
from qiskit_nature.converters.second_quantization import QubitConverter
from qiskit_nature.mappers.second_quantization import JordanWignerMapper
from qiskit_nature.transformers.second_quantization.electronic import FreezeCoreTransformer, ActiveSpaceTransformer
# from qiskit.aqua.operators import WeightedPauliOperator
from qiskit.quantum_info import Pauli, state_fidelity, SparsePauliOp
import matplotlib.pyplot as plt
# from scipy.linalg import expm
from scipy.sparse.linalg import expm
from scipy import sparse
from scipy.optimize import minimize
import tensorflow as tf
import warnings
from functools import partial
import functools as ft
# from keras.utils import plot_model
warnings.simplefilter(action='ignore', category=FutureWarning)
tc.set_backend("tensorflow")
tc.set_dtype("complex128")

def str2WeightedPaulis_H2D(H2D):
    h = []
    terms = H2D.split('+')
    for term in terms:
        if term:  
            term = term.strip('+')
            weight, pauli_str = term.split('*')
            pauli_list = [pauli for pauli in pauli_str if pauli in 'XYZI']
            weight = float(weight)
            h.append([weight] + [int(pauli == 'X') + 2*int(pauli == 'Y') + 3*int(pauli == 'Z') for pauli in pauli_list])
    return h

def str2WeightedPaulis(s):
	s = s.strip()
	IXYZ = ['I', 'X', 'Y', 'Z']
	prev_idx = 0
	coefs = []
	paulis = []
	is_coef = True
	for idx, c in enumerate(s + '+'):
		if idx == 0: continue
		if is_coef and c in IXYZ:
			coef = complex(s[prev_idx : idx].replace('i', 'j'))
			coefs.append(coef)
			is_coef = False
			prev_idx = idx
		if not is_coef and c in ['+', '-']:
			label = s[prev_idx : idx]
			paulis.append(Pauli(label))
			is_coef = True
			prev_idx = idx
	return SparsePauliOp(paulis,coefs)
dtype=np.complex128
X = np.array([[0, 1.0], [1.0, 0]], dtype=dtype)
Y = np.array([[0, -1j], [1j, 0]], dtype=dtype)
Z = np.array([[1, 0], [0, -1]], dtype=dtype)
I = np.array([[1, 0], [0, 1]], dtype=dtype)
             
def tran(tin):
    if tin=='I':
        return '0'
    if tin=='X':
        return '1'
    if tin=='Y':
        return '2'
    if tin=='Z':
        return '3'
    else:
        return tin
def Fedtest(ex,GS):
    SS=[]
    for x in GS:
        SS.append(state_fidelity(ex,w[:,x]))
    SS=np.array(SS)
    return SS
def mykron(ma, mb, *list):
    """
    :param ma: matrix a
    :param mb: matrix b
    :param *List: a set of matrices
    :return:  kron(ma,mb,list[0],....,list[n-1])
    """
    # k1=tran(ma).copy()
    # k2=tran(mb).copy()
    out = np.kron(ma,mb)
    if len(list) != 0:
        # print(out)
        out = mykron(out, *list)
    return out
def lshift(s,n):
    return s[n:]+s[:n]
def J1J2(na,nb,J1,J2):
    Sl=[]
    Hl=[]
    Sb=[['X','X'],['Y','Y'],['Z','Z']]
    # 0  1  2  3
    # 4  5  6  7
    # 8  9 10 11
    #12 13 14 15
    #J1 periodic
    edge=[]
    edges=[]
    n=na*nb
    for i in range(na):
        for j in range(nb-1):
            a=i*nb+j
            b=i*nb+np.mod(j+1,nb)
            if a!=b:
                edge.append([a,b])
    for i in range(na-1):
        for j in range(nb):
            a=i*nb+j
            b=np.mod((i+1),na)*nb+j
            if a!=b:
                edge.append([a,b])
            
    # for i in range(n):
    for i in edge:
        edges.append(i)
        for j in Sb:
            init=list('I'*n)
            tmp=[]
            # a=np.mod(i,n)
            # b=np.mod(i+1,n)
            a=i[0]
            b=i[1]
            init[a]=j[0]
            init[b]=j[1]
            Sl.append(str(J1)+''.join(init))
            for k in list(init):
                tmp.append(tran(k))
            Hl.append([J1,tmp])
    #J2 periodic
    edge=[]
    n=na*nb
    for i in range(na):
        for j in range(nb-2):
            a=i*nb+j
            b=i*nb+np.mod(j+2,nb)
            if a!=b and [b,a] not in edge:
                edge.append([a,b])
    
    for i in range(na-2):
        for j in range(nb):
            a=i*nb+j
            b=np.mod((i+2),na)*nb+j
            if a!=b and [b,a] not in edge:
                edge.append([a,b])
            
    for i in edge:
        edges.append(i)
        for j in Sb:
            init=list('I'*n)
            # a=np.mod(i,n)
            # b=np.mod(i+2,n)
            a=i[0]
            b=i[1]
            init[a]=j[0]
            init[b]=j[1]
            Sl.append(str(J2)+''.join(init))
            
    a='1'+'I'*n
    H=0*str2WeightedPaulis(a).to_matrix(sparse=1)
    Hy=0*str2WeightedPaulis(a).to_matrix(sparse=1)
    Hx=0*str2WeightedPaulis(a).to_matrix(sparse=1)
    for i in Sl:
        H+=str2WeightedPaulis(i).to_matrix(sparse=1)
        if 'X' in list(i):
            Hx+=str2WeightedPaulis(i).to_matrix(sparse=1)
        if 'Y' in list(i):
            Hy+=str2WeightedPaulis(i).to_matrix(sparse=1)
        # else:
            # H+=str2WeightedPaulis(i).to_opflow().to_spmatrix()
    return H,edges,Hy,Hx
        
def dtheta(params,H):
    N=np.size(params)
    A=np.zeros([N,N],dtype=np.complex128)
    C=np.zeros(N,dtype=np.complex128)
    dpdt=[]
    cp=1/np.sqrt(2)
    a=np.pi/2
    phi=E(params)
    for i in range(N):
        ptmp1=params.copy().reshape(-1)
        ptmp2=params.copy().reshape(-1)
        ptmp1[i]+=a
        ptmp2[i]-=a    
        dp=cp*(E(ptmp1.reshape(params.shape))-E(ptmp2.reshape(params.shape)))
        dpdt.append(dp)
    for i in range(N):
        for j in range(N):
            # phi=Lv(params,wavefunction)
            A[i,j]=(dpdt[i].conj().dot(dpdt[j])).real#+dpdt[i].conj().dot(phi)*dpdt[j].conj().dot(phi)
    for i in range(N):
        # phi=Lv(params,wavefunction)
        C[i]=(dpdt[i].conj().dot(H.dot(phi))).real
    dx=np.linalg.pinv(A.real).dot(-C)
    return dx.real

def commutator(A,B):
    return A.dot(B)-B.dot(A)

def anticommutator(A,B):
    return A.dot(B)+B.dot(A)

def convert_sparse_matrix_to_sparse_tensor(X):
    coo = X.tocoo()
    indices = np.mat([coo.row, coo.col]).transpose()
    return tf.SparseTensor(indices, coo.data, coo.shape)

def Mtheta(theta):
    M=tc.Circuit(nqu)
    j=0
    for i in range(nqu):
        M.rx(i,theta=theta[j])
        j+=1
    for i in range(nqu):
        M.ry(i,theta=theta[j]) 
        j+=1
    return M.matrix().numpy()

def E(theta):
    u=cir(theta).state()
    return u.numpy()

def EN(v,H):
    # v=E(theta)
    return (v.conj().dot(H.dot(v))).real
# def sexpm(H):
#     I=H.copy()
#     I[I!=0]=0
#     return I-H+0.5*H.dot(H)
def cost(theta,H):
    v=E(theta)
    return EN(v,H)
    # return 1-state_fidelity(v, w[:,GS])

# def mS(theta):
#     u=E(theta)
#     v=w[:,GS].reshape(-1)
#     wh=v.conj()*v
#     u=wh*u
#     u/=np.sqrt(u.conj().dot(u))
#     return state_fidelity(u, w[:,GS])

def mS(u):
    # u=E(theta)
    v=w[:,GS].reshape(-1)
    wh=v.conj()*v
    u=wh*u
    u/=np.sqrt(u.conj().dot(u))
    return state_fidelity(u, w[:,GS])

def mA(theta):
    u=E(theta)
    u=u.conj()*(u)
    u/=np.sqrt(u)
    v=w[:,GS].reshape(-1)
    wh=v.conj()*v
    wh/=np.sqrt(wh)
    return state_fidelity(u, wh)

def eS(w,H):
    wh=abs(w.reshape(-1))
    u=np.ones(len(wh))
    u=w.reshape(-1)/wh*u
    u/=np.sqrt(u.conj().dot(u))
    return u.conj().dot(H.dot(u))

def S(H):
    Hp=H.copy()
    I=H*0
    I.setdiag(1)
    Hp[Hp<0]=0
    Hp.setdiag(0)
    
    Hn=H.copy()
    Hn[Hn>0]=0
    Hn.setdiag(H.diagonal())
    Hb=Hn-Hp
    # eHb=expm(-Hb)
    # eH=expm(-H)
    # eHb=I-0.1*Hb+0.01*Hb.dot(Hb)
    # eH=I-0.1*H+0.01*H.dot(H)
    return Hp
#%% j1j2
na=12
nb=1
J1=1
J2=0.6
# J.append(J2)
H,edges,Hy,Hx=J1J2(na,nb,J1,J2)
n=na*nb

#%% 2-d 9-Heisenberg
# def initial_param(t, theta, a):
#     return {"q": tf.Variable(theta),"c":cv} #cv=cgrad_exact[99]
    # return {"q": tf.Variable(theta)}

# dist=[0.8,0.4,0.4,0.4]#0.1(4,4,4);0.1(2,4,4);8222
dist = [1,1,1,1]
d=dist[1:]
h=dist[0]
J=d*np.array(h)
na=3
nb=1
n=na*nb
edge=[]
perms=[]
for i in range(na):
    for j in range(nb-1):
        edge.append([i*nb+j,i*nb+np.mod(j+1,nb)])
for i in range(na-1):
    for j in range(nb):
        edge.append([i*nb+j,np.mod((i+1),na)*nb+j])
H2D=''
for i in range(n):
    # tmpX='+'+str(h)
    # tmpY='+'+str(h)
    tmpZ='+'+str(h)+'*'
    for j in range(n):
        if j==i:
            # tmpX+='X'
            # tmpY+='Y'
            tmpZ+='Z'
        else:
            # tmpX+='I'
            # tmpY+='I'
            tmpZ+='I'
    H2D=H2D+tmpZ
for i in edge:
    tmpX='+'+str(J[0])+'*'
    tmpY='+'+str(J[1])+'*'
    tmpZ='+'+str(J[2])+'*'
    for j in range(n):
        if j in i:
            tmpX+='X'
            tmpY+='Y'
            tmpZ+='Z'
        else:
            tmpX+='I'
            tmpY+='I'
            tmpZ+='I'
    H2D=H2D+tmpX+tmpY+tmpZ
    

H2D1=''
for i in range(n):
    # tmpX='+'+str(h)
    # tmpY='+'+str(h)
    tmpZ1='+'+str(h)
    for j in range(n):
        if j==i:
            # tmpX+='X'
            # tmpY+='Y'
            tmpZ1+='Z'
        else:
            # tmpX+='I'
            # tmpY+='I'
            tmpZ1+='I'
    H2D1=H2D1+tmpZ1
for i in edge:
    tmpX1='+'+str(J[0])
    tmpY1='+'+str(J[1])
    tmpZ1='+'+str(J[2])
    for j in range(n):
        if j in i:
            tmpX1+='X'
            tmpY1+='Y'
            tmpZ1+='Z'
        else:
            tmpX1+='I'
            tmpY1+='I'
            tmpZ1+='I'
    H2D1=H2D1+tmpX1+tmpY1+tmpZ1
#%% maxcut Heisenberg
import numpy as np
from itertools import combinations

dist = [1, 1, 1, 1]
d = dist[1:]  
h = dist[0]   
J = d * h     

na = 3
nb = 1
n = na * nb

edge = list(combinations(range(n), 2))

H2D = ""
H2D1 = ""
# X→Y→Z 
for pauli, coeff in zip(["X", "Y", "Z"], J):
    for u, v in edge:
        term = ["I"] * n
        term[u] = pauli
        term[v] = pauli
        H2D += f"+{coeff}*{''.join(term)}"

for pauli, coeff in zip(["X", "Y", "Z"], J):
    for u, v in edge:
        term = ["I"] * n
        term[u] = pauli
        term[v] = pauli
        H2D1 += f"+{coeff}{''.join(term)}"
#%% molecular
def H2O():
    molecule = Molecule(
        geometry=[["O", [0, 0, .0]], ["H", [0, -0.757, 0.586]], ["H", [0, 0.757, 0.586]]],
        charge=0, multiplicity=1,
    )
    
    # driver = ElectronicStructureMoleculeDriver(
    #     molecule, basis="sto-3g", driver_type=ElectronicStructureDriverType.PYSCF,
    # )
    # # es_problem = ElectronicStructureProblem(driver,[ActiveSpaceTransformer(2,6)])
    # es_problem = ElectronicStructureProblem(driver)
    driver = ElectronicStructureMoleculeDriver(
        molecule, basis="sto-3g", driver_type=ElectronicStructureDriverType.PYSCF,
    )
    es_problem = ElectronicStructureProblem(driver)
    second_q_op = es_problem.second_q_ops()
    # TQR=TwoQubitReduction(es_problem.num_particles)
    # qubit_converter = QubitConverter(mapper=ParityMapper())#,two_qubit_reduction=True,)
    qubit_converter = QubitConverter(mapper=JordanWignerMapper())
    qubitOp = qubit_converter.convert(second_q_op['ElectronicEnergy'])
    # qubitOp = TQR.convert(qubitOp)
    H=qubitOp.to_spmatrix()
    return H


# def BeH2(bond_length):
#     molecule = Molecule(
#         geometry=[
#             ["Be", [0.0, 0.0, 0.0]],
#             ["H", [-bond_length, 0.0, 0.0]],  
#             ["H", [bond_length, 0.0, 0.0]],   
#         ],
#         charge=0, 
#         multiplicity=1,  
#     )
    
#     driver = ElectronicStructureMoleculeDriver(
#         molecule, basis="sto-6g", driver_type=ElectronicStructureDriverType.PYSCF,
#     )
    
#     es_problem = ElectronicStructureProblem(driver)

#     second_q_op = es_problem.second_q_ops()
    
#     qubit_converter = QubitConverter(mapper=JordanWignerMapper())
#     qubitOp = qubit_converter.convert(second_q_op['ElectronicEnergy'])
    
#     H = qubitOp.to_spmatrix()
    
#     return H

# bond_lengths = np.arange(1.0, 1.81, 0.1)  

# for length in bond_lengths:
#     H = BeH2(length)
#     u,w=sparse.linalg.eigs(H,k=1,which='SR')
#     plt.plot(w[:,0])

def BeH2():
    """
    arXiv:2504.07037v2 
    """
    molecule = Molecule(
        geometry=[
            ["Be", [0.000, 0.000, 0.000]],
            ["H", [0.000, 1.275, 2.750]],  # H1
            ["H", [0.000, -1.275, 2.750]],  # H2
        ],
        charge=0,  
        multiplicity=1,  
    )

    driver = ElectronicStructureMoleculeDriver(
        molecule, basis="sto-6g", driver_type=ElectronicStructureDriverType.PYSCF,
    )

    es_problem = ElectronicStructureProblem(driver)

    second_q_op = es_problem.second_q_ops()

    qubit_converter = QubitConverter(mapper=JordanWignerMapper())
    qubitOp = qubit_converter.convert(second_q_op['ElectronicEnergy'])

    H = qubitOp.to_spmatrix()
    
    return H


# H = BeH2()
# u,w=sparse.linalg.eigs(H,k=1,which='SR')
# plt.plot(w[:,0])
#%%
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
H=str2WeightedPaulis(H2D1).to_matrix(sparse=1)
deep=[5]
def initial_param(t, theta=None, a=None, weights=None):
    return weights
def ry_gate(theta):
    return tf.convert_to_tensor([
        [tf.cos(theta / 2), -tf.sin(theta / 2)],
        [tf.sin(theta / 2), tf.cos(theta / 2)]
    ], dtype=tf.float32)
def tensor_product_gates(*gates):
    operators = [tf.linalg.LinearOperatorFullMatrix(gate) for gate in gates]
    result = tf.linalg.LinearOperatorKronecker(operators)
    return result.to_dense()
# deep=[0]
for di in deep:
    u,w=sparse.linalg.eigs(H,k=4,which='SR')
    GS=np.where(abs(u-min(u))<1e-5)[0]
    wh=abs(w[:,GS].reshape(-1))
    wh/=np.sqrt(wh.conj().dot(wh))
    h0=convert_sparse_matrix_to_sparse_tensor(H)
    h = str2WeightedPaulis_H2D(H2D)
    epoch = 1
    max_epochs = 2
    gradient_threshold = 1e-2
    previous_f2 = None
    theta_ry = np.ones(n) * 0.5 * np.pi  
    theta_rz = np.array([]) 
    Eny = [0]
    best_histories = []
    previous_best_weights = None
    previous_best_f2 = []
    best_results_all = []
    while epoch <= max_epochs:
        fq = list(range(n))   
        # Initialize theta and optimize if we have f2 from previous epoch
        if previous_f2 is not None:
            # Convert previous theta to TensorFlow Variable
            thetas = tf.Variable(np.random.rand(n) * 2 * np.pi - np.pi, dtype=tf.float32)
            optimizer = tf.keras.optimizers.Adam(learning_rate=0.01)
            previous_f2_real = tf.cast(tf.math.real(previous_f2), tf.float32)
            # Optimization loop to match previous f2
            for _ in range(1000):  # Adjust number of optimization steps as needed
                with tf.GradientTape() as tape:
                    ry_gates = [ry_gate(theta) for theta in thetas]
                    C_y = tensor_product_gates(*ry_gates)
                    loss = tf.reduce_sum(tf.abs(C_y - tf.linalg.diag(previous_f2_real)) ** 2)
                
                gradients = tape.gradient(loss, thetas)
                if gradients is not None:
                    optimizer.apply_gradients([(gradients, thetas)])                
            theta_ry = np.concatenate([theta_ry, thetas.numpy()])
        num_tries = 10
        best_energy = float('inf')
        best_results = None
        best_circuit = None
        best_history_current_epoch = None         
        
        for try_idx in range(num_tries):
            print(f"Epoch {epoch}, Try {try_idx + 1}/{num_tries}")
            
            vqeinstance = VQNHE(
                theta_ry,
                theta_rz,
                n,
                h0,
                h,
                {"depth": 5, "width": 3, "choose": "real"},
                # {"width":3, "stddev": 0.01, "choose": "real-rbm"},
                {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea4"},
                shortcut=False,
            )
            
            cir = vqeinstance.circuit
            t = n + len(edge)  
            theta = (np.random.rand(t)-0.5)*2*np.pi
            init_params = {"q": tf.Variable(theta)}
            if previous_best_weights is not None:
                init_params["c"] = previous_best_weights
            rs1 = vqeinstance.multi_training(
                tries=1,
                maxiter=400,
                threshold=1E-7 * 0.5,
                onlyq=0,
                debug=20,
                qon=200,
                initialization_func=partial(initial_param, weights=init_params)
            )
            
            current_energy = rs1[0]['history'][-1]
            
            if current_energy < best_energy:
                best_energy = current_energy
                best_results = rs1[0]
                best_circuit = vqeinstance
                best_history_current_epoch = rs1[0]['history']
                previous_best_weights_0 = rs1[0]['model_weights']
                print(f"New best energy: {best_energy}")
        best_histories.append({
        'epoch': epoch,
        'history': best_history_current_epoch,
        'final_energy': best_energy,
        'model_weights': previous_best_weights_0
        })
        Eny.append(best_energy)
        previous_f2 = best_results['amp_f2'][-1]
        previous_best_f2.append(previous_f2)
        best_results_all.append(best_results)
        
        if len(Eny) > 1:
            gradient = np.abs(np.gradient(Eny)).mean()
            if gradient > gradient_threshold:
                theta_rz = np.concatenate([theta_rz, best_circuit.circuit_variable.numpy()])
                previous_best_weights = previous_best_weights_0
                epoch += 1
                print(f"Gradient {gradient:.2e} greater than threshold, increasing epoch to {epoch}")
                print(f"Current theta_rz shape: {theta_rz.shape}")
            else:
                break
        else:
            break
#%% plot
# import matplotlib.pyplot as plt
# import numpy as np

plt.style.use('default')  

plt.rcParams.update({
    'font.size': 12,
    'figure.figsize': [12, 8],
    'lines.linewidth': 2,
    'axes.grid': True,
    'grid.alpha': 0.3
})

# history of each epoch
plt.figure(figsize=(12, 6))
for epoch_data in best_histories:
    epoch = epoch_data['epoch']
    history = epoch_data['history']
    # history = epoch_data['history']-min(u.real)
    plt.plot(history, label=f'Epoch {epoch}')

# plt.yscale('log')
plt.xlabel('Iterations', fontsize=12)
plt.ylabel('Energy', fontsize=12)
plt.title('Training History for Each Epoch', fontsize=14)
plt.legend()
plt.grid(True, alpha=0.3)
plt.savefig('training_history_all_epochs.png', dpi=300, bbox_inches='tight')
plt.show()

# 2. final energy of each epoch
epochs = [data['epoch'] for data in best_histories]
final_energies = [data['final_energy'] for data in best_histories]

plt.figure(figsize=(10, 6))
plt.plot(epochs, final_energies, 'o-', linewidth=2, markersize=8)
plt.xlabel('Epoch', fontsize=12)
plt.ylabel('Final Energy', fontsize=12)
plt.title('Final Energy vs Epoch', fontsize=14)
plt.grid(True, alpha=0.3)
plt.savefig('final_energy_per_epoch.png', dpi=300, bbox_inches='tight')
plt.show()

#%% test
from tensorcircuit import Circuit
from tensorcircuit.templates.measurements import operator_expectation
final_best_results = best_results
final_best_circuit = best_circuit
final_circuit_params = final_best_circuit.circuit_variable.numpy()
ry = final_best_circuit.theta_ry
rz = final_best_circuit.theta_rz

final_f2 = final_best_results['amp_f2']
f2=tf.constant(final_f2[-1])
final_circuit = final_best_circuit.circuit(final_circuit_params, final_best_circuit.theta_ry, final_best_circuit.theta_rz)
wavefunction = final_circuit.state()
w1=wavefunction.numpy()
wave = tf.multiply(f2, w1)
nm = tf.linalg.norm(wave)
wave=wave/nm

c2 = Circuit(n, inputs=wave)
operator_expectation(c2, h0)
# fidelity
ry1 = ry
ry1[n:] = 0
rz1 = rz
rz1[t:] = 0
others = np.zeros(t)
cir1 = final_best_circuit.circuit(others, ry1, rz1)
w1 = cir1.state()
w1 = w1.numpy()
state_fidelity(w1,w[:,0])

ry2 = ry
ry2[2*n:] = 0
rz2 = rz
others = np.zeros(t)
cir2 = final_best_circuit.circuit(others, ry2, rz2)
w2 = cir2.state()
w2 = w2.numpy()
state_fidelity(w2,w[:,0])
#%% save
import pickle
with open('signproblem/result/3h1111_all_hea2_new.pkl', 'wb') as f:
    pickle.dump(best_results_all, f)
with open('signproblem/result/6h1111_all_vqnhe_c32_q2.pkl', 'wb') as f:
    pickle.dump(best_results_all, f)
    
#%% ry0+D0+ry1 -> nn1, sample and exact large
def initial_param(t, theta=None, a=None, weights=None):
    return weights
def ry_gate(theta):
    return tf.convert_to_tensor([
        [tf.cos(theta / 2), -tf.sin(theta / 2)],
        [tf.sin(theta / 2), tf.cos(theta / 2)]
    ], dtype=tf.float32)
def tensor_product_gates(*gates):
    operators = [tf.linalg.LinearOperatorFullMatrix(gate) for gate in gates]
    result = tf.linalg.LinearOperatorKronecker(operators)
    return result.to_dense()

from tensorcircuit.applications.vqes import VQNHE, JointSchedule
# from itertools import combinations
# H=str2WeightedPaulis(H2D1).to_matrix(sparse=1) # sample
n = 14 #molecular, exact large
# H = H2O() #molecular, exact large
H = BeH2()
# edge = list(combinations(range(n), 2)) # exact large
#molecular edge
edge=[]
for i in range(n-1):
    edge.append([i,i+1])

u,w=sparse.linalg.eigs(H,k=4,which='SR')
GS=np.where(abs(u-min(u))<1e-5)[0]
wh=abs(w[:,GS].reshape(-1))
wh/=np.sqrt(wh.conj().dot(wh))
h0=convert_sparse_matrix_to_sparse_tensor(H)
# h = str2WeightedPaulis_H2D(H2D)
epoch = 1
max_epochs = 3
gradient_threshold = 1e-3
previous_f2 = None
theta_ry = np.ones(n) * 0.5 * np.pi  
theta_rz = np.array([]) 
best_histories = []
pretrained_weights = None
previous_best_f2 = []
best_results_all = []
Eny = [0]
while epoch <= max_epochs:
    fq = list(range(n))       
    if previous_f2 is not None:
        thetas = tf.Variable(np.random.rand(n) * 2 * np.pi - np.pi, dtype=tf.float32)
        optimizer = tf.keras.optimizers.Adam(learning_rate=0.01)
        previous_f2_real = tf.cast(tf.math.real(previous_f2), tf.float32)
        # complex
        # previous_f2_real = tf.cast(tf.abs(previous_f2), tf.float32)
        # Optimization loop to match previous f2
        for _ in range(500):  # 1000
            with tf.GradientTape() as tape:
                ry_gates = [ry_gate(theta) for theta in thetas]
                C_y = tensor_product_gates(*ry_gates)
                loss = tf.reduce_sum(tf.abs(C_y - tf.linalg.diag(previous_f2_real)) ** 2)            
            gradients = tape.gradient(loss, thetas)
            if gradients is not None:
                optimizer.apply_gradients([(gradients, thetas)])                
        theta_ry = np.concatenate([theta_ry, thetas.numpy()])
        print(f"\nComplete training of theta_ry")
        
        pretrain_tries = 2
        best_pretrain_energy = float('inf')
        best_pretrain_weights = None        
        print(f"\nPre-training neural network for epoch {epoch}")        
        for pretrain_idx in range(pretrain_tries):
            print(f"Pre-training attempt {pretrain_idx + 1}/{pretrain_tries}")           
            vqeinstance_pretrain = VQNHE(
                theta_ry,
                theta_rz,
                n,
                h0,
                # h,# sample
                # {"depth": 3, "width": 2, "choose": "real"}, # sample
                {"depth": 3, "width": 6, "choose": "real"}, # molecular
                # {"depth": 5, "width": 3, "choose": "real"},
                {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea4"},
                shortcut=False,
            )
    
            t = n + len(edge)
            zero_theta = np.zeros(t)
            
            init_dict = {
                "q": tf.Variable(zero_theta),
                "c": None
            }
            
            rs_pretrain = vqeinstance_pretrain.multi_training(
                tries=1,
                maxiter=150, #150, 300
                threshold=1E-7 * 0.5,
                onlyq=0,
                debug=30,
                qon=0,
                initialization_func=lambda try_idx: init_dict
            )
                
            current_pretrain_energy = rs_pretrain[0]['history'][-1]

            if current_pretrain_energy < best_pretrain_energy:
                best_pretrain_energy = current_pretrain_energy
                best_pretrain_weights = rs_pretrain[0]['model_weights']
                print(f"New best pre-training energy: {best_pretrain_energy}")
        
        print(f"\nBest pre-training energy achieved: {best_pretrain_energy}")
        pretrained_weights = best_pretrain_weights
    
    num_tries = 5 #5
    best_energy = float('inf')
    best_results = None
    best_circuit = None
    best_history_current_epoch = None
    
    print(f"\nStarting main training for Epoch {epoch}")
    
    for try_idx in range(num_tries):
        print(f"Epoch {epoch}, Try {try_idx + 1}/{num_tries}")
        
        vqeinstance = VQNHE(
            theta_ry,
            theta_rz,
            n,
            h0,
            # h,# sample
            # {"depth": 3, "width": 2, "choose": "real"}, # sample
            {"depth": 3, "width": 6, "choose": "real"}, # molecular,j1j2
            # {"depth": 5, "width": 3, "choose": "real"},
            # {"width":2, "stddev": 0.01, "choose": "complex-rbm"},
            {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea4"},
            shortcut=False,
        )
        
        cir = vqeinstance.circuit
        t = n + len(edge)  
        theta = (np.random.rand(t)-0.5)*2*np.pi
        # if previous_f2 is not None:
        #     theta = np.zeros(t)
        # else:
        #     theta = (np.random.rand(t)-0.5)*2*np.pi

        init_params = {"q": tf.Variable(theta)}
        if pretrained_weights is not None:
            init_params["c"] = pretrained_weights
        test = int(200+(epoch-2)*(epoch-1)*200)
        rs1 = vqeinstance.multi_training(
            tries=1,
            maxiter=test,
            threshold=1E-7 * 0.5,
            onlyq=0,
            debug=50,
            qon=test,
            initialization_func=partial(initial_param, weights=init_params)
        )
        
        current_energy = rs1[0]['history'][-1]
        
        if current_energy < best_energy:
            best_energy = current_energy
            best_results = rs1[0]
            best_circuit = vqeinstance
            best_history_current_epoch = rs1[0]['history']
            print(f"New best energy in epoch {epoch}: {best_energy}")
    
    best_histories.append({
        'epoch': epoch,
        'history': best_history_current_epoch,
        'final_energy': best_energy,
        'model_weights': best_results['model_weights'],
        'pretrained_weights': pretrained_weights  
    })
    
    Eny.append(best_energy)
    previous_f2 = best_results['amp_f2'][-1]
    previous_best_f2.append(previous_f2)
    best_results_all.append(best_results)
    
    if len(Eny) > 1:
        gradient = np.abs(np.gradient(Eny)).mean()
        if gradient > gradient_threshold:
            qv = best_results_all[-1]['qgrad'][-1]
            theta_rz = np.concatenate([theta_rz, qv])
            epoch += 1
            print(f"Gradient {gradient:.2e} greater than threshold, increasing epoch to {epoch}")
            print(f"Current theta_rz shape: {theta_rz.shape}")
        else:
            break
    else:
        break

# import pickle
# with open('signproblem/result/molecular_H2O_e3.pkl', 'wb') as f:
#     pickle.dump(best_results_all, f)

#%% vqe: hea3, sample and exact large
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
# H=str2WeightedPaulis(H2D1).to_matrix(sparse=1) # sample
n = 14 #molecular, exact large
H = H2O() #molecular, exact large
edge=[]
for i in range(n-1):
    edge.append([i,i+1])
deep=[1]
def initial_param(t, theta=None, a=None, weights=None):
    return weights

for di in deep:
    u,w=sparse.linalg.eigs(H,k=4,which='SR')
    GS=np.where(abs(u-min(u))<1e-5)[0]
    wh=abs(w[:,GS].reshape(-1))
    wh/=np.sqrt(wh.conj().dot(wh))
    h0=convert_sparse_matrix_to_sparse_tensor(H)
    # h = str2WeightedPaulis_H2D(H2D) # sample
    epoch = 1
    max_epochs = 3
    gradient_threshold = 1e-2
    previous_f2 = None
    theta_ry = np.array([])
    theta_rz = np.array([]) 
    Eny = [0]
    best_histories = []
    previous_best_weights = None
    previous_best_f2 = []
    best_results_all = []
    num_tries = 5
    while epoch <= max_epochs:
        fq = list(range(n)) 
        best_energy = float('inf')
        best_results = None
        best_circuit = None
        best_history_current_epoch = None         
        for try_idx in range(num_tries):
            print(f"Epoch {epoch}, Try {try_idx + 1}/{num_tries}")            
            vqeinstance = VQNHE(
                theta_ry,
                theta_rz,
                n,
                h0,
                # h,# sample
                {"depth": 3, "width": 2, "choose": "real"},
                # {"width":3, "stddev": 0.01, "choose": "real-rbm"},
                {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea3"},
                shortcut=False,
            )
            
            cir = vqeinstance.circuit
            t = 2*n + len(edge)  
            theta = (np.random.rand(t)-0.5)*2*np.pi
            # if epoch==1:
            #     theta = (np.random.rand(t)-0.5)*2*np.pi
            # else:
            #     theta = qv

            init_params = {"q": tf.Variable(theta)}
            if previous_best_weights is not None:
                init_params["c"] = previous_best_weights
            test = int(200+(epoch-2)*(epoch-1)*200)
            rs1 = vqeinstance.multi_training(
                tries=1,
                maxiter=test,
                threshold=1E-7 * 0.5,
                onlyq=test,
                debug=50,
                qon=0,
                initialization_func=partial(initial_param, weights=init_params)
            )
            
            current_energy = rs1[0]['history'][-1]
            
            if current_energy < best_energy:
                best_energy = current_energy
                best_results = rs1[0]
                best_circuit = vqeinstance
                best_history_current_epoch = rs1[0]['history']
                print(f"New best energy: {best_energy}")
        best_histories.append({
        'epoch': epoch,
        'history': best_history_current_epoch,
        'final_energy': best_energy
        })
        Eny.append(best_energy)
        best_results_all.append(best_results)
        
        if len(Eny) > 1:
            gradient = np.abs(np.gradient(Eny)).mean()
            if gradient > gradient_threshold:
                qv = best_results_all[-1]['qgrad'][-1]
                theta_rz = np.concatenate([theta_rz, qv[n:]])
                theta_ry = np.concatenate([theta_ry, qv[:n]])
                epoch += 1
                print(f"Gradient {gradient:.2e} greater than threshold, increasing epoch to {epoch}")
            else:
                break
        else:
            break
# import pickle
# with open('signproblem/result/molecular_H2O_hea3.pkl', 'wb') as f:
#     pickle.dump(best_results_all, f)
#%% vqe: hea2, sample and exact large
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
# H=str2WeightedPaulis(H2D1).to_matrix(sparse=1) # sample
n = 14 #molecular, exact large
H = H2O() #molecular, exact large
edge=[]
for i in range(n-1):
    edge.append([i,i+1])
deep=[1]
def initial_param(t, theta=None, a=None, weights=None):
    return weights

for di in deep:
    u,w=sparse.linalg.eigs(H,k=4,which='SR')
    GS=np.where(abs(u-min(u))<1e-5)[0]
    wh=abs(w[:,GS].reshape(-1))
    wh/=np.sqrt(wh.conj().dot(wh))
    h0=convert_sparse_matrix_to_sparse_tensor(H)
    # h = str2WeightedPaulis_H2D(H2D) # sample
    epoch = 1
    max_epochs = 3
    gradient_threshold = 1e-2
    previous_f2 = None
    theta_ry = np.array([])
    theta_rz = np.array([]) 
    Eny = [0]
    best_histories = []
    previous_best_weights = None
    previous_best_f2 = []
    best_results_all = []
    num_tries = 5
    while epoch <= max_epochs:
        fq = list(range(n)) 
        best_energy = float('inf')
        best_results = None
        best_circuit = None
        best_history_current_epoch = None         
        for try_idx in range(num_tries):
            print(f"Epoch {epoch}, Try {try_idx + 1}/{num_tries}")            
            vqeinstance = VQNHE(
                theta_ry,
                theta_rz,
                n,
                h0,
                # h, # sample
                # {"depth": 3, "width": 2, "choose": "real"},# sample
                {"depth": 3, "width": 6, "choose": "real"}, # molecular
                # {"width":3, "stddev": 0.01, "choose": "real-rbm"},
                {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": max_epochs, "choose": "hea2"},
                shortcut=False,
            )
            
            cir = vqeinstance.circuit
            t = (2*n + len(edge))*max_epochs  
            theta = (np.random.rand(t)-0.5)*2*np.pi
            if epoch==1:
                theta = (np.random.rand(t)-0.5)*2*np.pi
            else:
                theta = qv
            init_params = {"q": tf.Variable(theta)}
            if previous_best_weights is not None:
                init_params["c"] = previous_best_weights
            test = int(200+(epoch-2)*(epoch-1)*200)
            rs1 = vqeinstance.multi_training(
                tries=1,
                maxiter=test, # 200
                threshold=1E-7 * 0.5,
                onlyq=test, # vqe
                debug=50,
                qon=0,
                initialization_func=partial(initial_param, weights=init_params)
            )
            
            current_energy = rs1[0]['history'][-1]
            
            if current_energy < best_energy:
                best_energy = current_energy
                best_results = rs1[0]
                best_circuit = vqeinstance
                best_history_current_epoch = rs1[0]['history']
                print(f"New best energy: {best_energy}")
        best_histories.append({
        'epoch': epoch,
        'history': best_history_current_epoch,
        'final_energy': best_energy
        })
        Eny.append(best_energy)
        best_results_all.append(best_results)
        
        if len(Eny) > 1:
            gradient = np.abs(np.gradient(Eny)).mean()
            if gradient > gradient_threshold:
                qv = best_results_all[-1]['qgrad'][-1] # vqe
                # theta_rz = np.concatenate([theta_rz, qv[n:]])
                # theta_ry = np.concatenate([theta_ry, qv[:n]])
                epoch += 1
                print(f"Gradient {gradient:.2e} greater than threshold, increasing epoch to {epoch}")
            else:
                break
        else:
            break

# import pickle
# with open('signproblem/result/molecular_H2O_hea2.pkl', 'wb') as f:
#     pickle.dump(best_results_all, f)
#%% nn, exact large
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
# H=str2WeightedPaulis(H2D1).to_matrix(sparse=1) # sample
n = 14 #molecular, exact large
# H = H2O() #molecular, exact large
H = BeH2()
edge=[]
for i in range(n-1):
    edge.append([i,i+1])
deep=[1]
def initial_param(t, theta=None, a=None, weights=None):
    return weights

for di in deep:
    u,w=sparse.linalg.eigs(H,k=4,which='SR')
    GS=np.where(abs(u-min(u))<1e-5)[0]
    wh=abs(w[:,GS].reshape(-1))
    wh/=np.sqrt(wh.conj().dot(wh))
    h0=convert_sparse_matrix_to_sparse_tensor(H)
    # h = str2WeightedPaulis_H2D(H2D) # sample
    epoch = 1
    max_epochs = 3
    gradient_threshold = 1e-2
    previous_f2 = None
    theta_ry = np.array([])
    theta_rz = np.array([]) 
    Eny = [0]
    best_histories = []
    previous_best_weights = None
    previous_best_f2 = []
    best_results_all = []
    num_tries = 5
    while epoch <= max_epochs:
        fq = list(range(n)) 
        best_energy = float('inf')
        best_results = None
        best_circuit = None
        best_history_current_epoch = None         
        for try_idx in range(num_tries):
            print(f"Epoch {epoch}, Try {try_idx + 1}/{num_tries}")            
            vqeinstance = VQNHE(
                theta_ry,
                theta_rz,
                n,
                h0,
                # h, # sample
                # {"depth": 3, "width": 2, "choose": "real"},# sample
                {"depth": 3, "width": 6, "choose": "real"}, # molecular
                # {"width":3, "stddev": 0.01, "choose": "real-rbm"},
                {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": max_epochs, "choose": "hea2"},
                shortcut=False,
            )
            
            cir = vqeinstance.circuit
            t = (2*n + len(edge))*max_epochs  
            theta = (np.random.rand(t)-0.5)*2*np.pi*0
            # if epoch==1:
            #     theta = (np.random.rand(t)-0.5)*2*np.pi
            # else:
            #     theta = qv
            init_params = {"q": tf.Variable(theta)}
            if previous_best_weights is not None:
                init_params["c"] = previous_best_weights
            test = int(200+(epoch-2)*(epoch-1)*200)
            rs1 = vqeinstance.multi_training(
                tries=1,
                maxiter=test, # 200
                threshold=1E-7 * 0.5,
                onlyq=0, # vqe
                debug=50,
                qon=0,
                initialization_func=partial(initial_param, weights=init_params)
            )
            
            current_energy = rs1[0]['history'][-1]
            
            if current_energy < best_energy:
                best_energy = current_energy
                best_results = rs1[0]
                best_circuit = vqeinstance
                best_history_current_epoch = rs1[0]['history']
                print(f"New best energy: {best_energy}")
        best_histories.append({
        'epoch': epoch,
        'history': best_history_current_epoch,
        'final_energy': best_energy
        })
        Eny.append(best_energy)
        best_results_all.append(best_results)
        
        if len(Eny) > 1:
            gradient = np.abs(np.gradient(Eny)).mean()
            if gradient > gradient_threshold:
                qv = best_results_all[-1]['qgrad'][-1] # vqe
                previous_best_weights = best_results_all[-1]['cgrad'][-1] # nn
                # theta_rz = np.concatenate([theta_rz, qv[n:]])
                # theta_ry = np.concatenate([theta_ry, qv[:n]])
                epoch += 1
                print(f"Gradient {gradient:.2e} greater than threshold, increasing epoch to {epoch}")
            else:
                break
        else:
            break
# import pickle
# with open('signproblem/result/molecular_H2O_realnn.pkl', 'wb') as f:
#     pickle.dump(best_results_all, f)
#%% maxcut
import networkx as nx
def initial_param(t, theta=None, a=None, weights=None):
    return weights
def ry_gate(theta):
    return tf.convert_to_tensor([
        [tf.cos(theta / 2), -tf.sin(theta / 2)],
        [tf.sin(theta / 2), tf.cos(theta / 2)]
    ], dtype=tf.float32)
def tensor_product_gates(*gates):
    operators = [tf.linalg.LinearOperatorFullMatrix(gate) for gate in gates]
    result = tf.linalg.LinearOperatorKronecker(operators)
    return result.to_dense()

def maxcut_test(G,result_x):
    color_map = []
    for i in range(len(G.nodes())):
        if result_x[i]==-1:
            color_map.append('red') 
        else:
            color_map.append('blue') 
            
    group_A = [i for i, color in enumerate(color_map) if color == 'red']
    group_B = [i for i, color in enumerate(color_map) if color == 'blue']
    cut_size = nx.algorithms.cut_size(G, group_A)
    
    # nodes = sorted(G.nodes())  
    # color_dict = {node: color_map[i] for i, node in enumerate(nodes)}
    # draw_colors = [color_dict[node] for node in G.nodes()]
    # pos = {i: (i % 3, -(i // 3)) for i in G.nodes()}    
    # nx.draw(G, pos, node_color=draw_colors, with_labels=True)  
    # plt.title(f"3x3 Grid MaxCut (Size={cut_size})")
    # plt.show()
    
    return group_A, group_B, cut_size


# G = nx.grid_2d_graph(3, 3)
# G = nx.convert_node_labels_to_integers(G)
# pos = nx.spring_layout(G)
# nx.draw(G, pos, with_labels=True, node_color='lightblue')
# plt.show()
G = nx.erdos_renyi_graph(n=9, p=0.3)  # edge prob = 0.3
num_G = 0.5*len(G.edges())+0.25*(len(G.nodes())-1)
edges_G = G.edges()
# print("V:", list(G.nodes()))
# print("E:", list(G.edges()))

from tensorcircuit.applications.vqes import VQNHE, JointSchedule
H=str2WeightedPaulis(H2D1).to_matrix(sparse=1)
u,w=sparse.linalg.eigs(H,k=4,which='SR')
GS=np.where(abs(u-min(u))<1e-5)[0]
wh=abs(w[:,GS].reshape(-1))
wh/=np.sqrt(wh.conj().dot(wh))
h0=convert_sparse_matrix_to_sparse_tensor(H)
h = str2WeightedPaulis_H2D(H2D)
epoch = 1
max_epochs = 2
gradient_threshold = 1e-3
previous_f2 = None
theta_ry = np.ones(n) * 0.5 * np.pi  
theta_rz = np.array([]) 
best_histories = []
pretrained_weights = None
previous_best_f2 = []
best_results_all = []
Eny = [0]
while epoch <= max_epochs:
    fq = list(range(n))       
    if previous_f2 is not None:
        thetas = tf.Variable(np.random.rand(n) * 2 * np.pi - np.pi, dtype=tf.float32)
        optimizer = tf.keras.optimizers.Adam(learning_rate=0.01)
        previous_f2_real = tf.cast(tf.math.real(previous_f2), tf.float32)
        # complex
        # previous_f2_real = tf.cast(tf.abs(previous_f2), tf.float32)
        # Optimization loop to match previous f2
        for _ in range(1000):  # Adjust number of optimization steps as needed
            with tf.GradientTape() as tape:
                ry_gates = [ry_gate(theta) for theta in thetas]
                C_y = tensor_product_gates(*ry_gates)
                loss = tf.reduce_sum(tf.abs(C_y - tf.linalg.diag(previous_f2_real)) ** 2)            
            gradients = tape.gradient(loss, thetas)
            if gradients is not None:
                optimizer.apply_gradients([(gradients, thetas)])                
        theta_ry = np.concatenate([theta_ry, thetas.numpy()])
        print(f"\nComplete training of theta_ry")
        
        pretrain_tries = 5
        best_pretrain_energy = float('inf')
        best_pretrain_weights = None        
        print(f"\nPre-training neural network for epoch {epoch}")        
        for pretrain_idx in range(pretrain_tries):
            print(f"Pre-training attempt {pretrain_idx + 1}/{pretrain_tries}")           
            vqeinstance_pretrain = VQNHE(
                num_G,
                edges_G,
                theta_ry,
                theta_rz,
                n,
                h0,
                h,
                {"depth": 3, "width": 2, "choose": "real"},
                # {"depth": 5, "width": 3, "choose": "real"},
                {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea4"},
                shortcut=False,
            )
    
            t = n + len(edge)
            zero_theta = np.zeros(t)
            
            init_dict = {
                "q": tf.Variable(zero_theta),
                "c": None
            }
            
            rs_pretrain = vqeinstance_pretrain.multi_training(
                tries=1,
                maxiter=150, #150
                threshold=1E-7 * 0.5,
                onlyq=0,
                debug=30,
                qon=0,
                initialization_func=lambda try_idx: init_dict
            )
                
            current_pretrain_energy = rs_pretrain[0]['history'][-1]

            if current_pretrain_energy < best_pretrain_energy:
                best_pretrain_energy = current_pretrain_energy
                best_pretrain_weights = rs_pretrain[0]['model_weights']
                print(f"New best pre-training energy: {best_pretrain_energy}")
        
        print(f"\nBest pre-training energy achieved: {best_pretrain_energy}")
        pretrained_weights = best_pretrain_weights
    
    num_tries = 5 #5
    best_energy = float('inf')
    best_results = None
    best_circuit = None
    best_history_current_epoch = None
    
    print(f"\nStarting main training for Epoch {epoch}")
    
    for try_idx in range(num_tries):
        print(f"Epoch {epoch}, Try {try_idx + 1}/{num_tries}")
        
        vqeinstance = VQNHE(
            num_G,
            edges_G,
            theta_ry,
            theta_rz,
            n,
            h0,
            h,
            {"depth": 3, "width": 2, "choose": "real"},
            # {"depth": 5, "width": 3, "choose": "real"},
            # {"width":2, "stddev": 0.01, "choose": "complex-rbm"},
            {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea4"},
            shortcut=False,
        )
        
        cir = vqeinstance.circuit
        t = n + len(edge)  
        theta = (np.random.rand(t)-0.5)*2*np.pi
        # if previous_f2 is not None:
        #     theta = np.zeros(t)
        # else:
        #     theta = (np.random.rand(t)-0.5)*2*np.pi

        init_params = {"q": tf.Variable(theta)}
        if pretrained_weights is not None:
            init_params["c"] = pretrained_weights
        
        rs1 = vqeinstance.multi_training(
            tries=1,
            maxiter=50,
            threshold=1E-7 * 0.5,
            onlyq=0,
            debug=10,
            qon=50,
            initialization_func=partial(initial_param, weights=init_params)
        )
        
        current_energy = rs1[0]['history'][-1]
        
        if current_energy < best_energy:
            best_energy = current_energy
            best_results = rs1[0]
            best_circuit = vqeinstance
            best_history_current_epoch = rs1[0]['history']
            print(f"New best energy in epoch {epoch}: {best_energy}")
    
    best_histories.append({
        'epoch': epoch,
        'history': best_history_current_epoch,
        'final_energy': best_energy,
        'model_weights': best_results['model_weights'],
        'pretrained_weights': pretrained_weights  
    })
    
    Eny.append(best_energy)
    previous_f2 = best_results['amp_f2'][-1]
    previous_best_f2.append(previous_f2)
    best_results_all.append(best_results)
    
    if len(Eny) > 1:
        gradient = np.abs(np.gradient(Eny)).mean()
        if gradient > gradient_threshold:
            qv = best_results_all[-1]['qgrad'][-1]
            theta_rz = np.concatenate([theta_rz, qv])
            epoch += 1
            print(f"Gradient {gradient:.2e} greater than threshold, increasing epoch to {epoch}")
            print(f"Current theta_rz shape: {theta_rz.shape}")
        else:
            break
    else:
        break
# with open('signproblem/result/9maxcut_vqnhe_0.pkl', 'wb') as f:
#     pickle.dump(best_results_all, f)
#%% maxcut: hea1
# import networkx as nx
def num_param(n, epochs):
    total = n*epochs
    for epoch in range(epochs):
        if n % 2 == 1:  
            total += (n - 1) // 2
        else:  
            if epoch % 2 == 0:  
                total += n // 2
            else:  
                total += (n // 2) - 1                
    return total

def initial_param(t, theta=None, a=None, weights=None):
    return weights
def ry_gate(theta):
    return tf.convert_to_tensor([
        [tf.cos(theta / 2), -tf.sin(theta / 2)],
        [tf.sin(theta / 2), tf.cos(theta / 2)]
    ], dtype=tf.float32)
def tensor_product_gates(*gates):
    operators = [tf.linalg.LinearOperatorFullMatrix(gate) for gate in gates]
    result = tf.linalg.LinearOperatorKronecker(operators)
    return result.to_dense()


# G = nx.grid_2d_graph(3, 3)
# G = nx.convert_node_labels_to_integers(G)
# num_G = 0.5*len(G.edges())+0.25*(len(G.nodes())-1)
# edges_G = G.edges()
# print("V:", list(G.nodes()))
# print("E:", list(G.edges()))

from tensorcircuit.applications.vqes import VQNHE, JointSchedule
H=str2WeightedPaulis(H2D1).to_matrix(sparse=1)
u,w=sparse.linalg.eigs(H,k=4,which='SR')
GS=np.where(abs(u-min(u))<1e-5)[0]
wh=abs(w[:,GS].reshape(-1))
wh/=np.sqrt(wh.conj().dot(wh))
h0=convert_sparse_matrix_to_sparse_tensor(H)
h = str2WeightedPaulis_H2D(H2D)
epoch = 2
max_epochs = 2
gradient_threshold = 1e-3
previous_f2 = None
theta_ry = np.ones(n) * 0.5 * np.pi  
theta_rz = np.array([]) 
best_histories = []
pretrained_weights = None
previous_best_f2 = []
best_results_all = []
Eny = [0]
while epoch <= max_epochs:
    fq = list(range(n)) 
    num_tries = 5 #5
    best_energy = float('inf')
    best_results = None
    best_circuit = None
    best_history_current_epoch = None
    
    print(f"\nStarting main training for Epoch {epoch}")
    
    for try_idx in range(num_tries):
        print(f"Epoch {epoch}, Try {try_idx + 1}/{num_tries}")
        
        vqeinstance = VQNHE(
            num_G,
            edges_G,
            theta_ry,
            theta_rz,
            n,
            h0,
            h,
            {"depth": 3, "width": 2, "choose": "real"},
            # {"depth": 5, "width": 3, "choose": "real"},
            # {"width":2, "stddev": 0.01, "choose": "complex-rbm"},
            {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea1"},
            shortcut=False,
        )
        
        cir = vqeinstance.circuit
        t =  num_param(n, epoch)
        theta = (np.random.rand(t)-0.5)*2*np.pi

        init_params = {"q": tf.Variable(theta)}
        if pretrained_weights is not None:
            init_params["c"] = pretrained_weights
        
        rs1 = vqeinstance.multi_training(
            tries=1,
            maxiter=100,
            threshold=1E-7 * 0.5,
            onlyq=100,
            debug=20,
            qon=0,
            initialization_func=partial(initial_param, weights=init_params)
        )
        
        current_energy = rs1[0]['history'][-1]
        
        if current_energy < best_energy:
            best_energy = current_energy
            best_results = rs1[0]
            best_circuit = vqeinstance
            best_history_current_epoch = rs1[0]['history']
            print(f"New best energy in epoch {epoch}: {best_energy}")
    
    best_histories.append({
        'epoch': epoch,
        'history': best_history_current_epoch,
        'final_energy': best_energy,
        'model_weights': best_results['model_weights'],
        'pretrained_weights': pretrained_weights  
    })
    
    Eny.append(best_energy)
    # previous_f2 = best_results['amp_f2'][-1]
    previous_best_f2.append(previous_f2)
    best_results_all.append(best_results)
    
    if len(Eny) > 1:
        gradient = np.abs(np.gradient(Eny)).mean()
        if gradient > gradient_threshold:
            # theta_rz = np.concatenate([theta_rz, best_circuit.circuit_variable.numpy()])
            epoch += 1
            print(f"Gradient {gradient:.2e} greater than threshold, increasing epoch to {epoch}")
            print(f"Current theta_rz shape: {theta_rz.shape}")
        else:
            break
    else:
        break

#%% maxcut: hea2
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
H=str2WeightedPaulis(H2D1).to_matrix(sparse=1)
u,w=sparse.linalg.eigs(H,k=4,which='SR')
GS=np.where(abs(u-min(u))<1e-5)[0]
wh=abs(w[:,GS].reshape(-1))
wh/=np.sqrt(wh.conj().dot(wh))
h0=convert_sparse_matrix_to_sparse_tensor(H)
h = str2WeightedPaulis_H2D(H2D)
epoch = 1
max_epochs = 2
gradient_threshold = 1e-3
previous_f2 = None
theta_ry = np.ones(n) * 0.5 * np.pi  
theta_rz = np.array([]) 
best_histories = []
pretrained_weights = None
previous_best_f2 = []
best_results_all = []
Eny = [0]
while epoch <= max_epochs:
    fq = list(range(n)) 
    num_tries = 5 #5
    best_energy = float('inf')
    best_results = None
    best_circuit = None
    best_history_current_epoch = None
    
    print(f"\nStarting main training for Epoch {epoch}")
    
    for try_idx in range(num_tries):
        print(f"Epoch {epoch}, Try {try_idx + 1}/{num_tries}")
        
        vqeinstance = VQNHE(
            num_G,
            edges_G,
            theta_ry,
            theta_rz,
            n,
            h0,
            h,
            {"depth": 3, "width": 2, "choose": "real"},
            # {"depth": 5, "width": 3, "choose": "real"},
            # {"width":2, "stddev": 0.01, "choose": "complex-rbm"},
            {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": max_epochs, "choose": "hea2"},
            shortcut=False,
        )
        
        cir = vqeinstance.circuit
        # t =  num_param(n, epoch)
        t = (2*n + len(edge))*epoch
        theta = (np.random.rand(t)-0.5)*2*np.pi

        init_params = {"q": tf.Variable(theta)}
        if pretrained_weights is not None:
            init_params["c"] = pretrained_weights
        
        rs1 = vqeinstance.multi_training(
            tries=1,
            maxiter=100,
            threshold=1E-7 * 0.5,
            onlyq=100,
            debug=20,
            qon=0,
            initialization_func=partial(initial_param, weights=init_params)
        )
        
        current_energy = rs1[0]['history'][-1]
        
        if current_energy < best_energy:
            best_energy = current_energy
            best_results = rs1[0]
            best_circuit = vqeinstance
            best_history_current_epoch = rs1[0]['history']
            print(f"New best energy in epoch {epoch}: {best_energy}")
    
    best_histories.append({
        'epoch': epoch,
        'history': best_history_current_epoch,
        'final_energy': best_energy,
        'model_weights': best_results['model_weights'],
        'pretrained_weights': pretrained_weights  
    })
    
    Eny.append(best_energy)
    # previous_f2 = best_results['amp_f2'][-1]
    previous_best_f2.append(previous_f2)
    best_results_all.append(best_results)
    
    if len(Eny) > 1:
        gradient = np.abs(np.gradient(Eny)).mean()
        if gradient > gradient_threshold:
            # theta_rz = np.concatenate([theta_rz, best_circuit.circuit_variable.numpy()])
            epoch += 1
            print(f"Gradient {gradient:.2e} greater than threshold, increasing epoch to {epoch}")
            print(f"Current theta_rz shape: {theta_rz.shape}")
        else:
            break
    else:
        break

#%% maxcut test
def maxcut_test(G,result_x):
    # G = nx.grid_2d_graph(3, 3)
    # G = nx.convert_node_labels_to_integers(G)

    color_map = []
    # for node in G.nodes():
    #     original_pos = list(nx.grid_2d_graph(3, 3).nodes())[node]
    #     if (original_pos[0] + original_pos[1]) % 2 == 0:
    #         color_map.append('red')  
    #     else:
    #         color_map.append('blue') 
    for i in range(len(G.nodes())):
        if result_x[i]==-1:
            color_map.append('red') 
        else:
            color_map.append('blue') 
            
    group_A = [i for i, color in enumerate(color_map) if color == 'red']
    group_B = [i for i, color in enumerate(color_map) if color == 'blue']
    cut_size = nx.algorithms.cut_size(G, group_A)
    
    nodes = sorted(G.nodes())  
    color_dict = {node: color_map[i] for i, node in enumerate(nodes)}
    draw_colors = [color_dict[node] for node in G.nodes()]
    pos = {i: (i % 3, -(i // 3)) for i in G.nodes()}    
    nx.draw(G, pos, node_color=draw_colors, with_labels=True)  
    plt.title(f"3x3 Grid MaxCut (Size={cut_size})")
    plt.show()
    
    return group_A, group_B, cut_size


group_A, group_B, max_cut = maxcut_test(G,test)
# print(f"group A: {sorted(group_A)}")
# print(f"group B: {sorted(group_B)}")
# print(f"MaxCut: {max_cut}")
import networkx as nx
import matplotlib.pyplot as plt

G = nx.erdos_renyi_graph(n=9, p=0.3)  # edge prob = 0.3

pos = nx.spring_layout(G)
nx.draw(G, pos, with_labels=True, node_color='lightblue')
plt.show()

#%% figure
import pickle
with open('/home/Mengzhen/signproblem/result/3h1111_all_vqnhe.pkl', 'rb') as f:
    result_vqnhe = pickle.load(f)
with open('/home/Mengzhen/signproblem/result/3h1111_all_vqe3.pkl', 'rb') as f:
    result_vqe3 = pickle.load(f)
with open('/home/Mengzhen/signproblem/result/3h1111_all_vqe2_new.pkl', 'rb') as f:
    result_vqe2 = pickle.load(f)
plt.figure(figsize=(12, 6))
epoch = 0
for epoch_data in result_vqnhe:
    history = epoch_data['history']
    # history = np.abs(epoch_data['history']-min(u.real))
    plt.plot(history, label=f'Epoch {epoch}')
    epoch += 1

# plt.yscale('log')
plt.xlabel('Iterations', fontsize=12)
plt.ylabel('Energy', fontsize=12)
plt.title('Training History for Each Epoch', fontsize=14)
plt.legend()
plt.grid(True, alpha=0.3)
# plt.savefig('training_history_all_epochs.png', dpi=300, bbox_inches='tight')
plt.show()
# cv
# np.std(result_vqnhe[1]['history'][150:])/np.mean(result_vqnhe[1]['history'][150:])
#%%
import pickle
import matplotlib.pyplot as plt

with open('/home/Mengzhen/signproblem/result/3h1111_all_vqnhe_noise.pkl', 'rb') as f:
    result_vqnhe = pickle.load(f)
with open('/home/Mengzhen/signproblem/result/3h1111_all_vqe3_noise.pkl', 'rb') as f:
    result_vqe3 = pickle.load(f)
with open('/home/Mengzhen/signproblem/result/3h1111_all_vqe2_noise_new.pkl', 'rb') as f:
    result_vqe2 = pickle.load(f)
#%%
fig, axs = plt.subplots(3, 1, figsize=(6, 10), sharex=True)

def plot_history(ax, results, label):
    epoch = 0
    for epoch_data in results:
        history = epoch_data['history']
        ax.plot(history, label=f'Epoch {epoch}')
        epoch += 1
    ax.set_ylabel('Energy', fontsize=12)
    ax.legend()
    ax.grid(True, alpha=0.3)
    ax.hlines(round(min(u.real),4),0,200,linestyle=':',color='k')
    # ax.set_ylim(-5.5, 0.5)

plot_history(axs[0], result_vqnhe, 'vqnhe')
axs[0].set_title('sign-VQNHE', fontsize=14)

plot_history(axs[1], result_vqe3, 'vqe3')
axs[1].set_title('layered-VQE', fontsize=14)

plot_history(axs[2], result_vqe2, 'vqe2')
axs[2].set_title('standard-VQE', fontsize=14)
axs[2].set_xlabel('Iterations', fontsize=12)  

# plt.tight_layout()
plt.show()   


#%%
def compute_gradient_factor_corrected(grads,E, alpha, beta, edges_G, num_G):
    # grads = tf.cast(grads, dtype=tf.float32)
    num_vertices = len(grads[0])    
    neighbors = {k: [] for k in range(num_vertices)}
    for j, k in edges_G:
        neighbors[k].append(j)
        neighbors[j].append(k)  
    
    alpha_E_sq = alpha * E
    tanh_term = tf.tanh(alpha_E_sq)
    tanh_term_2 = tf.tanh(alpha_E_sq**2)
    sech_term = tf.square(1 / tf.cosh(alpha * E))    
    sech_term_2 = tf.square(1 / tf.cosh((alpha * E)**2))  
    sum_p_tanh = tf.reduce_sum(tanh_term_2)  
        
    grads_new = []
    for i in range(len(grads)):
        gn = 0
        for k in range(num_vertices):
            # Term1: 
            term1 = 0.0
            for j in neighbors[k]:
                # term1 += W[j, k] * tanh_term[j] * sech_term[k]
                term1 += tanh_term[j] * sech_term[k]
            term1 = alpha * term1             
            # Term2
            term2 = 4 * alpha * beta * num_G * E[k] / (num_vertices**2)
            term2 = term2 * sech_term_2[k] * sum_p_tanh  # sech^2(αE_k) * Σ_p tanh(αE_p^2)       
            gn = gn+tf.multiply(grads[i][k], term1 + term2)
        grads_new.append(gn)
    
    return grads_new

#%% molecular plot
# import pickle
# import matplotlib.pyplot as plt
# with open('/home/Mengzhen/signproblem/result/molecular_H2O_e3.pkl', 'rb') as f:
#     result_vqnhe = pickle.load(f)
    

epoch = 0
for epoch_data in result_vqnhe:
    # history = epoch_data['history']
    history = epoch_data['history']-min(u.real)
    plt.plot(history, label=f'Epoch {epoch}')
    epoch += 1
    
# plt.ylabel('Energy', fontsize=12)
plt.ylabel('dE', fontsize=12)
plt.xlabel('step', fontsize=12)
plt.legend()
plt.grid(True, alpha=0.3)
plt.yscale('log')
# plt.hlines(round(min(u.real),4),0,600,linestyle=':',color='k')










