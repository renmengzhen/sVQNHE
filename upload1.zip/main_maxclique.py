#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec  4 08:06:46 2025
max clique main
@author: Mengzhen
"""
import numpy as np
import pandas as pd
import math
import cmath
import tensorcircuit as tc
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
from qiskit_nature.drivers import UnitsType, Molecule
from qiskit_nature.drivers.second_quantization import (
    ElectronicStructureDriverType,
    ElectronicStructureMoleculeDriver,
)
from qiskit_nature.problems.second_quantization import ElectronicStructureProblem
from qiskit_nature.converters.second_quantization import QubitConverter
from qiskit_nature.mappers.second_quantization import JordanWignerMapper
from qiskit_nature.transformers.second_quantization.electronic import FreezeCoreTransformer, ActiveSpaceTransformer
# from qiskit.aqua.operators import WeightedPauliOperator
from qiskit.quantum_info import Pauli, state_fidelity, SparsePauliOp
import matplotlib.pyplot as plt
# from scipy.linalg import expm
from scipy.sparse.linalg import expm
from scipy import sparse
from scipy.optimize import minimize
import tensorflow as tf
import warnings
from functools import partial
import functools as ft
import pickle
# from keras.utils import plot_model
warnings.simplefilter(action='ignore', category=FutureWarning)
tc.set_backend("tensorflow")
tc.set_dtype("complex128")

def str2WeightedPaulis_H2D(H2D):
    h = []
    terms = H2D.split('+')
    for term in terms:
        if term:  
            term = term.strip('+')
            weight, pauli_str = term.split('*')
            pauli_list = [pauli for pauli in pauli_str if pauli in 'XYZI']
            weight = float(weight)
            h.append([weight] + [int(pauli == 'X') + 2*int(pauli == 'Y') + 3*int(pauli == 'Z') for pauli in pauli_list])
    return h

def str2WeightedPaulis(s):
	s = s.strip()
	IXYZ = ['I', 'X', 'Y', 'Z']
	prev_idx = 0
	coefs = []
	paulis = []
	is_coef = True
	for idx, c in enumerate(s + '+'):
		if idx == 0: continue
		if is_coef and c in IXYZ:
			coef = complex(s[prev_idx : idx].replace('i', 'j'))
			coefs.append(coef)
			is_coef = False
			prev_idx = idx
		if not is_coef and c in ['+', '-']:
			label = s[prev_idx : idx]
			paulis.append(Pauli(label))
			is_coef = True
			prev_idx = idx
	return SparsePauliOp(paulis,coefs)
dtype=np.complex128
X = np.array([[0, 1.0], [1.0, 0]], dtype=dtype)
Y = np.array([[0, -1j], [1j, 0]], dtype=dtype)
Z = np.array([[1, 0], [0, -1]], dtype=dtype)
I = np.array([[1, 0], [0, 1]], dtype=dtype)
             
def tran(tin):
    if tin=='I':
        return '0'
    if tin=='X':
        return '1'
    if tin=='Y':
        return '2'
    if tin=='Z':
        return '3'
    else:
        return tin
def Fedtest(ex,GS):
    SS=[]
    for x in GS:
        SS.append(state_fidelity(ex,w[:,x]))
    SS=np.array(SS)
    return SS
def mykron(ma, mb, *list):
    """
    :param ma: matrix a
    :param mb: matrix b
    :param *List: a set of matrices
    :return:  kron(ma,mb,list[0],....,list[n-1])
    """
    # k1=tran(ma).copy()
    # k2=tran(mb).copy()
    out = np.kron(ma,mb)
    if len(list) != 0:
        # print(out)
        out = mykron(out, *list)
    return out
def lshift(s,n):
    return s[n:]+s[:n]

def dtheta(params,H):
    N=np.size(params)
    A=np.zeros([N,N],dtype=np.complex128)
    C=np.zeros(N,dtype=np.complex128)
    dpdt=[]
    cp=1/np.sqrt(2)
    a=np.pi/2
    phi=E(params)
    for i in range(N):
        ptmp1=params.copy().reshape(-1)
        ptmp2=params.copy().reshape(-1)
        ptmp1[i]+=a
        ptmp2[i]-=a    
        dp=cp*(E(ptmp1.reshape(params.shape))-E(ptmp2.reshape(params.shape)))
        dpdt.append(dp)
    for i in range(N):
        for j in range(N):
            # phi=Lv(params,wavefunction)
            A[i,j]=(dpdt[i].conj().dot(dpdt[j])).real#+dpdt[i].conj().dot(phi)*dpdt[j].conj().dot(phi)
    for i in range(N):
        # phi=Lv(params,wavefunction)
        C[i]=(dpdt[i].conj().dot(H.dot(phi))).real
    dx=np.linalg.pinv(A.real).dot(-C)
    return dx.real

def commutator(A,B):
    return A.dot(B)-B.dot(A)

def anticommutator(A,B):
    return A.dot(B)+B.dot(A)

def convert_sparse_matrix_to_sparse_tensor(X):
    coo = X.tocoo()
    indices = np.mat([coo.row, coo.col]).transpose()
    return tf.SparseTensor(indices, coo.data, coo.shape)

def Mtheta(theta):
    M=tc.Circuit(nqu)
    j=0
    for i in range(nqu):
        M.rx(i,theta=theta[j])
        j+=1
    for i in range(nqu):
        M.ry(i,theta=theta[j]) 
        j+=1
    return M.matrix().numpy()

def E(theta):
    u=cir(theta).state()
    return u.numpy()

def EN(v,H):
    # v=E(theta)
    return (v.conj().dot(H.dot(v))).real
# def sexpm(H):
#     I=H.copy()
#     I[I!=0]=0
#     return I-H+0.5*H.dot(H)
def cost(theta,H):
    v=E(theta)
    return EN(v,H)
    # return 1-state_fidelity(v, w[:,GS])

# def mS(theta):
#     u=E(theta)
#     v=w[:,GS].reshape(-1)
#     wh=v.conj()*v
#     u=wh*u
#     u/=np.sqrt(u.conj().dot(u))
#     return state_fidelity(u, w[:,GS])

def mS(u):
    # u=E(theta)
    v=w[:,GS].reshape(-1)
    wh=v.conj()*v
    u=wh*u
    u/=np.sqrt(u.conj().dot(u))
    return state_fidelity(u, w[:,GS])

def mA(theta):
    u=E(theta)
    u=u.conj()*(u)
    u/=np.sqrt(u)
    v=w[:,GS].reshape(-1)
    wh=v.conj()*v
    wh/=np.sqrt(wh)
    return state_fidelity(u, wh)

def eS(w,H):
    wh=abs(w.reshape(-1))
    u=np.ones(len(wh))
    u=w.reshape(-1)/wh*u
    u/=np.sqrt(u.conj().dot(u))
    return u.conj().dot(H.dot(u))

def S(H):
    Hp=H.copy()
    I=H*0
    I.setdiag(1)
    Hp[Hp<0]=0
    Hp.setdiag(0)
    
    Hn=H.copy()
    Hn[Hn>0]=0
    Hn.setdiag(H.diagonal())
    Hb=Hn-Hp
    # eHb=expm(-Hb)
    # eH=expm(-H)
    # eHb=I-0.1*Hb+0.01*Hb.dot(Hb)
    # eH=I-0.1*H+0.01*H.dot(H)
    return Hp

#%% max clique Heisenberg (power 2/3/4)
import numpy as np
from itertools import combinations

dist = [1, 1, 1, 1]
d = dist[1:]  
h = dist[0]   
J = d * h     

na = 10
nb = 1
n = na * nb

edge = list(combinations(range(n), 2)) # power

H2D = ""
H2D1 = ""
# X→Y→Z 
for pauli, coeff in zip(["X", "Y", "Z"], J):
    for nodes in edge:
        term = ["I"] * n
        for node in nodes:
            term[node] = pauli
        H2D += f"+{coeff}*{''.join(term)}"

for pauli, coeff in zip(["X", "Y", "Z"], J):
    for nodes in edge:
        term = ["I"] * n
        for node in nodes:
            term[node] = pauli
        H2D1 += f"+{coeff}{''.join(term)}"
        
#%% max clique
import networkx as nx
def initial_param(t, theta=None, a=None, weights=None):
    return weights
def ry_gate(theta):
    return tf.convert_to_tensor([
        [tf.cos(theta / 2), -tf.sin(theta / 2)],
        [tf.sin(theta / 2), tf.cos(theta / 2)]
    ], dtype=tf.float32)
def tensor_product_gates(*gates):
    operators = [tf.linalg.LinearOperatorFullMatrix(gate) for gate in gates]
    result = tf.linalg.LinearOperatorKronecker(operators)
    return result.to_dense()
    
        
# def maxclique_test(G, solution_sign):
#     graph_edges = G.edges() 
#     num_vertices = len(G.nodes())
#     in_clique = [i for i, sign in enumerate(solution_sign) if sign > 0.15]
    
#     is_valid = True
#     for i in range(len(in_clique)):
#         for j in range(i+1, len(in_clique)):
#             v1, v2 = in_clique[i], in_clique[j]
#             if (v1, v2) not in graph_edges and (v2, v1) not in graph_edges:
#                 is_valid = False

    
#     clique_size = len(in_clique)

#     return clique_size, is_valid, in_clique


def maxclique_test(G, solution_sign, mode="adaptive", alpha=0.1):
    scores = np.array(solution_sign)
    n = len(scores)
    if mode == "adaptive":
        mu, sigma = np.mean(scores), np.std(scores)
        if sigma == 0:  
            threshold = mu
        else:
            threshold = mu + alpha * sigma
        candidates = [i for i, s in enumerate(scores) if s >= threshold]     
    elif mode == "original":
        candidates = [i for i, s in enumerate(scores) if s >= 0.5]     
    else:
        raise ValueError("mode must be adaptive")

    if len(candidates) <= 1:
        return len(candidates), True, candidates.tolist()
    H = G.subgraph(candidates).copy()  
    # Bron–Kerbosch with pivoting
    # find_cliques 
    max_clique = []
    max_size = 0
    
    for clique in nx.find_cliques(H):          
        if len(clique) > max_size:
            max_size = len(clique)
            max_clique = clique

    max_clique = sorted(max_clique)
    
    return max_size, True, max_clique, len(candidates)
# edge = list(combinations(range(n), 2))  
# G = nx.erdos_renyi_graph(n=135, p=0.5)
# node_G = len(G.nodes())
# edges_G = G.edges()    

#%% svqnhe benchmark, max clique(power 2/3/4)
import os
from tensorcircuit.applications.vqes import VQNHE, JointSchedule

save_dir = "/home/Mengzhen/signproblem/result/maxclique_results_g1485/"
# graph_filename = os.path.join(save_dir, f"maxcut_graph_n{n_l}_idx{i}.pkl")
# with open(graph_filename, "wb") as f:
#     pickle.dump(G, f)

#n_list = [135, 570, 1305] # qubit 10, 20, 30
# n_list = [630]
# n_list = [1485]
n_list = [135]
num_graphs = 1

H=str2WeightedPaulis(H2D1).to_matrix(sparse=1)
u,w=sparse.linalg.eigs(H,k=4,which='SR')
GS=np.where(abs(u-min(u))<1e-5)[0]
wh=abs(w[:,GS].reshape(-1))
wh/=np.sqrt(wh.conj().dot(wh))
h0=convert_sparse_matrix_to_sparse_tensor(H)
h = str2WeightedPaulis_H2D(H2D)
max_epochs = 2
gradient_threshold = 1e-3

svqnhe_cut_results = {}

for n_l in n_list:
    for i in range(num_graphs):
        i = i+2
        # load graph
        graph_filename = os.path.join(save_dir, f"random_n{n_l}_p{0.5}_i{i}.pkl")
        with open(graph_filename, "rb") as f:
            G = pickle.load(f)
        node_G = len(G.nodes())
        edges_G = G.edges()  
        # svqnhe
        epoch = 1
        previous_f2 = None
        # theta_ry = np.ones(n) * 0.5 * np.pi # hea4, svqnhe
        theta_ry = np.array([]) # hea0, ry HEA
        theta_rz = np.array([]) 
        best_histories = []
        pretrained_weights = None
        previous_best_f2 = []
        best_results_all = []
        Eny = [0]
        while epoch <= max_epochs:
            fq = list(range(n))       
            if previous_f2 is not None:
                thetas = tf.Variable(np.random.rand(n) * 2 * np.pi - np.pi, dtype=tf.float32)
                optimizer = tf.keras.optimizers.Adam(learning_rate=0.01)
                previous_f2_real = tf.cast(tf.math.real(previous_f2), tf.float32)
                # complex
                # previous_f2_real = tf.cast(tf.abs(previous_f2), tf.float32)
                # Optimization loop to match previous f2
                for _ in range(1000):  # 1000,1500
                    with tf.GradientTape() as tape:
                        ry_gates = [ry_gate(theta) for theta in thetas]
                        C_y = tensor_product_gates(*ry_gates)
                        loss = tf.reduce_sum(tf.abs(C_y - tf.linalg.diag(previous_f2_real)) ** 2)            
                    gradients = tape.gradient(loss, thetas)
                    if gradients is not None:
                        optimizer.apply_gradients([(gradients, thetas)])                
                theta_ry = np.concatenate([theta_ry, thetas.numpy()])
                print(f"\nComplete training of theta_ry")
                
                pretrain_tries = 1
                best_pretrain_energy = float('inf')
                best_pretrain_weights = None        
                print(f"\nPre-training neural network for epoch {epoch}")        
                for pretrain_idx in range(pretrain_tries):
                    print(f"Pre-training attempt {pretrain_idx + 1}/{pretrain_tries}")           
                    vqeinstance_pretrain = VQNHE(
                        node_G,
                        edges_G,
                        theta_ry,
                        theta_rz,
                        n,
                        h0,
                        h,
                        # {"depth": 3, "width": 6, "choose": "real"},
                        {"depth": 3, "width": 10, "choose": "real"},
                        # {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea4"},
                        {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea0"},
                        shortcut=False,
                    )
            
                    # t = n + len(edge)  # hea4, svqnhe
                    t = 6*n # hea0, ry 6-HEA 
                    zero_theta = np.zeros(t)
                    
                    init_dict = {
                        "q": tf.Variable(zero_theta),
                        "c": None
                    }
                    
                    rs_pretrain = vqeinstance_pretrain.multi_training(
                        tries=1,
                        maxiter=150, #150,200,300
                        threshold=1E-7 * 0.5,
                        onlyq=0,
                        debug=50,
                        qon=0,
                        initialization_func=lambda try_idx: init_dict
                    )
                        
                    current_pretrain_energy = rs_pretrain[0]['history'][-1]

                    if current_pretrain_energy < best_pretrain_energy:
                        best_pretrain_energy = current_pretrain_energy
                        best_pretrain_weights = rs_pretrain[0]['model_weights']
                        print(f"New best pre-training energy: {best_pretrain_energy}")
                
                print(f"\nBest pre-training energy achieved: {best_pretrain_energy}")
                pretrained_weights = best_pretrain_weights
            
            num_tries = 1
            best_energy = float('inf')
            best_results = None
            best_circuit = None
            best_history_current_epoch = None
            
            print(f"\nStarting main training for Epoch {epoch}")
            
            for try_idx in range(num_tries):
                print(f"Epoch {epoch}, Try {try_idx + 1}/{num_tries}")
                
                vqeinstance = VQNHE(
                    node_G,
                    edges_G,
                    theta_ry,
                    theta_rz,
                    n,
                    h0,
                    h,
                    # {"depth": 3, "width": 6, "choose": "real"},
                    {"depth": 3, "width": 10, "choose": "real"},
                    # {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea4"},
                    {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea0"},
                    shortcut=False,
                )
                
                cir = vqeinstance.circuit
                # t = n + len(edge)  # hea4, svqnhe
                t = 6*n # hea0, ry 6-HEA  
                theta = (np.random.rand(t)-0.5)*2*np.pi
                init_params = {"q": tf.Variable(theta)}
                if pretrained_weights is not None:
                    init_params["c"] = pretrained_weights
                test = int(30+540*(epoch-1))
                # test = int(30+440*(epoch-1))
                rs1 = vqeinstance.multi_training(
                    tries=1,
                    maxiter=test, 
                    threshold=1E-7 * 0.5,
                    onlyq=0,
                    debug=30,
                    qon=test,
                    initialization_func=partial(initial_param, weights=init_params)
                )
                
                current_energy = rs1[0]['history'][-1]
                
                if current_energy < best_energy:
                    best_energy = current_energy
                    best_results = rs1[0]
                    best_circuit = vqeinstance
                    best_history_current_epoch = rs1[0]['history']
                    print(f"New best energy in epoch {epoch}: {best_energy}")
            
            best_histories.append({
                'epoch': epoch,
                'history': best_history_current_epoch,
                'final_energy': best_energy,
                'model_weights': best_results['model_weights'],
                'pretrained_weights': pretrained_weights  
            })
            
            Eny.append(best_energy)
            previous_f2 = best_results['amp_f2'][-1]
            previous_best_f2.append(previous_f2)
            best_results_all.append(best_results)
            
            if len(Eny) > 1:
                gradient = np.abs(np.gradient(Eny)).mean()
                if gradient > gradient_threshold:
                    qv = best_results_all[-1]['qgrad'][-1]
                    theta_rz = np.concatenate([theta_rz, qv])
                    epoch += 1
                    print(f"Gradient {gradient:.2e} greater than threshold, increasing epoch to {epoch}")
                    print(f"Current theta_rz shape: {theta_rz.shape}")
                else:
                    break
            else:
                break
        
        # result_hist = best_results_all[-1]['history']
        # min_index = result_hist.index(min(result_hist))
        # result_vqnhe = best_results_all[-1]['sign'][min_index]
        result_vqnhe = best_results_all[-1]['sign'][-1]
        
        clique_size, is_valid, vertices, size = maxclique_test(G, result_vqnhe)
        # clique_size, is_valid, vertices, size = maxclique_test(G, result_vqnhe,mode="original")
        
        print(f"n={n_l}, graph {i+1}/{num_graphs}, clique={clique_size}, is_valid={is_valid}")
# with open('/home/Mengzhen/signproblem/result/maxclique_results_g1485/alpha1_n135_p0.5_i2_hea0-6.pkl', 'wb') as f:
#     pickle.dump(best_results_all, f)
#%% load
n_l = 135
fa = 1
i=0
graph_filename = os.path.join(save_dir, f"random_n{n_l}_p{0.5}_i{i}.pkl")
with open(graph_filename, "rb") as f:
    G = pickle.load(f)
filename = os.path.join(save_dir, f"alpha{fa}_n135_p0.5_i{i}.pkl")
filename_nn = os.path.join(save_dir, f"alpha{fa}_n135_p0.5_i{i}_nn.pkl")
with open(filename, "rb") as f:
    result_all = pickle.load(f)
with open(filename_nn, "rb") as f:
    result_all_nn = pickle.load(f)

solution_sign = result_all[-1]['sign'][-1]
solution_nn = result_all_nn[-1]['sign'][-1]

if fa<=10:
    clique_size, _, vertices, size = maxclique_test(G, solution_sign, mode="adaptive")
    clique_size_nn, _, vertices_nn, size_nn = maxclique_test(G, solution_nn, mode="adaptive")
else:
    clique_size, _, vertices, size = maxclique_test(G, solution_sign,mode="original")
    clique_size_nn, _, vertices_nn, size_nn = maxclique_test(G, solution_nn,mode="original")

print(f"svqnhe: graph={i}, factor={fa}, clique={clique_size}, ratio = {clique_size/size}")

print(f"nn: graph={i}, factor={fa}, clique={clique_size_nn}, ratio = {clique_size_nn/size_nn}")


#%%
def find_max_clique_in_induced_subgraph(G, candidate_vertices):

    from collections import defaultdict
    
    if not candidate_vertices:
        return [], True
    
 
    candidates = set(candidate_vertices)
    adjacency = {v: set() for v in candidate_vertices}
    
    for v in candidate_vertices:
        for neighbor in G.neighbors(v):
            if neighbor in candidates:
                adjacency[v].add(neighbor)
    
    # Bron-Kerbosch
    def bron_kerbosch(R, P, X, best_solution):
        if not P and not X:
            if len(R) > len(best_solution[0]):
                best_solution[0] = list(R)
            return

        pivot = None
        max_degree = -1
        for v in P.union(X):
            if len(adjacency[v]) > max_degree:
                max_degree = len(adjacency[v])
                pivot = v

        for v in list(P - adjacency.get(pivot, set())):

            bron_kerbosch(
                R.union({v}),
                P.intersection(adjacency[v]),
                X.intersection(adjacency[v]),
                best_solution
            )

            P.remove(v)
            X.add(v)

    best_solution = [[]]
    bron_kerbosch(set(), set(candidates), set(), best_solution)
    
    return best_solution[0], True   
def find_valid_clique_heuristic(G, candidate_vertices, time_limit=1.0):
    import time
    start_time = time.time()

    if len(candidate_vertices) <= 20:
        return find_max_clique_in_induced_subgraph(G, candidate_vertices)
    
    # greedy
    sorted_vertices = sorted(candidate_vertices, 
                           key=lambda v: G.degree(v), 
                           reverse=True)

    initial_clique = []
    for v in sorted_vertices:
        if all(G.has_edge(v, u) for u in initial_clique):
            initial_clique.append(v)
    
    best_clique = initial_clique.copy()

    while time.time() - start_time < time_limit:
        improved = False

        remaining = [v for v in candidate_vertices if v not in best_clique]
        for v in remaining:
            if all(G.has_edge(v, u) for u in best_clique):
                best_clique.append(v)
                improved = True
                break

        if not improved and len(best_clique) >= 3:
            for i in range(len(best_clique)):
                for new_v in remaining:

                    temp = best_clique.copy()
                    temp.pop(i)
                    temp.append(new_v)

                    if is_clique_valid(G, temp):
                        if len(temp) > len(best_clique) or \
                           (len(temp) == len(best_clique) and 
                            sum(G.degree(v) for v in temp) > sum(G.degree(v) for v in best_clique)):
                            best_clique = temp
                            improved = True
                            break
                if improved:
                    break

        if not improved:
            break
    
    return best_clique, True


def is_clique_valid(G, vertices):
    n = len(vertices)
    if n <= 1:
        return True
    
    vertex_set = set(vertices)
    for i in range(n):
        v = vertices[i]

        neighbors = set(G.neighbors(v))
        for j in range(i+1, n):
            if vertices[j] not in neighbors:
                return False
    return True


def maxclique_test_with_postprocessing(G, solution_sign, method='heuristic'):
    graph_edges = G.edges() 
    num_vertices = len(G.nodes())
    candidate_vertices = [i for i, sign in enumerate(solution_sign) if sign > 0]

    is_valid_original = True
    for i in range(len(candidate_vertices)):
        for j in range(i+1, len(candidate_vertices)):
            v1, v2 = candidate_vertices[i], candidate_vertices[j]
            if not G.has_edge(v1, v2):
                is_valid_original = False
                break
        if not is_valid_original:
            break
    
    original_clique_size = len(candidate_vertices)

    if not is_valid_original and candidate_vertices:
        if method == 'exact':
            valid_clique, _ = find_max_clique_in_induced_subgraph(G, candidate_vertices)
        else:  # 'heuristic'
            valid_clique, _ = find_valid_clique_heuristic(G, candidate_vertices)
        
        valid_clique_size = len(valid_clique)
        is_valid_postprocessed = True

        return {
            'original': {
                'clique_size': original_clique_size,
                'is_valid': is_valid_original
                # 'vertices': candidate_vertices
            },
            'postprocessed': {
                'clique_size': valid_clique_size,
                'is_valid': is_valid_postprocessed,
                # 'vertices': valid_clique,
                'method': method
            },
            'improvement': valid_clique_size - original_clique_size if not is_valid_original else 0
        }
    else:
        return {
            'original': {
                'clique_size': original_clique_size,
                'is_valid': is_valid_original,
                'vertices': candidate_vertices
            },
            'postprocessed': None,
            'improvement': 0
        }   
    
maxclique_test_with_postprocessing(G, result_vqnhe, method='heuristic')    
    
    
    
    
    
    
    