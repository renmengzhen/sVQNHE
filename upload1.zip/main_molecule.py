#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 15 09:10:25 2025

main molecules, exact_large

@author: Mengzhen
"""
import numpy as np
import pandas as pd
import math
import cmath
import tensorcircuit as tc
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
from qiskit_nature.drivers import UnitsType, Molecule
from qiskit_nature.drivers.second_quantization import (
    ElectronicStructureDriverType,
    ElectronicStructureMoleculeDriver,
)
from qiskit_nature.mappers.second_quantization import ParityMapper
from qiskit_nature.problems.second_quantization import ElectronicStructureProblem
from qiskit_nature.converters.second_quantization import QubitConverter
from qiskit_nature.mappers.second_quantization import JordanWignerMapper
from qiskit_nature.transformers.second_quantization.electronic import FreezeCoreTransformer
from qiskit_nature.second_q.drivers import PySCFDriver
from qiskit_nature.units import DistanceUnit
from qiskit_nature.second_q.transformers import ActiveSpaceTransformer
# from qiskit.aqua.operators import WeightedPauliOperator
from qiskit.quantum_info import Pauli, state_fidelity, SparsePauliOp
import matplotlib.pyplot as plt
# from scipy.linalg import expm
from scipy.sparse.linalg import expm
from scipy import sparse
from scipy.optimize import minimize
import tensorflow as tf
import warnings
from functools import partial
import functools as ft
import pickle
import os
# from keras.utils import plot_model
warnings.simplefilter(action='ignore', category=FutureWarning)
tc.set_backend("tensorflow")
tc.set_dtype("complex128")

def convert_sparse_matrix_to_sparse_tensor(X):
    coo = X.tocoo()
    indices = np.mat([coo.row, coo.col]).transpose()
    return tf.SparseTensor(indices, coo.data, coo.shape)

#%% molecular
def H2O_geom(r_oh, angle_hoh_deg):
    """
    Build the water Hamiltonian for a given O–H bond length and H–O–H bond angle.
    - r_oh: O–H bond length (Angstrom)
    - angle_hoh_deg: H–O–H bond angle in degrees
    Geometry convention: O at origin; molecule lies in the y–z plane;
    H atoms are placed symmetrically at ±y with same positive z.
    """
    half_angle_rad = math.radians(angle_hoh_deg / 2.0)
    y = r_oh * math.sin(half_angle_rad)
    z = r_oh * math.cos(half_angle_rad)
    molecule = Molecule(
        geometry=[["O", [0.0, 0.0, 0.0]], ["H", [0.0, -y, z]], ["H", [0.0, y, z]]],
        charge=0,
        multiplicity=1,
        units=UnitsType.ANGSTROM,
    )
    driver = ElectronicStructureMoleculeDriver(
        molecule, basis="sto-3g", driver_type=ElectronicStructureDriverType.PYSCF,
    )
    es_problem = ElectronicStructureProblem(driver)
    second_q_op = es_problem.second_q_ops()
    qubit_converter = QubitConverter(mapper=JordanWignerMapper())
    qubit_op = qubit_converter.convert(second_q_op['ElectronicEnergy'])
    return qubit_op.to_spmatrix()

def H2O_geom_reduced(r, angle_deg,freeze_core=True, num_active_electrons=None, num_active_orbitals=None, use_parity_two_qubit_reduction=True):

    half_angle = math.radians(angle_deg / 2)
    y = r * math.sin(half_angle)
    z = r * math.cos(half_angle)
    
    molecule = Molecule(
        geometry=[["O", [0.0, 0.0, 0.0]], ["H", [0.0, -y, z]], ["H", [0.0, y, z]]],
        charge=0,
        multiplicity=1,
        units=UnitsType.ANGSTROM,
    )
    driver = ElectronicStructureMoleculeDriver(
        molecule, basis="sto-3g", driver_type=ElectronicStructureDriverType.PYSCF,
    )

    transformers = []
    if freeze_core:
        transformers.append(FreezeCoreTransformer())
    if (num_active_electrons is not None) and (num_active_orbitals is not None):
        transformers.append(ActiveSpaceTransformer(num_electrons=num_active_electrons, num_spatial_orbitals=num_active_orbitals))

    es_problem = ElectronicStructureProblem(driver, transformers=transformers)

    second_q_op = es_problem.second_q_ops()

    # Prefer parity mapping with two-qubit reduction to cut 2 qubits when applicable
    if use_parity_two_qubit_reduction:
        qubit_converter = QubitConverter(mapper=ParityMapper(), two_qubit_reduction=True)
        qubit_op = qubit_converter.convert(second_q_op['ElectronicEnergy'], num_particles=es_problem.num_particles)
    else:
        qubit_converter = QubitConverter(mapper=JordanWignerMapper())
        qubit_op = qubit_converter.convert(second_q_op['ElectronicEnergy'])

    return qubit_op.to_spmatrix()

    

def scan_H2O_energy_surface(r_list, angle_list_deg, method="exact"):
    """
    Compute ground-state energies for a grid of O–H bond lengths and H–O–H angles.
    - r_list: iterable of O–H bond lengths (Angstrom)
    - angle_list_deg: iterable of angles in degrees
    - method: "exact" uses sparse eigensolver to get the lowest eigenvalue
    Returns a pandas DataFrame with columns: r_oh, angle_deg, energy_hartree
    """
    results_e = []
    results_v = []
    for r in r_list:
        for angle_deg in angle_list_deg:
            # H = H2O_geom(r, angle_deg)
            H = H2O_geom_reduced(r, angle_deg)
            if method == "exact":
                try:
                    # Use Hermitian solver for ground energy
                    e, v = sparse.linalg.eigsh(H, k=1, which='SA')
                    e0 = float(np.real(e[0]))
                    psi0 = v[:, 0]
                except Exception:
                    # Fallback if eigsh fails (non-Hermitian numerical issues)
                    e, v = sparse.linalg.eigs(H, k=1, which='SR')
                    e0 = float(np.real(e[0]))
                    psi0 = v[:, 0]
            else:
                raise ValueError("Unsupported method for scanning: {}".format(method))
            results_e.append({"r_oh": r, "angle_deg": angle_deg, "energy_hartree": e0})
            results_v.append(psi0)
    return pd.DataFrame(results_e),results_v

#%% plot test
r_list = np.round(np.linspace(0.8, 1.2, 3),1)
angle_list = np.round(np.linspace(90, 120, 3))
df,wave_list = scan_H2O_energy_surface(r_list, angle_list)
print(df.head())


df_plot = df.sort_values(["r_oh", "angle_deg"])

plt.figure(figsize=(6,4))
for r in sorted(df_plot["r_oh"].unique()):
    sub = df_plot[df_plot["r_oh"].eq(r)]
    plt.plot(sub["angle_deg"], sub["energy_hartree"], marker="o", label=f"r={r:.1f} Å")

plt.xlabel("H–O–H angle (deg)")
plt.ylabel("Energy (Hartree)")  
# plt.title("H2O energy (STO-3G) vs angle (slices at fixed O–H bond length (Å))")
plt.legend(ncol=2, fontsize=8)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.show()

#%% svqnhe, nn
def initial_param(t, theta=None, a=None, weights=None):
    return weights
def ry_gate(theta):
    return tf.convert_to_tensor([
        [tf.cos(theta / 2), -tf.sin(theta / 2)],
        [tf.sin(theta / 2), tf.cos(theta / 2)]
    ], dtype=tf.float32)
def tensor_product_gates(*gates):
    operators = [tf.linalg.LinearOperatorFullMatrix(gate) for gate in gates]
    result = tf.linalg.LinearOperatorKronecker(operators)
    return result.to_dense()

from tensorcircuit.applications.vqes import VQNHE, JointSchedule
n = 10
# edge=[]
# for i in range(n-1):
#     edge.append([i,i+1])
from itertools import combinations
edge=list(combinations(range(n), 2))

max_epochs = 1
gradient_threshold = 1e-3

# r_list = np.round(np.linspace(0.8, 1.2, 3),1)
r_list = [1.2]
angle_list = np.round(np.linspace(90, 120, 3))
save_dir = "/home/Mengzhen/signproblem/result/reduced_H2O/more"

for r in r_list:
    for angle_deg in angle_list:
        # H = H2O_geom(r, angle_deg)
        H = H2O_geom_reduced(r, angle_deg)
        h0=convert_sparse_matrix_to_sparse_tensor(H)
        # svqnhe
        epoch = 1
        previous_f2 = None
        theta_ry = np.ones(n) * 0.5 * np.pi   
        # theta_ry = np.random.rand(n) * 0.5 * np.pi * 0.01
        theta_rz = np.array([]) 
        best_histories = []
        pretrained_weights = None
        previous_best_f2 = []
        best_results_all = []
        Eny = [0]
        while epoch <= max_epochs:
            fq = list(range(n))       
            if previous_f2 is not None:
                thetas = tf.Variable(np.random.rand(n) * 2 * np.pi - np.pi, dtype=tf.float32)
                optimizer = tf.keras.optimizers.Adam(learning_rate=0.01)
                previous_f2_real = tf.cast(tf.math.real(previous_f2), tf.float32)
                # complex
                # previous_f2_real = tf.cast(tf.abs(previous_f2), tf.float32)
                # Optimization loop to match previous f2
                for _ in range(200):  # 1000,1500
                    with tf.GradientTape() as tape:
                        ry_gates = [ry_gate(theta) for theta in thetas]
                        C_y = tensor_product_gates(*ry_gates)
                        loss = tf.reduce_sum(tf.abs(C_y - tf.linalg.diag(previous_f2_real)) ** 2)            
                    gradients = tape.gradient(loss, thetas)
                    if gradients is not None:
                        optimizer.apply_gradients([(gradients, thetas)])                
                theta_ry = np.concatenate([theta_ry, thetas.numpy()])
                print(f"\nComplete training of theta_ry")
                
                pretrain_tries = 1
                best_pretrain_energy = float('inf')
                best_pretrain_weights = None        
                print(f"\nPre-training neural network for epoch {epoch}")        
                for pretrain_idx in range(pretrain_tries):
                    print(f"Pre-training attempt {pretrain_idx + 1}/{pretrain_tries}")           
                    vqeinstance_pretrain = VQNHE(
                        # num_G,
                        # edges_G,
                        theta_ry,
                        theta_rz,
                        n,
                        h0,
                        # h,
                        {"depth": 3, "width": 6, "choose": "real"},
                        # {"depth": 3, "width": 10, "choose": "real"},
                        # {"depth": 3, "width": 6, "choose": "complex"},
                        # {"width":2, "stddev": 0.01, "choose": "complex-rbm",
                         # "current_epoch": epoch}, 
                        # {"depth": 3, "width": 6, "choose": "complex", "current_epoch": epoch},
                        # {"width":256, "stddev": 0.01, "choose": "complex-rbm"},
                        # {"width":10, "set_depth":2, "stddev": 0.01, "choose": "complex-rbm"},
                        {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea4"},
                        shortcut=False,
                    )
            
                    t = n + len(edge)
                    zero_theta = np.zeros(t)
                    
                    init_dict = {
                        "q": tf.Variable(zero_theta),
                        "c": None
                    }
                    
                    rs_pretrain = vqeinstance_pretrain.multi_training(
                        tries=1,
                        maxiter=100, #150,200,300
                        threshold=1E-7 * 0.5,
                        onlyq=0,
                        debug=50,
                        qon=0,
                        initialization_func=lambda try_idx: init_dict
                    )
                        
                    current_pretrain_energy = rs_pretrain[0]['history'][-1]

                    if current_pretrain_energy < best_pretrain_energy:
                        best_pretrain_energy = current_pretrain_energy
                        best_pretrain_weights = rs_pretrain[0]['model_weights']
                        print(f"New best pre-training energy: {best_pretrain_energy}")
                
                print(f"\nBest pre-training energy achieved: {best_pretrain_energy}")
                pretrained_weights = best_pretrain_weights
            
            num_tries = 1
            best_energy = float('inf')
            best_results = None
            best_circuit = None
            best_history_current_epoch = None
            
            print(f"\nStarting main training for Epoch {epoch}")
            
            for try_idx in range(num_tries):
                print(f"Epoch {epoch}, Try {try_idx + 1}/{num_tries}")
                
                vqeinstance = VQNHE(
                    # num_G,
                    # edges_G,
                    theta_ry,
                    theta_rz,
                    n,
                    h0,
                    # h,
                    {"depth": 3, "width": 6, "choose": "real"},
                    # {"depth": 3, "width": 10, "choose": "real"},
                    # {"depth": 3, "width": 6, "choose": "complex"},
                    # {"width":2, "stddev": 0.01, "choose": "complex-rbm",
                     # "current_epoch": epoch}, 
                    # {"depth": 3, "width": 6, "choose": "complex", "current_epoch": epoch},
                    # {"width":256, "stddev": 0.01, "choose": "complex-rbm"},
                    # {"width":10, "set_depth":2, "stddev": 0.01, "choose": "complex-rbm"},
                    {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea4"},
                    shortcut=False,
                )
                
                cir = vqeinstance.circuit
                t = n + len(edge)  
                theta = (np.random.rand(t)-0.5)*2*np.pi
                # if previous_f2 is not None:
                #     theta = np.zeros(t)
                # else:
                #     theta = (np.random.rand(t)-0.5)*2*np.pi

                init_params = {"q": tf.Variable(theta)}
                if pretrained_weights is not None:
                    init_params["c"] = pretrained_weights
                test = int(50+400*(epoch-1))
                rs1 = vqeinstance.multi_training(
                    tries=1,
                    maxiter=500, 
                    threshold=1E-7 * 0.5,
                    onlyq=0,
                    debug=50,
                    qon=0,
                    initialization_func=partial(initial_param, weights=init_params)
                )
                
                current_energy = rs1[0]['history'][-1]
                
                if current_energy < best_energy:
                    best_energy = current_energy
                    best_results = rs1[0]
                    best_circuit = vqeinstance
                    best_history_current_epoch = rs1[0]['history']
                    print(f"New best energy in epoch {epoch}: {best_energy}")
            
            best_histories.append({
                'epoch': epoch,
                'history': best_history_current_epoch,
                'final_energy': best_energy,
                'model_weights': best_results['model_weights'],
                'pretrained_weights': pretrained_weights  
            })
            
            Eny.append(best_energy)
            previous_f2 = best_results['amp_f2'][-1]
            previous_best_f2.append(previous_f2)
            best_results_all.append(best_results)
            
            if len(Eny) > 1:
                gradient = np.abs(np.gradient(Eny)).mean()
                if gradient > gradient_threshold:
                    qv = best_results_all[-1]['qgrad'][-1]
                    theta_rz = np.concatenate([theta_rz, qv])
                    epoch += 1
                    print(f"Gradient {gradient:.2e} greater than threshold, increasing epoch to {epoch}")
                    print(f"Current theta_rz shape: {theta_rz.shape}")
                else:
                    break
            else:
                break
   
        filename = f"4_q10_r{r}_angle{angle_deg}_nn36r.pkl"
        filepath = os.path.join(save_dir, filename)
        with open(filepath, 'wb') as f:
            pickle.dump(best_results_all, f)
        
#%% vqe (HEA3)
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
def initial_param(t, theta=None, a=None, weights=None):
    return weights
n = 10
# edge=[]
# for i in range(n-1):
#     edge.append([i,i+1])
from itertools import combinations
edge=list(combinations(range(n), 2))

max_epochs = 3

# r_list = np.round(np.linspace(0.8, 1.2, 3),1)
r_list = [1.2]
angle_list = np.round(np.linspace(90, 120, 3))
save_dir = "/home/Mengzhen/signproblem/result/reduced_H2O/more"

for r in r_list:
    for angle_deg in angle_list:
        # H = H2O_geom(r, angle_deg)
        H = H2O_geom_reduced(r, angle_deg)
        h0=convert_sparse_matrix_to_sparse_tensor(H)
        # vqe
        epoch = 3 #(HEA2, ansatz hea0)
        previous_f2 = None
        theta_ry = np.ones(n) * 0.5 * np.pi   
        # theta_ry = np.random.rand(n) * 0.5 * np.pi * 0.01
        theta_rz = np.array([]) 
        best_histories = []
        pretrained_weights = None
        previous_best_f2 = []
        best_results_all = []
        Eny = [0]
        fq = list(range(n))
        while epoch <= max_epochs:            
            num_tries = 1
            best_energy = float('inf')
            best_results = None
            best_circuit = None
            best_history_current_epoch = None
            
            print(f"\nStarting main training for Epoch {epoch}")
            
            for try_idx in range(num_tries):
                print(f"Epoch {epoch}, Try {try_idx + 1}/{num_tries}")
                
                vqeinstance = VQNHE(
                    # num_G,
                    # edges_G,
                    theta_ry,
                    theta_rz,
                    n,
                    h0,
                    # h,
                    {"depth": 3, "width": 6, "choose": "real"},
                    # {"depth": 3, "width": 10, "choose": "real"},
                    # {"depth": 3, "width": 6, "choose": "complex"},
                    # {"width":2, "stddev": 0.01, "choose": "complex-rbm",
                     # "current_epoch": epoch}, 
                    # {"depth": 3, "width": 6, "choose": "complex", "current_epoch": epoch},
                    # {"width":256, "stddev": 0.01, "choose": "complex-rbm"},
                    # {"width":10, "set_depth":2, "stddev": 0.01, "choose": "complex-rbm"},
                    {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea0"},
                    shortcut=False,
                )
                
                cir = vqeinstance.circuit
                t = 2*n + epoch*(3*n-1)  
                theta = (np.random.rand(t)-0.5)*2*np.pi
                # if previous_f2 is not None:
                #     theta = np.zeros(t)
                # else:
                #     theta = (np.random.rand(t)-0.5)*2*np.pi

                init_params = {"q": tf.Variable(theta)}
                if pretrained_weights is not None:
                    init_params["c"] = pretrained_weights
                # test = int(50+400*(epoch-1))
                rs1 = vqeinstance.multi_training(
                    tries=1,
                    maxiter=500, 
                    threshold=1E-7 * 0.5,
                    onlyq=500,
                    debug=50,
                    qon=0,
                    initialization_func=partial(initial_param, weights=init_params)
                )
                
                current_energy = rs1[0]['history'][-1]
                
                if current_energy < best_energy:
                    best_energy = current_energy
                    best_results = rs1[0]
                    best_circuit = vqeinstance
                    best_history_current_epoch = rs1[0]['history']
                    print(f"New best energy in epoch {epoch}: {best_energy}")
            
            
            Eny.append(best_energy)
            best_results_all.append(best_results)
            epoch = epoch+1
   
        filename = f"4_q10_r{r}_angle{angle_deg}_vqeHEA3.pkl"
        filepath = os.path.join(save_dir, filename)
        with open(filepath, 'wb') as f:
            pickle.dump(best_results_all, f)



#%% analysis
# df,wave_list = scan_H2O_energy_surface(r_list, angle_list)

def calculate_fidelity(psi1, psi2):
    return np.abs(np.dot(np.conj(psi1), psi2))**2

num = 0
fid_nn = {}
fid_svqnhe = {}
eny_nn = []
eny_svqnhe = []
for r in r_list:
    for angle_deg in angle_list:
        filename_nn = f"4_q10_r{r}_angle{angle_deg}_vqeHEA3.pkl"
        filename_svqnhe = f"3_q10_r{r}_angle{angle_deg}_svqnhe36r.pkl"

        filepath_nn = os.path.join(save_dir, filename_nn)
        filepath_svqnhe = os.path.join(save_dir, filename_svqnhe)
    
        with open(filepath_nn, 'rb') as f:
            results_nn = pickle.load(f)
        with open(filepath_svqnhe, 'rb') as f:
            results_svqnhe = pickle.load(f)
        
        eny_nn.append(min(results_nn[-1]['history']))
        eny_svqnhe.append(min(results_svqnhe[-1]['history']))
        
        min_index_nn = np.argmin(results_nn[-1]['history'])
        min_index_svqnhe = np.argmin(results_svqnhe[-1]['history'])
        psi_nn = results_nn[-1]['wave'][min_index_nn]
        psi_svqnhe = results_svqnhe[-1]['wave'][min_index_svqnhe]

        psi_nn = psi_nn / np.linalg.norm(psi_nn)
        psi_svqnhe = psi_svqnhe / np.linalg.norm(psi_svqnhe)
        # nn_list = []
        # svqnhe_list = []
        # for i in range(200):
        #     j = i+1
        #     psi_nn = results_nn[-1]['wave'][-j]
        #     psi_svqnhe = results_svqnhe[-1]['wave'][-j]
        #     psi_nn = psi_nn / np.linalg.norm(psi_nn)
        #     psi_svqnhe = psi_svqnhe / np.linalg.norm(psi_svqnhe)
        #     nn_list.append(calculate_fidelity(psi_nn, wave_list[num]))
        #     svqnhe_list.append(calculate_fidelity(psi_svqnhe, wave_list[num]))
        # fidelity_nn = max(nn_list)
        # fidelity_svqnhe = max(svqnhe_list)
        fidelity_nn = calculate_fidelity(psi_nn, wave_list[num])
        fidelity_svqnhe = calculate_fidelity(psi_svqnhe, wave_list[num])
        num = num + 1

        fid_nn[(r, angle_deg)] = fidelity_nn
        fid_svqnhe[(r, angle_deg)] = fidelity_svqnhe
            
#%% plot H2O
def calculate_fidelity(psi1, psi2):
    return np.abs(np.dot(np.conj(psi1), psi2))**2

fid_nn = {}
fid_svqnhe = {}

for r in r_list:
    for angle_deg in angle_list:
        fid_nn[(r, angle_deg)] = []
        fid_svqnhe[(r, angle_deg)] = []

for group in range(3):  
    num = 0
    for r in r_list:
        for angle_deg in angle_list:
            filename_nn = f"{group}_q10_r{r}_angle{angle_deg}_nn36r.pkl"
            filename_svqnhe = f"{group}_q10_r{r}_angle{angle_deg}_svqnhe36r.pkl"
            filepath_nn = os.path.join(save_dir, filename_nn)
            filepath_svqnhe = os.path.join(save_dir, filename_svqnhe)
            with open(filepath_nn, 'rb') as f:
                results_nn = pickle.load(f)
            with open(filepath_svqnhe, 'rb') as f:
                results_svqnhe = pickle.load(f)

            min_index_nn = np.argmin(results_nn[-1]['history'])
            min_index_svqnhe = np.argmin(results_svqnhe[-1]['history'])
            psi_nn = results_nn[-1]['wave'][min_index_nn]
            psi_svqnhe = results_svqnhe[-1]['wave'][min_index_svqnhe]
            psi_nn = psi_nn / np.linalg.norm(psi_nn)
            psi_svqnhe = psi_svqnhe / np.linalg.norm(psi_svqnhe)

            fid_nn[(r, angle_deg)].append(calculate_fidelity(psi_nn, wave_list[num]))
            fid_svqnhe[(r, angle_deg)].append(calculate_fidelity(psi_svqnhe, wave_list[num]))
            num += 1

# box   
# fig, axes = plt.subplots(len(r_list), len(angle_list), figsize=(4*len(angle_list), 4*len(r_list)), sharey=True)
# for i, r in enumerate(r_list):
#     for j, angle_deg in enumerate(angle_list):
#         ax = axes[i, j] if len(r_list) > 1 and len(angle_list) > 1 else axes[max(i, j)]
#         data = [fid_nn[(r, angle_deg)], fid_svqnhe[(r, angle_deg)]]
#         ax.boxplot(data, labels=["NN", "SVQNHE"])
#         ax.set_title(f"r={r}, angle={angle_deg}")
#         ax.set_ylabel("Fidelity")
# plt.tight_layout()
# plt.show()

# bar

all_labels = []
nn_means = []
svqnhe_means = []
nn_stds = []
svqnhe_stds = []

for key in fid_nn:
    r, angle_deg = key
    all_labels.append(f"r={r}\nangle={angle_deg}")
    nn_vals = fid_nn[key]
    svqnhe_vals = fid_svqnhe[key]
    nn_means.append(np.mean(nn_vals))
    nn_stds.append(np.std(nn_vals))
    svqnhe_means.append(np.mean(svqnhe_vals))
    svqnhe_stds.append(np.std(svqnhe_vals))
    
x = np.arange(len(all_labels))
width = 0.35

fig, ax = plt.subplots(figsize=(max(8, len(all_labels)*1.5), 6))
# rects1 = ax.bar(x - width/2, nn_means, width, yerr=nn_stds, label='NN', alpha=0.8)
# rects2 = ax.bar(x + width/2, svqnhe_means, width, yerr=svqnhe_stds, label='SVQNHE', alpha=0.8)

rects1 = ax.bar(
    x - width/2, nn_means, width, yerr=nn_stds, label='NN', alpha=0.8,
    error_kw=dict(ecolor='gray', elinewidth=2, capsize=4)
)
rects2 = ax.bar(
    x + width/2, svqnhe_means, width, yerr=svqnhe_stds, label='SVQNHE', alpha=0.8,
    error_kw=dict(ecolor='gray', elinewidth=2, capsize=4)
)

ax.set_ylabel('Fidelity')
ax.set_title('Fidelity comparison for each H2O (r, angle)')
ax.set_xticks(x)
ax.set_xticklabels(all_labels, rotation=0, ha='center')

ax.legend()
ax.set_ylim(0.95, 1.01)

plt.tight_layout()
plt.show()    

#%% plot H2O (eny and fid)
def calculate_fidelity(psi1, psi2):
    return np.abs(np.dot(np.conj(psi1), psi2))**2

fid_nn = {}
fid_svqnhe = {}
fid_vqe = {}
energy_nn = {}
energy_svqnhe = {}
energy_vqe = {}


for r in r_list:
    for angle_deg in angle_list:
        fid_nn[(r, angle_deg)] = []
        fid_vqe[(r, angle_deg)] = []
        fid_svqnhe[(r, angle_deg)] = []
        energy_nn[(r, angle_deg)] = []
        energy_vqe[(r, angle_deg)] = []
        energy_svqnhe[(r, angle_deg)] = []

for group in range(3):
    num = 0
    for r in r_list:
        for angle_deg in angle_list:
            filename_nn = f"{group}_q10_r{r}_angle{angle_deg}_nn36r.pkl"
            filename_svqnhe = f"{group}_q10_r{r}_angle{angle_deg}_svqnhe36r.pkl"
            filename_vqe = f"{group}_q10_r{r}_angle{angle_deg}_vqeHEA3.pkl"
            filepath_nn = os.path.join(save_dir, filename_nn)
            filepath_vqe = os.path.join(save_dir, filename_vqe)
            filepath_svqnhe = os.path.join(save_dir, filename_svqnhe)

            with open(filepath_nn, 'rb') as f:
                results_nn = pickle.load(f)
            with open(filepath_vqe, 'rb') as f:
                results_vqe = pickle.load(f)
            with open(filepath_svqnhe, 'rb') as f:
                results_svqnhe = pickle.load(f)

            min_index_nn = np.argmin(results_nn[-1]['history'])
            min_index_vqe = np.argmin(results_vqe[-1]['history'])
            min_index_svqnhe = np.argmin(results_svqnhe[-1]['history'])
            psi_nn = results_nn[-1]['wave'][min_index_nn]
            psi_vqe = results_vqe[-1]['wave'][min_index_vqe]
            psi_svqnhe = results_svqnhe[-1]['wave'][min_index_svqnhe]
            psi_nn = psi_nn / np.linalg.norm(psi_nn)
            psi_vqe = psi_vqe / np.linalg.norm(psi_vqe)
            psi_svqnhe = psi_svqnhe / np.linalg.norm(psi_svqnhe)
            fid_nn[(r, angle_deg)].append(calculate_fidelity(psi_nn, wave_list[num]))
            fid_vqe[(r, angle_deg)].append(calculate_fidelity(psi_vqe, wave_list[num]))
            fid_svqnhe[(r, angle_deg)].append(calculate_fidelity(psi_svqnhe, wave_list[num]))
            # energy
            min_energy_nn = np.min(results_nn[-1]['history'])
            min_energy_vqe = np.min(results_vqe[-1]['history'])
            min_energy_svqnhe = np.min(results_svqnhe[-1]['history'])
            energy_nn[(r, angle_deg)].append(min_energy_nn)
            energy_vqe[(r, angle_deg)].append(min_energy_vqe)
            energy_svqnhe[(r, angle_deg)].append(min_energy_svqnhe)
            num += 1

all_labels = []
# fidelity
nn_means = []
vqe_means = []
svqnhe_means = []
nn_stds = []
vqe_stds = []
svqnhe_stds = []
# energy
energy_nn_means = []
energy_vqe_means = []
energy_svqnhe_means = []
energy_nn_stds = []
energy_vqe_stds = []
energy_svqnhe_stds = []

for key in fid_nn:
    r, angle_deg = key
    all_labels.append(f"r={r}\nangle={angle_deg}")
    # fidelity
    nn_means.append(np.mean(fid_nn[key]))
    nn_stds.append(np.std(fid_nn[key]))
    vqe_means.append(np.mean(fid_vqe[key]))
    vqe_stds.append(np.std(fid_vqe[key]))
    svqnhe_means.append(np.mean(fid_svqnhe[key]))
    svqnhe_stds.append(np.std(fid_svqnhe[key]))
    # energy
    energy_nn_means.append(np.mean(energy_nn[key]))
    energy_nn_stds.append(np.std(energy_nn[key]))
    energy_vqe_means.append(np.mean(energy_vqe[key]))
    energy_vqe_stds.append(np.std(energy_vqe[key]))
    energy_svqnhe_means.append(np.mean(energy_svqnhe[key]))
    energy_svqnhe_stds.append(np.std(energy_svqnhe[key]))

x = np.arange(len(all_labels))
width = 0.2
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(max(8, len(all_labels)*1.5), 10), sharex=True)


energy_lookup = {(float(row['r_oh']), float(row['angle_deg'])): float(row['energy_hartree']) for _, row in df.iterrows()}

normalized_nn = []
normalized_vqe = []
normalized_svqnhe = []

all_keys = list(energy_nn.keys())   

for key in all_keys:
    r, angle_deg = key
    exact_energy = energy_lookup[(float(r), float(angle_deg))]
    nn_norm = [e / exact_energy for e in energy_nn[key]]
    vqe_norm = [e / exact_energy for e in energy_vqe[key]]
    svqnhe_norm = [e / exact_energy for e in energy_svqnhe[key]]
    normalized_nn.append(nn_norm)
    normalized_vqe.append(vqe_norm)
    normalized_svqnhe.append(svqnhe_norm)

# box
# positions = np.arange(len(all_labels))
# width = 0.35
# box_colors = ['C0', 'C1']

# for i in range(len(all_labels)):
#     bp = ax1.boxplot(
#         [normalized_nn[i], normalized_svqnhe[i]],
#         positions=[positions[i] - width/2, positions[i] + width/2],
#         widths=width*0.9,
#         patch_artist=True,
#         labels=["NN", "SVQNHE"] if i == 0 else ["", ""],
#         showmeans=True,
#         meanline=True,
#         meanprops={"color": "black", "linestyle": "-", "linewidth": 1.5},
#         medianprops={"color": "white", "linewidth": 0}
#     )
#     for patch, color in zip(bp['boxes'], box_colors):
#         patch.set_facecolor(color)

# box
# ax1.set_ylabel('E_pred / E_exact')
# ax1.set_title('(a) Normalized energy by group')
# ax1.set_xticks(positions)
# ax1.set_xticklabels(all_labels, rotation=0, ha='center')
# import matplotlib.patches as mpatches
# nn_patch = mpatches.Patch(color='C0', label='NN')
# svqnhe_patch = mpatches.Patch(color='C1', label='SVQNHE')
# ax1.legend(handles=[nn_patch, svqnhe_patch])
# bar
positions = np.arange(len(all_labels))
energy_nn_bar_means = [np.mean(group) for group in normalized_nn]
energy_nn_bar_stds  = [np.std(group)  for group in normalized_nn]
energy_vqe_bar_means = [np.mean(group) for group in normalized_vqe]
energy_vqe_bar_stds  = [np.std(group)  for group in normalized_vqe]
energy_svqnhe_bar_means = [np.mean(group) for group in normalized_svqnhe]
energy_svqnhe_bar_stds  = [np.std(group)  for group in normalized_svqnhe]
# rects1 = ax1.bar(
#     positions - width, energy_nn_bar_means, width, yerr=[std*0.5 for std in energy_nn_bar_stds],
#     label='NN', alpha=0.8,
#     error_kw=dict(ecolor='gray', elinewidth=2, capsize=4)
# )
rects2 = ax1.bar(
    positions - width/2, energy_vqe_bar_means, width, yerr=[std*0.5 for std in energy_vqe_bar_stds],
    label='VQE', alpha=0.8,
    error_kw=dict(ecolor='gray', elinewidth=2, capsize=4)
)
rects3 = ax1.bar(
    positions + width/2, energy_svqnhe_bar_means, width, yerr=[std*0.5 for std in energy_svqnhe_bar_stds],
    label='sign-VQNHE', alpha=0.8,
    error_kw=dict(ecolor='gray', elinewidth=2, capsize=4)
)
ax1.set_ylabel('E_pred / E_exact')
ax1.set_title('(a) Normalized energy comparison for each H2O (r, angle)')
ax1.set_xticks(positions)
ax1.set_xticklabels(all_labels, rotation=0, ha='center')
ax1.legend()
ax1.set_ylim(0.9, 1.02)  
ax1.grid(True, which='major', axis='both',linestyle='--', linewidth=0.8, color='gray', alpha=0.7)
# --- Fidelity subplot (b)  ---
# rects4 = ax2.bar(
#     x - width, nn_means, width, yerr=[std*0.5 for std in nn_stds], label='NN', alpha=0.8,
#     error_kw=dict(ecolor='gray', elinewidth=2, capsize=4)
# )
rects5 = ax2.bar(
    x - width/2, vqe_means, width, yerr=[std*0.5 for std in vqe_stds], label='VQE', alpha=0.8,
    error_kw=dict(ecolor='gray', elinewidth=2, capsize=4)
)
rects6 = ax2.bar(
    x + width/2, svqnhe_means, width, yerr=[std*0.5 for std in svqnhe_stds], label='sign-VQNHE', alpha=0.8,
    error_kw=dict(ecolor='gray', elinewidth=2, capsize=4)
)
ax2.set_ylabel('Fidelity')
ax2.set_title('(b) Fidelity comparison for each H2O (r, angle)')
ax2.legend()
ax2.set_xticks(x)
ax2.set_xticklabels(all_labels, rotation=0, ha='center')
ax2.set_ylim(0, 1.1)
ax2.grid(True, which='major', axis='both',linestyle='--', linewidth=0.8, color='gray', alpha=0.7)

plt.tight_layout()
plt.show()

#%% double y
width = 0.2
fig, (ax1, ax2) = plt.subplots(
    2, 1, figsize=(12, 10),
    sharex=True,  
    gridspec_kw={'hspace': 0.35}
)

# ============
ax1_vqe = ax1.twinx()  # VQE 

# NN, sign-VQNHE
rects1 = ax1.bar(
    positions - width, energy_nn_bar_means, width, yerr=[std*0.5 for std in energy_nn_bar_stds],
    label='NN', color='skyblue', alpha=0.8,
    error_kw=dict(ecolor='gray', elinewidth=2, capsize=4)
)
rects3 = ax1.bar(
    positions + width, energy_svqnhe_bar_means, width, yerr=[std*0.5 for std in energy_svqnhe_bar_stds],
    label='sign-VQNHE', color='lightgreen', alpha=0.8,
    error_kw=dict(ecolor='gray', elinewidth=2, capsize=4)
)

ax1.set_ylabel('E_pred / E_exact (NN & sign-VQNHE)', color='tab:blue', fontsize=12)
ax1.set_ylim(0.98, 1.005)  
ax1.tick_params(axis='y', labelcolor='tab:blue')

# VQE
rects2 = ax1_vqe.bar(
    positions, energy_vqe_bar_means, width, yerr=[std*0.5 for std in energy_vqe_bar_stds],
    label='VQE', color='lightcoral', alpha=0.8,
    error_kw=dict(ecolor='gray', elinewidth=2, capsize=4)
)
ax1_vqe.set_ylabel('E_pred / E_exact (VQE)', color='tab:red', fontsize=12)
ax1_vqe.set_ylim(0.97,1.001)  # VQE 实际范围
ax1_vqe.tick_params(axis='y', labelcolor='tab:red')

ax1.set_title('(a) Normalized energy comparison for each H2O (r, angle)')
ax1.set_xticks(positions)
# ax1.set_xticklabels(all_labels, rotation=0, ha='center')
ax1.grid(True, which='major', axis='both', linestyle='--', linewidth=0.8, color='gray', alpha=0.7)

# merger
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax1_vqe.get_legend_handles_labels()
# ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper center',
           # bbox_to_anchor=(0.5, -0.15), ncol=3, frameon=True)

# ====================================
# Fidelity 
ax2_vqe = ax2.twinx()

# NN, sign-VQNHE
rects4 = ax2.bar(
    positions - width, nn_means, width, yerr=[std*0.5 for std in nn_stds],
    label='NN', color='skyblue', alpha=0.8,
    error_kw=dict(ecolor='gray', elinewidth=2, capsize=4)
)
rects6 = ax2.bar(
    positions + width, svqnhe_means, width, yerr=[std*0.5 for std in svqnhe_stds],
    label='sign-VQNHE', color='lightgreen', alpha=0.8,
    error_kw=dict(ecolor='gray', elinewidth=2, capsize=4)
)

ax2.set_ylabel('Fidelity (NN & sign-VQNHE)', color='tab:blue', fontsize=12)
ax2.set_ylim(0.9, 1.001)  
ax2.tick_params(axis='y', labelcolor='tab:blue')

# VQE
rects5 = ax2_vqe.bar(
    positions, vqe_means, width, yerr=[std*0.5 for std in vqe_stds],
    label='VQE', color='lightcoral', alpha=0.8,
    error_kw=dict(ecolor='gray', elinewidth=2, capsize=4)
)
ax2_vqe.set_ylabel('Fidelity (VQE)', color='tab:red', fontsize=12)
ax2_vqe.set_ylim(0.0, 1)  # VQE 
ax2_vqe.tick_params(axis='y', labelcolor='tab:red')

ax2.set_title('(b) Fidelity comparison for each H2O (r, angle)')
ax2.set_xticks(positions)
ax2.set_xticklabels(all_labels, rotation=0, ha='center')
ax2.grid(True, which='major', axis='both', linestyle='--', linewidth=0.8, color='gray', alpha=0.7)

# merger
lines3, labels3 = ax2.get_legend_handles_labels()
lines4, labels4 = ax2_vqe.get_legend_handles_labels()
ax2.legend(lines3 + lines4, labels3 + labels4, loc='upper center',
           bbox_to_anchor=(0.5, -0.15), ncol=3, frameon=True)


plt.tight_layout(rect=[0, 0.03, 1, 0.97])
plt.subplots_adjust(hspace=0.5)
plt.show()
#%%
from qiskit_nature.drivers import Molecule
from qiskit_nature.drivers.second_quantization import ElectronicStructureMoleculeDriver, ElectronicStructureDriverType
from qiskit_nature.problems.second_quantization import ElectronicStructureProblem
from qiskit_nature.mappers.second_quantization import JordanWignerMapper
from qiskit_nature.converters.second_quantization import QubitConverter
from pyscf import gto, scf

def BeH2_full_space():
    """
    计算 arXiv:2504.07037v2 中 BeH2 构型的 Hamiltonian，使用全轨道空间（12 量子比特）。
    几何结构基于文章提供的坐标（单位：Bohr），STO-6G 基组，C_{2v} 对称性。
    返回: Hamiltonian 稀疏矩阵，PySCF 分子对象，HF 对象
    """
    # 定义 BeH2 分子几何结构（单位：Bohr）
    molecule = Molecule(
        geometry=[
            ["Be", [0.000, 0.000, 0.000]],
            ["H", [0.000, 1.275, 2.750]],  # H1
            ["H", [0.000, -1.275, 2.750]],  # H2
        ],
        charge=0,  # 中性分子
        multiplicity=1,  # 单重态
    )

    # 使用 PySCF 设置 C_{2v} 对称性
    mol = gto.Mole()
    mol.atom = [
        ["Be", (0.000, 0.000, 0.000)],
        ["H", (0.000, 1.275, 2.750)],
        ["H", (0.000, -1.275, 2.750)],
    ]
    mol.basis = "sto-6g"
    mol.charge = 0
    mol.spin = 0
    mol.symmetry = "C2v"  # 启用 C_{2v} 对称性
    mol.build()

    # 运行 Hartree-Fock 计算
    mf = scf.RHF(mol)
    mf.kernel()

    # 定义电子结构驱动器
    driver = ElectronicStructureMoleculeDriver(
        molecule, basis="sto-6g", driver_type=ElectronicStructureDriverType.PYSCF,
    )

    # 创建电子结构问题（无活跃空间限制）
    es_problem = ElectronicStructureProblem(driver)
    
    # 生成二阶量子化算符
    second_q_op = es_problem.second_q_ops()
    
    # 使用 Jordan-Wigner 映射转换为量子比特算符
    qubit_converter = QubitConverter(mapper=JordanWignerMapper())
    qubitOp = qubit_converter.convert(second_q_op['ElectronicEnergy'])
    
    # 转换为稀疏矩阵
    H = qubitOp.to_spmatrix()
    
    return H, mol, mf

# 运行计算
if __name__ == "__main__":
    H, mol, mf = BeH2_full_space()
    print("Hamiltonian computed for BeH2 (arXiv:2504.07037v2 geometry, full orbital space, C_{2v} symmetry)")
    print(f"Hamiltonian shape: {H.shape}")
    print(f"HF energy: {mf.e_tot} Hartree")

#%%
if __name__ == "__main__":
    H, mol, mf = BeH2_active_space()
    print("Hamiltonian computed for BeH2 (arXiv:2504.07037v2 geometry, full orbital space, C_{2v} symmetry)")
    print(f"Hamiltonian shape: {H.shape}")
    print(f"HF energy: {mf.e_tot} Hartree")





