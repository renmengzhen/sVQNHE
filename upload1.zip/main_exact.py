#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  8 02:03:21 2024
main exact, J1J2, Heisenberg, TFIM, Ising
@author: Mengzhen
"""
import numpy as np
import pandas as pd
import math
import cmath
import tensorcircuit as tc
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
from qiskit_nature.drivers import UnitsType, Molecule
from qiskit_nature.drivers.second_quantization import (
    ElectronicStructureDriverType,
    ElectronicStructureMoleculeDriver,
)
from qiskit_nature.problems.second_quantization import ElectronicStructureProblem
from qiskit_nature.converters.second_quantization import QubitConverter
from qiskit_nature.mappers.second_quantization import JordanWignerMapper
from qiskit_nature.transformers.second_quantization.electronic import FreezeCoreTransformer, ActiveSpaceTransformer
# from qiskit.aqua.operators import WeightedPauliOperator
from qiskit.quantum_info import Pauli, state_fidelity, SparsePauliOp
import matplotlib.pyplot as plt
# from scipy.linalg import expm
from scipy.sparse.linalg import expm
from scipy import sparse
from scipy.optimize import minimize
import tensorflow as tf
import warnings
from functools import partial
import functools as ft
# from keras.utils import plot_model
warnings.simplefilter(action='ignore', category=FutureWarning)
tc.set_backend("tensorflow")
tc.set_dtype("complex128")

def str2WeightedPaulis_H2D(H2D):
    h = []
    terms = H2D.split('+')
    for term in terms:
        if term:  
            term = term.strip('+')
            weight, pauli_str = term.split('*')
            pauli_list = [pauli for pauli in pauli_str if pauli in 'XYZI']
            weight = float(weight)
            h.append([weight] + [int(pauli == 'X') + 2*int(pauli == 'Y') + 3*int(pauli == 'Z') for pauli in pauli_list])
    return h

def str2WeightedPaulis(s):
	s = s.strip()
	IXYZ = ['I', 'X', 'Y', 'Z']
	prev_idx = 0
	coefs = []
	paulis = []
	is_coef = True
	for idx, c in enumerate(s + '+'):
		if idx == 0: continue
		if is_coef and c in IXYZ:
			coef = complex(s[prev_idx : idx].replace('i', 'j'))
			coefs.append(coef)
			is_coef = False
			prev_idx = idx
		if not is_coef and c in ['+', '-']:
			label = s[prev_idx : idx]
			paulis.append(Pauli(label))
			is_coef = True
			prev_idx = idx
	return SparsePauliOp(paulis,coefs)
dtype=np.complex128
X = np.array([[0, 1.0], [1.0, 0]], dtype=dtype)
Y = np.array([[0, -1j], [1j, 0]], dtype=dtype)
Z = np.array([[1, 0], [0, -1]], dtype=dtype)
I = np.array([[1, 0], [0, 1]], dtype=dtype)
             
def tran(tin):
    if tin=='I':
        return '0'
    if tin=='X':
        return '1'
    if tin=='Y':
        return '2'
    if tin=='Z':
        return '3'
    else:
        return tin
def Fedtest(ex,GS):
    SS=[]
    for x in GS:
        SS.append(state_fidelity(ex,w[:,x]))
    SS=np.array(SS)
    return SS
def mykron(ma, mb, *list):
    """
    :param ma: matrix a
    :param mb: matrix b
    :param *List: a set of matrices
    :return:  kron(ma,mb,list[0],....,list[n-1])
    """
    # k1=tran(ma).copy()
    # k2=tran(mb).copy()
    out = np.kron(ma,mb)
    if len(list) != 0:
        # print(out)
        out = mykron(out, *list)
    return out
def lshift(s,n):
    return s[n:]+s[:n]
def J1J2(na,nb,J1,J2):
    Sl=[]
    Hl=[]
    Sb=[['X','X'],['Y','Y'],['Z','Z']]
    # 0  1  2  3
    # 4  5  6  7
    # 8  9 10 11
    #12 13 14 15
    #J1 periodic
    edge=[]
    edges=[]
    n=na*nb
    for i in range(na):
        for j in range(nb-1):
            a=i*nb+j
            b=i*nb+np.mod(j+1,nb)
            if a!=b:
                edge.append([a,b])
    for i in range(na-1):
        for j in range(nb):
            a=i*nb+j
            b=np.mod((i+1),na)*nb+j
            if a!=b:
                edge.append([a,b])
            
    # for i in range(n):
    for i in edge:
        edges.append(i)
        for j in Sb:
            init=list('I'*n)
            tmp=[]
            # a=np.mod(i,n)
            # b=np.mod(i+1,n)
            a=i[0]
            b=i[1]
            init[a]=j[0]
            init[b]=j[1]
            Sl.append(str(J1)+''.join(init))
            for k in list(init):
                tmp.append(tran(k))
            Hl.append([J1,tmp])
    #J2 periodic
    edge=[]
    n=na*nb
    for i in range(na):
        for j in range(nb-2):
            a=i*nb+j
            b=i*nb+np.mod(j+2,nb)
            if a!=b and [b,a] not in edge:
                edge.append([a,b])
    
    for i in range(na-2):
        for j in range(nb):
            a=i*nb+j
            b=np.mod((i+2),na)*nb+j
            if a!=b and [b,a] not in edge:
                edge.append([a,b])
            
    for i in edge:
        edges.append(i)
        for j in Sb:
            init=list('I'*n)
            # a=np.mod(i,n)
            # b=np.mod(i+2,n)
            a=i[0]
            b=i[1]
            init[a]=j[0]
            init[b]=j[1]
            Sl.append(str(J2)+''.join(init))
            
    a='1'+'I'*n
    H=0*str2WeightedPaulis(a).to_matrix(sparse=1)
    Hy=0*str2WeightedPaulis(a).to_matrix(sparse=1)
    Hx=0*str2WeightedPaulis(a).to_matrix(sparse=1)
    for i in Sl:
        H+=str2WeightedPaulis(i).to_matrix(sparse=1)
        if 'X' in list(i):
            Hx+=str2WeightedPaulis(i).to_matrix(sparse=1)
        if 'Y' in list(i):
            Hy+=str2WeightedPaulis(i).to_matrix(sparse=1)
        # else:
            # H+=str2WeightedPaulis(i).to_opflow().to_spmatrix()
    return H,edges,Hy,Hx
        
def dtheta(params,H):
    N=np.size(params)
    A=np.zeros([N,N],dtype=np.complex128)
    C=np.zeros(N,dtype=np.complex128)
    dpdt=[]
    cp=1/np.sqrt(2)
    a=np.pi/2
    phi=E(params)
    for i in range(N):
        ptmp1=params.copy().reshape(-1)
        ptmp2=params.copy().reshape(-1)
        ptmp1[i]+=a
        ptmp2[i]-=a    
        dp=cp*(E(ptmp1.reshape(params.shape))-E(ptmp2.reshape(params.shape)))
        dpdt.append(dp)
    for i in range(N):
        for j in range(N):
            # phi=Lv(params,wavefunction)
            A[i,j]=(dpdt[i].conj().dot(dpdt[j])).real#+dpdt[i].conj().dot(phi)*dpdt[j].conj().dot(phi)
    for i in range(N):
        # phi=Lv(params,wavefunction)
        C[i]=(dpdt[i].conj().dot(H.dot(phi))).real
    dx=np.linalg.pinv(A.real).dot(-C)
    return dx.real

def commutator(A,B):
    return A.dot(B)-B.dot(A)

def anticommutator(A,B):
    return A.dot(B)+B.dot(A)

def convert_sparse_matrix_to_sparse_tensor(X):
    coo = X.tocoo()
    indices = np.mat([coo.row, coo.col]).transpose()
    return tf.SparseTensor(indices, coo.data, coo.shape)

def Mtheta(theta):
    M=tc.Circuit(nqu)
    j=0
    for i in range(nqu):
        M.rx(i,theta=theta[j])
        j+=1
    for i in range(nqu):
        M.ry(i,theta=theta[j]) 
        j+=1
    return M.matrix().numpy()

def E(theta):
    u=cir(theta).state()
    return u.numpy()

def EN(v,H):
    # v=E(theta)
    return (v.conj().dot(H.dot(v))).real
# def sexpm(H):
#     I=H.copy()
#     I[I!=0]=0
#     return I-H+0.5*H.dot(H)
def cost(theta,H):
    v=E(theta)
    return EN(v,H)
    # return 1-state_fidelity(v, w[:,GS])

# def mS(theta):
#     u=E(theta)
#     v=w[:,GS].reshape(-1)
#     wh=v.conj()*v
#     u=wh*u
#     u/=np.sqrt(u.conj().dot(u))
#     return state_fidelity(u, w[:,GS])

def mS(u):
    # u=E(theta)
    v=w[:,GS].reshape(-1)
    wh=v.conj()*v
    u=wh*u
    u/=np.sqrt(u.conj().dot(u))
    return state_fidelity(u, w[:,GS])

def mA(theta):
    u=E(theta)
    u=u.conj()*(u)
    u/=np.sqrt(u)
    v=w[:,GS].reshape(-1)
    wh=v.conj()*v
    wh/=np.sqrt(wh)
    return state_fidelity(u, wh)

def eS(w,H):
    wh=abs(w.reshape(-1))
    u=np.ones(len(wh))
    u=w.reshape(-1)/wh*u
    u/=np.sqrt(u.conj().dot(u))
    return u.conj().dot(H.dot(u))

def S(H):
    Hp=H.copy()
    I=H*0
    I.setdiag(1)
    Hp[Hp<0]=0
    Hp.setdiag(0)
    
    Hn=H.copy()
    Hn[Hn>0]=0
    Hn.setdiag(H.diagonal())
    Hb=Hn-Hp
    # eHb=expm(-Hb)
    # eH=expm(-H)
    # eHb=I-0.1*Hb+0.01*Hb.dot(Hb)
    # eH=I-0.1*H+0.01*H.dot(H)
    return Hp

#%% J1-J2
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
def initial_param(t, theta, a):
    v=E(theta)
    sf.append(EN(v,H))
    nsi.append(mS(v))
    print('VITE done')
    return {"q": tf.Variable(theta)}
     
# d=[2,2,3,1]
d=[1,1,1,1]
# deep=list(range(1,4))
# deep=[1,2,3]
deep=[10]
for di in deep:
    na= 10 #12
    # d=[2,2,na,int(na/2)]
    # NSI=[]
    # Ene=[]
    iters=[]
    for iii in [1.5]:
    # for iii in np.linspace(0.5,3,51):
        nb=1
        J1=1
        J2=0.6
        # J.append(J2)
        H,edges,Hy,Hx=J1J2(na,nb,J1,J2)
        nqu=na*nb
        # H, qubits=molecule(symbols, iii)
        # nqu=qubits
        # edges=[[0,2],[1,3],[4,1],[2,4],[3,5]]
        # edges=[]
        # for i in range(nqu-1):
        #     edges.append([i,(i+1)%nqu])
        # for i in range(nqu-2):
        #     edges.append([i,(i+2)%nqu])
            
        u,w=sparse.linalg.eigs(H,k=5,which='SR')
        GS=np.where(abs(u-min(u))<1e-5)[0]
        wh=abs(w[:,GS].reshape(-1))
        wh/=np.sqrt(wh.conj().dot(wh))
        h=convert_sparse_matrix_to_sparse_tensor(H)
        epoch=1
        Eny=[]
        sf=[]
        nsi=[]
        hist = []
        # C=[]
        # Q=[]
        fq=list(range(nqu))
        # fq=[]
        # create_hea4_circuit(ry); create_hea_circuit(sign)
        vqeinstance = VQNHE(
        nqu,
        h,
        # {"width":int(na/2), "stddev": 0.01, "choose": "complex-rbm"},  # model parameter
        # {"d": d, "choose": "complex"},  # model parameter
        {"depth": 5, "width": 3, "choose": "real"},  # model parameter
        {"filled_qubit": fq,"edge": edges, "stddev": 0.01,"channel":1 , "epochs":epoch, "choose": "hea"},  # circuit parameter
        shortcut=True,  # enable shortcut for full Hamiltonian matrix evaluation
        )
        cir=vqeinstance.circuit
        t=(nqu+len(edges))*epoch #hea
        # t=(nqu+len(edges))*epoch+nqu #hea4
        # t=2*nqu*(epoch+1) #hea2
        # t = 2*nqu*epoch #hea3
        # t=len(edges)
        # t=2*nqu*epoch
        print('Qubit:',nqu,'iii',iii)
        eny_sign = np.zeros(20)
        for iII in range(20):
            theta=(np.random.rand(t)-0.5)*np.pi
            if di==0:
                theta*=0
           # theta=[]
            rs1 = vqeinstance.multi_training(
                tries=1,  # 10
                maxiter=2000,  # 10000
                threshold=0,
                # optq=JointSchedule(200, 0.01, 800, 0.002, 800),
                # optc=JointSchedule(300, 0.03, 400, 0.01, 4000),
                onlyq=0,
                debug=200,
                qon=0,#1000,2000
                initialization_func=partial(initial_param, theta=theta, a=nqu)
            )
            Eny.append((min(np.array(rs1[0]['history']))-min(u)).real)
            iters.append(rs1[0]['iterations'])
            # print(mS(rs1[0]['circuit_weights']))
            # nsi.append((mA(rs1[0]['circuit_weights'])))
            # if min(Eny)<1e-5:
            #     break
            # v=np.array(rs1[0]['cgrad'])[-1]
            # Y=rs1[0]['quantum_energy']
            # Q.append(np.array(rs1[0]['qgrad']))
            # C.append(np.array(rs1[0]['cgrad']))
            hist.append(rs1[0]['history'])
            print(Eny[-1])
            eny_sign[iII]=rs1[0]['energy']
            
#%% TFIM, Ising
def initial_param(t, theta, a):
    # v=E(theta)
    # sf.append(EN(v,H))
    # nsi.append(mS(v))
    # print('VITE done')
    # return {"q": tf.Variable(theta),"c":cv} #cv=cgrad_exact[99]
    return {"q": tf.Variable(theta)}

# dist=[1,0.4]#tfim
# d=dist[1]
# J=[dist[0]]
# h=d*np.array(J)[0]
J=[1,0.6,0.2] #ising
h=0
na=12
nb=1
n=na*nb
edge=[]
perms=[]
for i in range(na):
    for j in range(nb-1):
        edge.append([i*nb+j,i*nb+np.mod(j+1,nb)])
# ra = np.random.randint(2, na)
# edge.append([i*nb+j,np.mod((i+ra),na)*nb+j])
for i in range(na-1):
    for j in range(nb):
        edge.append([i*nb+j,np.mod((i+1),na)*nb+j])
# for i in range(na-2):
#     for j in range(nb):
#         edge.append([i*nb+j,np.mod((i+2),na)*nb+j])
for i in range(na-3): #ising
    for j in range(nb):
        edge.append([i*nb+j,np.mod((i+3),na)*nb+j])
for i in range(na-6): #ising
    for j in range(nb):
        edge.append([i*nb+j,np.mod((i+6),na)*nb+j])
H2D=''
for i in range(n):
    tmpX='+'+str(h)+'*'
    # tmpY='+'+str(h)
    # tmpZ='+'+str(h)+'*'
    for j in range(n):
        if j==i:
            tmpX+='X'
            # tmpY+='Y'
            # tmpZ+='Z'
        else:
            tmpX+='I'
            # tmpY+='I'
            # tmpZ+='I'
    H2D=H2D+tmpX
ii=0
for i in edge:
    ii = ii+1
    # tmpX='+'+str(J[0])+'*'
    # tmpY='+'+str(J[1])+'*'
    tmpZ='+'+str(J[0])+'*'
    if ii-1<int(len(edge)/3): #ising
        tmpZ='+'+str(J[0])+'*'
    elif ii-1>2*int(len(edge)/3):
        tmpZ='+'+str(J[2])+'*'
    else:
        tmpZ='+'+str(J[1])+'*'
    for j in range(n):
        if j in i:
            # tmpX+='X'
            # tmpY+='Y'
            tmpZ+='Z'
        else:
            # tmpX+='I'
            # tmpY+='I'
            tmpZ+='I'
    H2D=H2D+tmpZ


H2D1=''
for i in range(n):
    tmpX='+'+str(h)
    # tmpY='+'+str(h)
    # tmpZ='+'+str(h)+'*'
    for j in range(n):
        if j==i:
            tmpX+='X'
            # tmpY+='Y'
            # tmpZ+='Z'
        else:
            tmpX+='I'
            # tmpY+='I'
            # tmpZ+='I'
    H2D1=H2D1+tmpX
ii=0
for i in edge:
    # tmpX='+'+str(J[0])
    # tmpY='+'+str(J[1])
    tmpZ='+'+str(J[0])
    ii = ii+1
    if ii-1<int(len(edge)/3): #ising
        tmpZ='+'+str(J[0])
    elif ii-1>2*int(len(edge)/3):
        tmpZ='+'+str(J[2])
    else:
        tmpZ='+'+str(J[1])
    for j in range(n):
        if j in i:
            # tmpX+='X'
            # tmpY+='Y'
            tmpZ+='Z'
        else:
            # tmpX+='I'
            # tmpY+='I'
            tmpZ+='I'
    H2D1=H2D1+tmpZ            
#%% 2-d 9-Heisenberg
def initial_param(t, theta, a):
    # v=E(theta)
    # sf.append(EN(v,H))
    # nsi.append(mS(v))
    # print('VITE done')
    # return {"q": tf.Variable(theta),"c":cv} #cv=cgrad_exact[99]
    return {"q": tf.Variable(theta)}

dist=[1,0.4,0.4,0.4]#0.1(4,4,4);0.1(2,4,4);8222
# dist = [0.8,0.5,0.5,0.5]
d=dist[1:]
h=dist[0]
J=d*np.array(h)
na=3
nb=3
n=na*nb
edge=[]
perms=[]
for i in range(na):
    for j in range(nb-1):
        edge.append([i*nb+j,i*nb+np.mod(j+1,nb)])
for i in range(na-1):
    for j in range(nb):
        edge.append([i*nb+j,np.mod((i+1),na)*nb+j])
H2D=''
for i in range(n):
    # tmpX='+'+str(h)
    # tmpY='+'+str(h)
    tmpZ='+'+str(h)+'*'
    for j in range(n):
        if j==i:
            # tmpX+='X'
            # tmpY+='Y'
            tmpZ+='Z'
        else:
            # tmpX+='I'
            # tmpY+='I'
            tmpZ+='I'
    H2D=H2D+tmpZ
for i in edge:
    tmpX='+'+str(J[0])+'*'
    tmpY='+'+str(J[1])+'*'
    tmpZ='+'+str(J[2])+'*'
    for j in range(n):
        if j in i:
            tmpX+='X'
            tmpY+='Y'
            tmpZ+='Z'
        else:
            tmpX+='I'
            tmpY+='I'
            tmpZ+='I'
    H2D=H2D+tmpX+tmpY+tmpZ
    

H2D1=''
for i in range(n):
    # tmpX='+'+str(h)
    # tmpY='+'+str(h)
    tmpZ1='+'+str(h)
    for j in range(n):
        if j==i:
            # tmpX+='X'
            # tmpY+='Y'
            tmpZ1+='Z'
        else:
            # tmpX+='I'
            # tmpY+='I'
            tmpZ1+='I'
    H2D1=H2D1+tmpZ1
for i in edge:
    tmpX1='+'+str(J[0])
    tmpY1='+'+str(J[1])
    tmpZ1='+'+str(J[2])
    for j in range(n):
        if j in i:
            tmpX1+='X'
            tmpY1+='Y'
            tmpZ1+='Z'
        else:
            tmpX1+='I'
            tmpY1+='I'
            tmpZ1+='I'
    H2D1=H2D1+tmpX1+tmpY1+tmpZ1
#%%
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
H=str2WeightedPaulis(H2D1).to_matrix(sparse=1)
deep=[5]
# deep=[0]
for di in deep:
    d=[2,2,3,3]
    NSI=[]
    # Ene=[]
    iters=[]
    u,w=sparse.linalg.eigs(H,k=4,which='SR')
    GS=np.where(abs(u-min(u))<1e-5)[0]
    wh=abs(w[:,GS].reshape(-1))
    wh/=np.sqrt(wh.conj().dot(wh))
    h0=convert_sparse_matrix_to_sparse_tensor(H)
    h = str2WeightedPaulis_H2D(H2D)
    epoch=1
    Eny=[]
    sf=[]
    nsi=[]
    C=[]
    Q=[]
    fq=list(range(n))
    # fq=[]
    
    vqeinstance = VQNHE(
    # w, for testnn
    n,
    # h0,# for samp only
    h,
    # {"width":2, "stddev": 0.01, "choose": "complex-rbm"},  # model parameter
    # {"width":2, "stddev": 0.01, "choose": "real-rbm"},
    # {"depth": d, "choose": "real-rbm"},  # model parameter
    {"depth": 2, "width": 3, "choose": "real"},  # model parameter
    {"filled_qubit": fq,"edge": edge, "stddev": 0.01,"channel":1 , "epochs":epoch, "choose": "hea3"},  # circuit parameter
    shortcut=False,  # enable shortcut for full Hamiltonian matrix evaluation
    )
    
    cir=vqeinstance.circuit
    # t=(n+len(edge))*epoch #hea
    # t=(n+len(edge))*epoch+n #hea4
    # t = n+epoch*(n+2*len(edge)) #hea3
    # t = 2*epoch #hea3,exact,QAOA
    t = 2*n*epoch #hea3,exact,hea0.5
    # t = 2*n*(epoch+1) #hea2,vqe
    # t=2*nqu*epoch
    # print('Qubit:',n,'iii',iii)
    eny_sign = np.zeros(20)
    eny_list = []
    qgrad_all = []
    qv_all = []
    f2_all = []
    cv_all = []
    cgrad_list = []
    # w1_all = []
    for iII in range(20):
        theta=(np.random.rand(t)-0.5)*2*np.pi
        # theta = np.zeros(t)
        # theta=qv[-1] # qv[150]:hea2_4q
        # theta[:8]=qv[60]
        # theta[:8] = qv3[70]
        # theta = qv+0.1*(np.random.rand(t)-0.5)*2*np.pi 
        # theta[:5] = qv#qv=qgrad_vqnhe[0]; qv=qgrad_exact[99],cv=cv_exact[99]
        # theta[5:] = 0
        # if di==0:
        #     theta*=0
       # theta=[]
        rs1 = vqeinstance.multi_training(
            tries=1,  # 10
            maxiter=1000,  # 200,100,160,360
            threshold=1E-7*0.5,# 1E-2*0.9 or 1; noise: 1E-2*2; 1E-7*0.5
            # optq=JointSchedule(200, 0.01, 800, 0.002, 800),
            # optc=JointSchedule(300, 0.03, 400, 0.01, 4000),
            onlyq=0,
            debug=200,
            qon=1000,
            initialization_func=partial(initial_param, theta=theta, a=n)
        )
        Eny.append((min(np.array(rs1[0]['history']))-min(u)).real)
        print(Eny[-1])
        eny_list.append(rs1[0]['history'])
        eny_sign[iII]=rs1[0]['energy']
        qgrad_all.append(rs1[0]['qgrad'])
        qv_all.append(rs1[0]['circuit_weights'])
        cv_all.append(rs1[0]['model_weights'])
        f2_all.append(rs1[0]['amp_f2'])
        cgrad_list.append(rs1[0]['model_var'])















