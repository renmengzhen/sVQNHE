#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 26 18:30:15 2025

@author: Mengzhen
"""
import numpy as np
import matplotlib.pyplot as plt


#%%
qq=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/Sign_Test/VQNHE')
q=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/Sign_Test/VQE')
histn=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/Sign_Test/VITE')
plt.scatter(list(range(len(qq))),1-np.sort(qq),label='VQNHE',c='r',alpha=0.7)
plt.scatter(list(range(len(histn))),1-np.sort(histn),label='VITE',c='g',marker='*',alpha=0.7)
plt.scatter(list(range(len(q))),1-np.sort(q),label='VQE',c='b',marker='^',alpha=0.7)
plt.yscale('log')
plt.ylim([1e-2,2])
plt.legend(fontsize=15)
plt.xticks(fontsize=15)
plt.yticks(fontsize=15)
# plt.title('Sign')
plt.xlabel('Sorted Initial State', fontsize=20)
plt.ylabel('$1-F_s(\psi)$', fontsize=20)
# qq=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/Sign_Test/qq')
# q=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/Sign_Test/q')
# histn=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/Sign_Test/histn')
# plt.plot(1-np.array(qq),label='VQNHE',c='r',linewidth=3)
# plt.plot(1-np.array(histn),label='VITE',c='g',linewidth=3)
# plt.plot(1-np.array(q),label='VQE',c='b',linewidth=3)
# plt.yscale('log')
# plt.ylim([1e-2,1])
# plt.legend(fontsize=15)
# plt.xticks(fontsize=15)
# plt.yticks(fontsize=15)
# # plt.title('Sign')
# plt.xlabel('time steps', fontsize=20)
# plt.ylabel('$1-F_s(\psi)$', fontsize=20)


#%%
color=['r','g','b','purple','orange']
nqu=6
D=[1,2,3]
# for di in D:
#     Eny2=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/J12_6/SJ0'+str(nqu)+str(di)+'E')
#     NS2=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/J12_6/SJ0'+str(nqu)+str(di)+'S')
#     es=np.argsort(-Eny2)
#     plt.plot(Eny2[es],label='Sign+NN('+str(di)+','+str(di)+')',linestyle='--',linewidth=3,c=color[di-1])
    # plt.plot(NS2[es],label='Rz/CRz Circuit+NN('+str(di)+')',linestyle='--',linewidth=3,c=color[di-1])
# for di in D:
#     Eny=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/J12_6/AJ0'+str(nqu)+str(di)+'E')
#     NS=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/J12_6/AJ0'+str(nqu)+str(di)+'S')
#     es=np.argsort(-Eny)
#     plt.plot(Eny[es],label='Real Amp+NN('+str(di)+','+str(di)+')',linestyle=':',linewidth=3,c=color[di-1])
    # plt.plot(NS[es],label='Amp Circuit+NN('+str(di)+')',linestyle='-',linewidth=3,c=color[di-1])
#86,134
# for di in [1,2,3]:
#     Eny=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/J12V'+str(nqu)+str(di)+'E')
#     plt.plot(-np.sort(-Eny),label='VQE reps='+str(di),linestyle=':',linewidth=3,c=color[di-1])
# #62
ck=0
u=[9.0767654,12.1223249,15.1697863,18.216231]
main_lines = []
main_labels = []
ref_lines = []
ref_labels = []
for di in [6,8,10,12]:
    Eny1=np.loadtxt('//home/Mengzhen/signproblem/result/exact_others/J12_'+str(di)+'/J12'+'10E')
    # print(min(Eny))
    l1, = plt.plot(-np.sort(-Eny1),label=str(di)+' w/ Sign Ansatz',alpha=1,linestyle='dashdot',linewidth=2,c=color[ck])
    main_lines.append(l1)
    main_labels.append(str(di)+' w/ Sign Ansatz')
    Eny2=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/J12_'+str(di)+'/J12'+'0E')
    l2, = plt.plot(-np.sort(-Eny2),label=str(di)+' w/o Sign Ansatz',alpha=0.7,linestyle='-',linewidth=2,c=color[ck])
    main_lines.append(l2)
    main_labels.append(str(di)+' w/o Sign Ansatz')
    l3 = plt.plot(list(range(-5,105)),[0.001*u[ck]]*110,alpha=0.5,linestyle=':',linewidth=2,c=color[ck])
    ref_lines.append(l3[0])
    ref_labels.append(str(di)+' 99.9% Energy')
    ck+=1
    # print(min(Eny))

#62
# u=[10.5173127]
# ck=0
# for di in [1,2,3,4,5]:
#     Eny=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/Heisenberg/Heis9'+str(di)+'V')
#     plt.plot(-np.sort(-Eny),label='HEA Rep='+str(di),linestyle='--',linewidth=2,c=color[ck])
#     ck+=1
#     print(min(Eny))
# ck=0
# for di in [0,3,6]:
#     Eny=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/Heisenberg/Heis9'+str(di)+'E')
#     plt.plot(-np.sort(-Eny),label='NN with Qsteps='+str(di*10),linestyle='-',linewidth=2,c=color[ck])
#     ck+=1
#     print(min(Eny))
# plt.plot(list(range(-2,52)),[0.0001*u[0]]*54,alpha=1,label='99.99% Energy',linestyle=':',linewidth=2,c='k')

# name=['Hardware Efficient','Local','Non Local']
# Egs=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/LiH/LiH_Egs',dtype=np.complex128)
# Ehf=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/LiH/LiH_Ehf',dtype=np.complex128)
# for di in [1,2,3]:
#     Eny=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/LiH/LiHV'+str(di)+'E',dtype=np.complex128)
#     plt.plot(np.arange(0.5,4,0.2),Eny.real,linestyle='dashdot',c=color[di-1],linewidth=1,label='Hardware Efficient Rep:'+str(di))
# for di in [1,2,3]:
#     Eny=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/LiH/LiHS'+str(di)+'E',dtype=np.complex128)
#     plt.plot(np.arange(0.5,4,0.2),Eny.real,linestyle=':',c=color[di-1],linewidth=1,label='Rz/CRz+NN('+str(di)+',1)')
# for di in [1,2]:
#     Eny=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/LiH/LiH_NN'+str(di)+'E',dtype=np.complex128)
#     plt.plot(-np.sort(Egs[0]-Eny),linestyle='-',c=color[di-1],linewidth=1,label='NN('+str(di)+','+str(di)+')')
# for di in ['NN','Y','Z']:
#     Eny=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/LiH/LiH_'+str(di)+'0E',dtype=np.complex128)
#     plt.plot(-np.sort(Egs[0]-Eny),linestyle='-',linewidth=1,label=di)
 
# plt.plot(np.arange(0.5,4,0.2),Egs.real,linestyle='-',linewidth=1,label='FCI')   
# plt.plot(np.arange(0.5,4,0.2),Ehf.real,linestyle='-',linewidth=1,label='Hartree Fock')
plt.yscale('log')
# plt.title('VQNHE Architecture Test',size=30)
# plt.title('J1-J2 6 Qubit',size=30)
# plt.title('LiH Ansatz',size=30)
# plt.title('Heisenberg 2D 9 Qubit',size=30)
# plt.xlabel('Fiedlity with Ground State Amplitude(Sign) Part',size=25)
plt.xlabel('Sorted Converged Results',size=14)
plt.ylabel('$E-E_0$',size=14)
#J12 6,8,10,12
# plt.plot(list(range(100)),[0.001]*100,label='Chemical Accuracy',linewidth=3,c='k')
# for i in range(4):
#     plt.plot(list(range(100)),[0.001*u[i]]*100,label='99.9% Ground state energy',linestyle='--',linewidth=2,c=color[i])
# plt.plot(list(range(100)),[0.0001*abs(min(u))]*100,label='99.99% Ground State Energy',linestyle=':',linewidth=3,c='k')
# plt.plot(list(range(100)),[0.002*abs(min(u))]*100,label='99.8% Ground State Energy',linestyle=':',linewidth=3,c='grey')
# main legend
# leg1 = plt.legend(handles=main_lines, labels=main_labels, fontsize=10, bbox_to_anchor=(0.95,0.95), ncol=1)
leg1 = plt.legend(handles=main_lines, labels=main_labels, fontsize=10, loc='upper right', ncol=1)
plt.gca().add_artist(leg1)
# ref legend
# plt.legend(handles=ref_lines, labels=ref_labels, fontsize=10, loc='lower left', title='Reference')
plt.legend(handles=ref_lines, labels=ref_labels, fontsize=10, loc='lower left')
# plt.xlim(-3,52)
# plt.legend(fontsize=18,ncol=1)
plt.xticks(size=14)
plt.yticks(size=14)

#%% 6 qubit j1-j2
fig, axes = plt.subplots(nrows=1,ncols=2,sharex=True) 
# fig.suptitle('Title of this figure')
color=['r','g','b','purple','orange']
nqu=6
u=[9.0767654,12.1223249,15.1697863,18.216231]
#subplot1
axes1 = axes[0]
for di in [1,2,3]:
    Eny2=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/J12_6/SJ0'+str(nqu)+str(di)+'E')
    NS2=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/J12_6/SJ0'+str(nqu)+str(di)+'S')
    es=np.argsort(-Eny2)
    axes1.plot(Eny2[es],label='Sign+NN('+str(di)+','+str(di)+')',linestyle='--',linewidth=3,c=color[di-1])
axes1.set_yscale('log')
axes1.set_xlabel('Sorted Converged Results',size=18)
axes1.set_ylabel('$E-E_0$',size=18)
axes1.legend(prop={'size': 10})
axes1.hlines(0.0001*abs(min(u)),0,100,linestyle=':',color='k',label='99.99% Ground State Energy')
# axes1.plot(list(range(100)),[0.0001*abs(min(u))]*100,label='99.99% Ground State Energy',linestyle=':',linewidth=3,c='k')
axes1.text(-20, 0.0001, '(a)', fontsize=18, ha='center')

# subplot2
ck=0
axes2 = axes[1]
main_lines2 = []
main_labels2 = []
ref_lines2 = []
ref_labels2 = []
for di in [6,8,10,12]:
    Eny=np.loadtxt('//home/Mengzhen/signproblem/result/exact_others/J12_'+str(di)+'/J12'+'10E')
    print(min(Eny))
    l1, = axes2.plot(-np.sort(-Eny),label=str(di)+' w/ Sign Ansatz',alpha=1,linestyle='dashdot',linewidth=2,c=color[ck])
    main_lines2.append(l1)
    main_labels2.append(str(di)+' w/ Sign Ansatz')
    Eny=np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/J12_'+str(di)+'/J12'+'0E')
    l2, = axes2.plot(-np.sort(-Eny),label=str(di)+' w/o Sign Ansatz',alpha=0.7,linestyle='-',linewidth=2,c=color[ck])
    main_lines2.append(l2)
    main_labels2.append(str(di)+' w/o Sign Ansatz')
    l3 = axes2.hlines(0.001*u[ck],0,100,linestyle=':',color=color[ck],label=str(di)+' 99.9% Energy')
    ref_lines2.append(l3)
    ref_labels2.append(str(di)+' 99.9% Energy')
    ck+=1
    print(min(Eny))
axes2.set_yscale('log')
axes2.set_xlabel('Sorted Converged Results',size=18)
axes2.set_ylabel('$E-E_0$',size=18)

leg2 = axes2.legend(handles=main_lines2, labels=main_labels2, prop={'size': 10}, loc='upper right')
axes2.add_artist(leg2)
axes2.legend(handles=ref_lines2, labels=ref_labels2, prop={'size': 10}, loc='lower left')
axes2.text(-20, 0.0025, '(b)', fontsize=18, ha='center')

#%% j1-j2
fig, axes = plt.subplots(nrows=1, ncols=2, sharex=True) 
color = ['r', 'g', 'b', 'purple', 'orange']
nqu = 6
u = [9.0767654, 12.1223249, 15.1697863, 18.216231]

# subplot1
axes1 = axes[0]
main_lines1 = []
main_labels1 = []
ref_lines1 = []
ref_labels1 = []
for di in [1, 2, 3]:
    Eny2 = np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/J12_6/SJ0' + str(nqu) + str(di) + 'E')
    NS2 = np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/J12_6/SJ0' + str(nqu) + str(di) + 'S')
    es = np.argsort(-Eny2)
    l1, = axes1.plot(Eny2[es], label='Sign+NN(' + str(di) + ',' + str(di) + ')', linestyle='--', linewidth=3, c=color[di-1])
    main_lines1.append(l1)
    main_labels1.append('Sign+NN(' + str(di) + ',' + str(di) + ')')

lref = axes1.hlines(0.0001 * abs(min(u)), 0, 100, linestyle=':', color='k', label='99.99% Ground State Energy')
ref_lines1.append(lref)
ref_labels1.append('99.99% Ground State Energy')
axes1.set_yscale('log')
axes1.set_xlabel('Sorted Converged Results', size=18)
axes1.set_ylabel('$E-E_0$', size=18)

leg1 = axes1.legend(handles=main_lines1, labels=main_labels1, prop={'size': 10}, loc='upper right')
axes1.add_artist(leg1)
axes1.legend(handles=ref_lines1, labels=ref_labels1, prop={'size': 10}, loc='lower left')
axes1.text(-20, 0.0001, '(a)', fontsize=18, ha='center')

# subplot2
ck = 0
axes2 = axes[1]
main_lines2 = []
main_labels2 = []
ref_lines2 = []
ref_labels2 = []
for di in [6, 8, 10, 12]:
    Eny = np.loadtxt('//home/Mengzhen/signproblem/result/exact_others/J12_' + str(di) + '/J12' + '10E')
    print(min(Eny))
    l1, = axes2.plot(-np.sort(-Eny), label=str(di) + ' w/ Sign Ansatz', alpha=1, linestyle='dashdot', linewidth=2, c=color[ck])
    main_lines2.append(l1)
    main_labels2.append(str(di) + ' w/ Sign Ansatz')
    Eny = np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/J12_' + str(di) + '/J12' + '0E')
    l2, = axes2.plot(-np.sort(-Eny), label=str(di) + ' w/o Sign Ansatz', alpha=0.7, linestyle='-', linewidth=2, c=color[ck])
    main_lines2.append(l2)
    main_labels2.append(str(di) + ' w/o Sign Ansatz')
    l3 = axes2.hlines(0.001 * u[ck], 0, 100, linestyle=':', color=color[ck], label=str(di) + ' 99.9% Energy')
    ref_lines2.append(l3)
    ref_labels2.append(str(di) + ' 99.9% Energy')
    ck += 1
    print(min(Eny))
axes2.set_yscale('log')
axes2.set_xlabel('Sorted Converged Results', size=18)
axes2.set_ylabel('$E-E_0$', size=18)

leg2 = axes2.legend(handles=main_lines2, labels=main_labels2, prop={'size': 10}, loc='upper right')
axes2.add_artist(leg2)
axes2.legend(handles=ref_lines2, labels=ref_labels2, prop={'size': 10}, loc='lower left')
axes2.text(-20, 0.0025, '(b)', fontsize=18, ha='center')

#%%
import numpy as np
import matplotlib.pyplot as plt
u = [-9.0767654, -12.1223249, -15.1697863, -18.216231]
qubits = [6, 8, 10, 12]
min_with_sign = []
min_without_sign = []
Eny1_avg = [0.0202035,0.106295,0.286835,0.908695]
Eny1_var = [0.000824385,0.071926506,0.180553578,0.739485438]
Eny2_avg = [1.8723825,2.5909155,3.442325	,4.7062]
Eny2_var = [0.623150464	,0.301024351,0.342840719,0.952772859]
for ck, di in enumerate(qubits):
    # with Sign Ansatz
    # Eny1 = np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/J12_'+str(di)+'/J12'+'10E')
    # min_with_sign.append(np.min(Eny1))
    min_with_sign.append(np.abs(Eny1_avg[ck]/u[ck]))
    # NN
    # Eny2 = np.loadtxt('/home/Mengzhen/signproblem/result/exact_others/J12_'+str(di)+'/J12'+'0E')
    # min_without_sign.append(np.min(Eny2))
    min_without_sign.append(np.abs(Eny2_avg[ck]/u[ck]))

min_with_sign = np.array(min_with_sign)
min_without_sign = np.array(min_without_sign)
diff = min_without_sign - min_with_sign
# diff_avg = np.array(Eny2_avg)-np.array(Eny1_avg)

plt.figure(figsize=(6,4))
plt.plot(qubits, min_with_sign, marker='o', linestyle='-', label='sign-NN')
plt.plot(qubits, min_without_sign, marker='o', linestyle='-', label='NN')
plt.plot(qubits, diff, marker='o', linestyle=':', label='diff between NN and sign-NN')

plt.xlabel('Qubit Number', size=14)
plt.ylabel('Average relative error', size=14)
# plt.title('Precision Gap vs Qubit Number', size=16)
plt.xticks(qubits, size=14)
plt.yticks(size=14)
# plt.yscale('log')
plt.legend(fontsize=12)
plt.grid(True)
plt.tight_layout()
plt.show()
#%%
import numpy as np
import matplotlib.pyplot as plt

u = [-9.0767654, -12.1223249, -15.1697863, -18.216231]
qubits = [6, 8, 10, 12]
Eny1_avg = [0.0202035,0.106295,0.286835,0.908695]
Eny1_var = [0.000824385,0.071926506,0.180553578,0.739485438]
Eny2_avg = [1.835593,2.5909155,3.442325,4.7062]
Eny2_var = [0.210868306,0.301024351,0.342840719,0.952772859]

min_with_sign = []
min_with_sign_err = []
min_without_sign = []
min_without_sign_err = []

for ck, di in enumerate(qubits):

    min_with_sign.append(np.abs(Eny1_avg[ck]/u[ck]))
    min_without_sign.append(np.abs(Eny2_avg[ck]/u[ck]))

    min_with_sign_err.append(np.sqrt(Eny1_var[ck]) / np.abs(u[ck]))
    min_without_sign_err.append(np.sqrt(Eny2_var[ck]) / np.abs(u[ck]))

min_with_sign = np.array(min_with_sign)
min_with_sign_err = 0.5*np.array([np.sqrt(v)/np.abs(u_) for v, u_ in zip(Eny1_var, u)])
min_without_sign = np.array(min_without_sign)
min_without_sign_err = 0.5*np.array([np.sqrt(v)/np.abs(u_) for v, u_ in zip(Eny2_var, u)])
diff = min_without_sign - min_with_sign
# diff_avg = np.array(Eny2_avg)-np.array(Eny1_avg)

plt.figure(figsize=(6,4))

plt.fill_between(qubits, min_with_sign - min_with_sign_err, min_with_sign + min_with_sign_err, color='gray', alpha=0.2)
plt.fill_between(qubits, min_without_sign - min_without_sign_err, min_without_sign + min_without_sign_err, color='gray', alpha=0.2)

plt.errorbar(qubits, min_with_sign, yerr=min_with_sign_err, marker='o', linestyle='-', label='sign-NN', capsize=5, color='C0')
plt.errorbar(qubits, min_without_sign, yerr=min_without_sign_err, marker='o', linestyle='-', label='NN', capsize=5, color='C1')
plt.plot(qubits, diff, marker='o', linestyle=':', label='diff between NN and sign-NN', color='C2')

plt.xlabel('Qubit Number', size=14)
plt.ylabel('Average relative error', size=14)
# plt.title('Precision Gap vs Qubit Number', size=16)
plt.xticks(qubits, size=14)
plt.yticks(size=14)
# plt.yscale('log')
plt.legend(fontsize=12)
plt.grid(True)
plt.tight_layout()
plt.show()