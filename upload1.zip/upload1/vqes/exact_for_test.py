#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jul 21 05:11:18 2024

exact for test (the difference between exact_large is use MLP32)
now we just use exact_large

@author: Mengzhen
"""

from functools import lru_cache
from itertools import product
from functools import partial
import time
from typing import (
    List,
    Any,
    Tuple,
    Callable,
    Optional,
    Dict,
)

import numpy as np
import tensorflow as tf
from tqdm import tqdm
from ..circuit import Circuit
from ..quantum import generate_local_hamiltonian
from .. import gates as G

tf.compat.v1.enable_eager_execution()
Tensor = Any
Array = Any
Model = Any
dtype = np.complex128
# only guarantee compatible with float64 mode
# only support tf backend

x = np.array([[0, 1.0], [1.0, 0]], dtype=dtype)
y = np.array([[0, -1j], [1j, 0]], dtype=dtype)
z = np.array([[1, 0], [0, -1]], dtype=dtype)
xx = np.array([[0, 0, 0, 1], [0, 0, 1, 0], [0, 1, 0, 0], [1, 0, 0, 0]], dtype=dtype)
yy = np.array([[0, 0, 0, -1], [0, 0, 1, 0], [0, 1, 0, 0], [-1, 0, 0, 0]], dtype=dtype)
zz = np.array([[1, 0, 0, 0], [0, -1, 0, 0], [0, 0, -1, 0], [0, 0, 0, 1]], dtype=dtype)
swap = np.array([[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 1]], dtype=dtype)

Y2M = np.array([[np.cos(np.pi/4),np.sin(np.pi/4)], [-np.sin(np.pi/4),np.cos(np.pi/4)]], dtype=dtype)
Y2P = np.array([[np.cos(np.pi/4),-np.sin(np.pi/4)], [np.sin(np.pi/4),np.cos(np.pi/4)]], dtype=dtype)
X2M = np.array([[np.cos(np.pi/4),1j*np.sin(np.pi/4)], [1j*np.sin(np.pi/4),np.cos(np.pi/4)]], dtype=dtype)
X2P = np.array([[np.cos(np.pi/4),-1j*np.sin(np.pi/4)], [-1j*np.sin(np.pi/4),np.cos(np.pi/4)]], dtype=dtype)


pauli = [np.eye(2), x, y, z]


@lru_cache()
def paulistring(term: Tuple[int, ...]) -> Array:
    n = len(term)
    if n == 1:
        return pauli[term[0]]
    ps = np.kron(pauli[term[0]], paulistring(tuple(list(term)[1:])))
    return ps


def construct_matrix(ham: List[List[float]]) -> Array:
    # deprecated
    # only suitable for matrix of small Hilbert dimensions, say <14 qubits
    h = 0.0j
    for term in ham:
        term = list(term)
        for i, t in enumerate(term):
            if i > 0:
                term[i] = int(t)
        h += term[0] * paulistring(tuple(term[1:]))
    return h


# replace with QuOperator tensor_product approach for Hamiltonian construction
# i.e. using ``construct_matrix_v2``


def construct_matrix_tf(ham: List[List[float]], dtype: Any = tf.complex128) -> Tensor:
    # deprecated
    h = 0.0j
    for term in ham:
        term = list(term)
        for i, t in enumerate(term):
            if i > 0:
                term[i] = int(t)
        h += tf.cast(term[0], dtype=dtype) * tf.constant(
            paulistring(tuple(term[1:])), dtype=dtype
        )
    return h


_generate_local_hamiltonian = tf.function(generate_local_hamiltonian)


def construct_matrix_v2(ham: List[List[float]], dtype: Any = tf.complex128) -> Tensor:
    # deprecated
    s = len(ham[0]) - 1
    h = tf.zeros([2**s, 2**s], dtype=dtype)
    for term in tqdm(ham, desc="Hamiltonian building"):
        term = list(term)
        for i, t in enumerate(term):
            if i > 0:
                term[i] = int(t)
        local_matrix_list = [tf.constant(pauli[t], dtype=dtype) for t in term[1:]]
        h += tf.cast(term[0], dtype=dtype) * tf.cast(
            _generate_local_hamiltonian(*local_matrix_list), dtype=dtype
        )
    return h


def construct_matrix_v3(ham: List[List[float]], dtype: Any = tf.complex128) -> Tensor:
    from ..quantum import PauliStringSum2COO

    sparsem = PauliStringSum2COO([h[1:] for h in ham], [h[0] for h in ham])  # type: ignore
    return sparsem
    # densem = backend.to_dense(sparsem)
    # return tf.cast(densem, dtype)

def ry_gate(theta):
    return np.array([
        [np.cos(theta / 2), -np.sin(theta / 2)],
        [np.sin(theta / 2), np.cos(theta / 2)]
    ])
# def ry_gate(theta):
#     return tf.stack([
#         tf.cos(theta / 2),
#         tf.sin(theta / 2)
#     ], axis=0)[..., tf.newaxis] * tf.stack([
#         tf.eye(2),
#         -tf.eye(2)
#     ], axis=-1)

def tensor_product_gates(*gates):
    result = np.eye(1)
    for gate in gates:
        result = np.kron(result, gate)
    return result

# def tensor_product_gates(ry_gates):
#     def reduce_fn(acc, gate):
#         return tf.linalg.tensordot(acc, gate, axes=[[-1], [0]])
    
#     result = tf.eye(ry_gates.dtype)
#     result = tf.scan(reduce_fn, ry_gates, initializer=result, parallel_iterations=1)
#     return result


def vqe_energy(c: Circuit, h: List[List[float]], reuse: bool = True) -> Tensor:
    loss = 0.0
    for term in h:
        ep = []
        for i, t in enumerate(term[1:]):
            if t == 3:
                ep.append((G.z(), [i]))  # type: ignore
            elif t == 1:
                ep.append((G.x(), [i]))  # type: ignore
            elif t == 2:
                ep.append((G.y(), [i]))  # type: ignore
        if ep:
            loss += term[0] * c.expectation(*ep, reuse=reuse)
        else:
            loss += term[0]

    return loss


def vqe_energy_shortcut(c: Circuit, h: Tensor) -> Tensor:
    from ..templates.measurements import operator_expectation
    return operator_expectation(c, h)


class Linear(tf.keras.layers.Layer):  # type: ignore
    """
    Dense layer but with complex weights, used for building complex RBM
    """

    def __init__(self, units: int, input_dim: int, stddev: float = 0.1) -> None:
        super().__init__()
        self.wr = tf.Variable(
            initial_value=tf.random.normal(
                shape=[input_dim, units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )
        self.wi = tf.Variable(
            initial_value=tf.random.normal(
                shape=[input_dim, units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )
        self.br = tf.Variable(
            initial_value=tf.random.normal(
                shape=[units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )
        self.bi = tf.Variable(
            initial_value=tf.random.normal(
                shape=[units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )

    def call(self, inputs: Tensor) -> Tensor:
        inputs = tf.cast(inputs, dtype=dtype)
        return (
            tf.matmul(
                inputs,
                tf.cast(self.wr, dtype=dtype) + 1.0j * tf.cast(self.wi, dtype=dtype),
            )
            + tf.cast(self.br, dtype=dtype)
            + 1.0j * tf.cast(self.bi, dtype=dtype)
        )


class JointSchedule(tf.keras.optimizers.schedules.LearningRateSchedule):  # type: ignore
    def __init__(
        self,
        steps: int = 300,
        pre_rate: float = 0.1,
        pre_decay: int = 400,
        post_rate: float = 0.001,
        post_decay: int = 4000,
        dtype: Any = tf.float64,
    ) -> None:
        super().__init__()
        self.steps = steps
        self.pre_rate = pre_rate
        self.pre_decay = pre_decay
        self.post_rate = post_rate
        self.post_decay = post_decay
        self.dtype = dtype

    def __call__(self, step: Tensor) -> Tensor:
        if step < self.steps:
            return tf.constant(self.pre_rate, dtype=self.dtype) * (1 / 2.0) ** (
                (tf.cast(step, dtype=self.dtype)) / self.pre_decay
            )
        else:
            return tf.constant(self.post_rate, dtype=self.dtype) * (1 / 2.0) ** (
                (tf.cast(step, dtype=self.dtype) - self.steps) / self.post_decay
            )


class VQNHE:
    def __init__(
        self,
        n: int,
        hamiltonian: List[List[float]],
        model_params: Optional[Dict[str, Any]] = None,
        circuit_params: Optional[Dict[str, Any]] = None,
        shortcut: bool = False,
    ) -> None:
        self.n = n
        if not model_params:
            model_params = {}
        self.model = self.create_model(**model_params)
        self.model_params = model_params
        self.cut = model_params.get("cut", 20)
        if not circuit_params:
            circuit_params = {"epochs": 2, "stddev": 0.1}
        self.epochs = circuit_params.get("epochs", 2)
        self.circuit_stddev = circuit_params.get("stddev", 0.1)
        self.channel = circuit_params.get("channel", 2)

        self.circuit_variable = tf.Variable(
            tf.random.normal(
                mean=0.0,
                stddev=self.circuit_stddev,
                shape=[self.epochs, self.n, self.channel],
                dtype=tf.float64,
            )
        )
        self.circuit = self.create_circuit(**circuit_params)
        self.base = tf.constant(list(product(*[[0, 1] for _ in range(n)])))
        self.hamiltonian = hamiltonian
        self.shortcut = shortcut
        self.history: List[float] = []

    def assign(
        self, c: Optional[List[Tensor]] = None, q: Optional[Tensor] = None
    ) -> None:
        if c is not None:
            self.model.set_weights(c)
        if q is not None:
            self.circuit_variable.assign(q)

    def recover(self) -> None:
        try:
            self.assign(self.ccache, self.qcache)
        except AttributeError:
            pass

    def load(self, path: str) -> None:
        w = np.load(path, allow_pickle=True)
        self.assign(w["c"], w["q"])
        self.history = list(w["h"])

    def save(self, path: str) -> None:
        np.savez(path, c=self.ccache, q=self.qcache, h=np.array(self.history))

    def create_model(self, choose: str = "real", **kws: Any) -> Model:
        if choose == "real":
            return self.create_real_model(**kws)
        if choose == "complex":
            return self.create_complex_model(**kws)
        if choose == "real-rbm":
            return self.create_real_rbm_model(**kws)
        if choose == "complex-rbm":
            return self.create_complex_rbm_model(**kws)

    def create_real_model(
        self,
        init_value: float = 0.1,
        max_value: float = 1.0,
        min_value: float = 0,
        depth: int = 2,
        width: int = 2,
        **kws: Any,
    ) -> Model:

        model = tf.keras.Sequential()
        for _ in range(depth):
            model.add(tf.keras.layers.Dense(width * self.n, activation=partial(tf.nn.leaky_relu, alpha=0.01)))

        model.add(tf.keras.layers.Dense(1, activation="tanh"))
        model.add(
            tf.keras.layers.Dense(
                1,
                activation=None,
                use_bias=False,
                kernel_initializer=tf.keras.initializers.Constant(value=init_value),
                kernel_constraint=tf.keras.constraints.MinMaxNorm(
                    min_value=min_value,
                    max_value=max_value,
                ),
            )
        )
        model.build([None, self.n])
        return model

    def create_complex_model(
        self,
        init_value: float = 0.0,
        max_value: float = 1.0,
        min_value: float = 0,
        d: list = [1,1,1,1],
        **kws: Any,
    ) -> Model:
        # if not isinstance(d, list) or not all(isinstance(x, int) for x in d):
        #     raise ValueError("d must be a list of integers")
        # if not isinstance(self.n, int):
        #     raise ValueError("self.n must be an integer")
        inputs = tf.keras.layers.Input(shape=[self.n])
        x = tf.keras.layers.Dense(int(d[0]) * self.n, activation="relu")(inputs)
        x = tf.keras.layers.Dense(int(d[1]) * self.n, activation="relu")(x)

        lnr = tf.keras.layers.Dense(int(d[2])*self.n, activation="relu")(x)
        lnr = tf.keras.layers.Dense(int(d[2])*self.n, activation=None)(lnr)
        lnr = tf.math.log(tf.math.cosh(lnr))
        # lnr = lnr + inputs

        phi = tf.keras.layers.Dense(int(d[3])*self.n, activation="relu")(x)
        phi = tf.keras.layers.Dense(int(d[3])*self.n, activation="relu")(phi)
        # phi = phi + inputs

        lnr = tf.keras.layers.Dense(1, activation=None)(lnr)
        # lnr = tf.keras.layers.Dense(
        #     1,
        #     activation=None,
        #     use_bias=False,
        #     kernel_initializer=tf.keras.initializers.Constant(value=init_value),
        #     kernel_constraint=tf.keras.constraints.MinMaxNorm(
        #         min_value=min_value,
        #         max_value=max_value,
        #     ),
        # )(lnr)
        phi = tf.keras.layers.Dense(1, activation="tanh")(phi)
        lnr = tf.cast(lnr, dtype=tf.complex128)
        phi = tf.cast(phi, dtype=tf.complex128)
        phi = 3.14159j * phi
        outputs = lnr + phi
        model = tf.keras.Model(inputs=inputs, outputs=outputs)
        return model

    def create_real_rbm_model(
        self, stddev: float = 0.1, width: int = 2, **kws: Any
    ) -> Model:
        inputs = tf.keras.layers.Input(shape=[self.n])
        x = tf.keras.layers.Dense(width * self.n, activation=None)(inputs)
        x = tf.math.log(2 * tf.math.cosh(x))
        x = tf.reduce_sum(x, axis=-1)
        x = tf.reshape(x, [-1, 1])
        y = tf.keras.layers.Dense(1, activation=None)(inputs)
        outputs = y + x
        model = tf.keras.Model(inputs=inputs, outputs=outputs)
        return model

    def create_complex_rbm_model(
        self, stddev: float = 0.1, width: int = 2, **kws: Any
    ) -> Model:
        inputs = tf.keras.layers.Input(shape=[self.n])
        x = Linear(width * self.n, self.n, stddev=stddev)(inputs)
        x = tf.math.log(2 * tf.math.cosh(x))
        x = tf.reduce_sum(x, axis=-1)
        x = tf.reshape(x, [-1, 1])
        y = Linear(1, self.n, stddev=stddev)(inputs)
        outputs = y + x
        model = tf.keras.Model(inputs=inputs, outputs=outputs)
        return model

    def create_circuit(
        self, choose: str = "hea", **kws: Any
    ) -> Callable[[Tensor], Tensor]:
        if choose == "hea":
            return self.create_hea_circuit(**kws)
        if choose == "hea2":
            return self.create_hea2_circuit(**kws)
        if choose == "hn":
            return self.create_hn_circuit(**kws)
        if choose == "hea3":
            return self.create_hea3_circuit(**kws)
        if choose == "hea4":
            return self.create_hea4_circuit(**kws)
        raise ValueError("no such choose option: %s" % choose)

    def create_hn_circuit(self, **kws: Any) -> Callable[[Tensor], Tensor]:
        def circuit(a: Tensor) -> Tensor:
            c = Circuit(self.n)
            for i in range(self.n):
                c.H(i)  # type: ignore
            return c

        return circuit

    def create_hea_circuit(
        self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, edge: Optional[List[int]] = None, **kws: Any
    ) -> Callable[[Tensor], Tensor]:
        if filled_qubit is None:
            filled_qubit = [0]

        def circuit(a: Tensor) -> Tensor:
            c = Circuit(self.n)
            if filled_qubit:
                for i in filled_qubit:
                    c.h(i)  # type: ignore

            t=0
            for epoch in range(epochs):
                for i in range(self.n):
                    c.rz(i, theta=a[t])  # type: ignore
                    t+=1
                for i in edge:
                    c.any(int(i[1]),unitary=Y2M)
                    c.cz(i[0],i[1])
                    c.any(int(i[1]),unitary=Y2P)
                    c.rz(int(i[1]), theta=a[t])
                    t+=1
                    c.any(int(i[1]),unitary=Y2M)
                    c.cz(i[0],i[1])
                    c.any(int(i[1]),unitary=Y2P)
                    # c.rzz(i[0],i[1], theta=a[t])                    
                    # t+=1
                # for i in range(self.n):
                #     c.ry(i, theta=a[t])  # type: ignore
                #     t+=1
                # for i in range(self.n):
                #     for j in range(self.n):
                #         if abs(i-j)<2 and i!=j:
                #             c.cz(i, j)
                            # c.crz(i, j, theta=a[epoch, t, 0])  # type: ignore
                        #     t+=1
                    # c.cz(i, np.mod(i+1,self.n))
                    # c.cz(i, np.mod(i+2,self.n))
                # for i in range(self.n):
                #     for j in range(self.n):
                #         for k in range(self.n):
                #             if i!=j!=k:
                #                 c.multicontrol(j, k, unitary=G.z(), ctrl=[i])
                    # c.multicontrol(np.mod(i+1,self.n), np.mod(i+3,self.n), unitary=G.z(), ctrl=[i])
            # if filled_qubit:
                # for i in filled_qubit:
                    # c.h(i) 
            return c

        return circuit

    def create_hea2_circuit(
        self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, **kws: Any
    ) -> Callable[[Tensor], Tensor]:
        if filled_qubit is None:
            filled_qubit = [0]

        def circuit(a: Tensor) -> Tensor:
            c = Circuit(self.n)
            if filled_qubit:
                for i in filled_qubit:
                    c.h(i)  # type: ignore, HEA
            t=0
            for epoch in range(epochs):
                for i in range(self.n):
                    c.ry(i, theta=a[t])  # type: ignore
                    t+=1
                for i in range(self.n):
                    c.rz(i, theta=a[t])  # type: ignore
                    t+=1
                for i in range(self.n-1):
                    c.cx(i,i+1)
                    
            for i in range(self.n):
                c.ry(i, theta=a[t])  # type: ignore
                t+=1
            for i in range(self.n):
                c.rz(i, theta=a[t])
                t+=1
                # for i in range(self.n - 1):
                #     c.exp1(i, (i + 1), theta=a[epoch, i, 3], unitary=G._zz_matrix)  # type: ignore
            return c

        return circuit

    # def create_hea3_circuit(
    #     self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, edge: Optional[List[int]] = None, **kws: Any
    # ) -> Callable[[Tensor], Tensor]:
    #     if filled_qubit is None:
    #         filled_qubit = [0]
            
    #     def circuit(a: Tensor) -> Tensor:
    #         c = Circuit(self.n)
    #         if filled_qubit:
    #             for i in filled_qubit:
    #                 c.h(i)  # type: ignore, QAOA

    #         t=0
    #         for epoch in range(epochs):                
    #             for i in range(self.n):
    #                 c.rx(i, theta=a[t])  # type: ignore
    #                 # t+=1
    #             t=t+1
    #             for i in range(self.n):
    #                 c.rz(i, theta=a[t])
    #             for i in edge:
    #                 # c.ryy(i[0],i[1], theta=a[t])
    #                 # t+=1
    #                 c.rzz(i[0],i[1],theta=a[t])
    #                 # t+=1
    #             t=t+1
    #         # for i in range(self.n):
    #         #     c.ry(i, theta=a[t])  # type: ignore
    #         #     t+=1
    #         return c

    #     return circuit    
    def create_hea3_circuit(
        self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, **kws: Any
    ) -> Callable[[Tensor], Tensor]:
        if filled_qubit is None:
            filled_qubit = [0]

        def circuit(a: Tensor) -> Tensor:
            c = Circuit(self.n)
            if filled_qubit:
                for i in filled_qubit:
                    c.h(i)  # type: ignore, hea0.5
            t=0
            for epoch in range(epochs):
                for i in range(self.n):
                    c.ry(i, theta=a[t])  # type: ignore
                    t+=1
                for i in range(self.n):
                    c.rz(i, theta=a[t])  # type: ignore
                    t+=1
                for i in range(self.n-1):
                    c.cx(i,i+1)
                    
            # for i in range(self.n):
            #     c.ry(i, theta=a[t])  # type: ignore
            #     t+=1
            # for i in range(self.n):
            #     c.rz(i, theta=a[t])
            #     t+=1
                # for i in range(self.n - 1):
                #     c.exp1(i, (i + 1), theta=a[epoch, i, 3], unitary=G._zz_matrix)  # type: ignore
            return c

        return circuit
    # def create_hea4_circuit(
    #     self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, edge: Optional[List[int]] = None, **kws: Any
    # ) -> Callable[[Tensor], Tensor]:
    #     if filled_qubit is None:
    #         filled_qubit = [0]

    #     def circuit(a: Tensor) -> Tensor:
    #         c = Circuit(self.n)
    #         if filled_qubit:
    #             for i in filled_qubit:
    #                 c.h(i)  # type: ignore

    #         t=0
    #         for epoch in range(epochs):
    #             for i in range(self.n):
    #                 c.rz(i, theta=a[t])  # type: ignore
    #                 t+=1
    #             for i in edge:
    #                 # c.rzz(i[0],i[1], theta=a[t])
    #                 # t+=1
    #                 c.rzz(i[0],i[1], theta=a[t])
    #                 # c.cx(i[0],i[1])
    #                 t+=1
    #         if filled_qubit:
    #             for i in filled_qubit:
    #                 c.ry(i,theta=a[t])
    #                 t+=1
    #         return c
    #     return circuit
    # def create_hea4_circuit(
    #     self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, edge: Optional[List[int]] = None, **kws: Any
    # ) -> Callable[[Tensor], Tensor]:
    #     if filled_qubit is None:
    #         filled_qubit = [0]

    #     def circuit(a: Tensor) -> Tensor:
    #         c = Circuit(self.n)
    #         if filled_qubit:
    #             for i in filled_qubit:
    #                 c.h(i)  # type: ignore
    #         t=0
    #         ###############simulation
    #         # for epoch in range(epochs):
    #         #     for i in range(self.n):
    #         #         c.rz(i, theta=a[t])  # type: ignore
    #         #         t+=1
    #         #     for i in edge:
    #         #         c.rzz(i[0],i[1], theta=a[t])
    #         #         t+=1
    #         # if filled_qubit:
    #         #     for i in filled_qubit:
    #         #         c.ry(i,theta=a[t])
    #         #         t+=1
    #         ################experiment
    #         for epoch in range(epochs):
    #             for i in range(self.n):
    #                 c.rz(i, theta=a[t])  # type: ignore
    #                 t+=1
    #             for i in edge:
    #                 c.any(int(i[1]),unitary=Y2M)
    #                 c.cz(i[0],i[1])
    #                 c.any(int(i[1]),unitary=Y2P)
    #                 c.rz(int(i[1]), theta=a[t])
    #                 t+=1
    #                 c.any(int(i[1]),unitary=Y2M)
    #                 c.cz(i[0],i[1])
    #                 c.any(int(i[1]),unitary=Y2P)          
    #         if filled_qubit:
    #             for i in filled_qubit:
    #                 c.any(i,unitary=X2P)
    #                 c.rz(i,theta=a[t])
    #                 t+=1
    #                 c.any(i,unitary=X2M)
    #         return c
    #     return circuit
    def create_hea4_circuit(
        self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, edge: Optional[List[int]] = None, **kws: Any
    ) -> Callable[[Tensor, Tensor, Tensor], Tensor]:
        if filled_qubit is None:
            filled_qubit = [0]
    
        def circuit(a: Tensor, theta_ry: Tensor, theta_rz: Tensor) -> Tensor:
            c = Circuit(self.n)
            t_rz = 0  
            t_ry = 0  
            # params_per_layer = self.n + len(edge)  
            # for H2O, HF state
            # for i in range(5):
            #     c.x(i+2)
            #     c.x(i+9)
            
            for epoch in range(epochs-1):
                for i in range(self.n):
                    c.ry(i, theta=theta_ry[t_ry])
                    t_ry += 1
                for i in range(self.n):
                    c.rz(i, theta=theta_rz[t_rz])
                    t_rz+=1
                for i in edge:
                    c.any(int(i[1]), unitary=Y2M)
                    c.cz(i[0], i[1])
                    c.any(int(i[1]), unitary=Y2P)
                    c.rz(int(i[1]), theta=theta_rz[t_rz])
                    t_rz += 1
                    c.any(int(i[1]), unitary=Y2M)
                    c.cz(i[0], i[1])
                    c.any(int(i[1]), unitary=Y2P)
            t = 0  
            for i in range(self.n):
                c.ry(i, theta=theta_ry[t_ry])
                t_ry += 1
            for i in range(self.n):
                c.rz(i, theta=a[t])
                t += 1
            for i in edge:
                c.any(int(i[1]), unitary=Y2M)
                c.cz(i[0], i[1])
                c.any(int(i[1]), unitary=Y2P)
                c.rz(int(i[1]), theta=a[t])
                t += 1
                c.any(int(i[1]), unitary=Y2M)
                c.cz(i[0], i[1])
                c.any(int(i[1]), unitary=Y2P)
            
            return c
        return circuit

    # @tf.function
    def evaluation(self, cv: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
        with tf.GradientTape() as tape:
            c1 = self.circuit(cv, self.theta_ry, self.theta_rz)
            w = c1.wavefunction()
            f2 = tf.reshape(self.model(self.base), [-1])
            # svqnhe
            # # f2 = abs(f2) # positive svqnhe
            w1 = tf.multiply(tf.cast(f2, dtype=dtype), w)
            # for NN
            # w1 = tf.cast(f2, dtype=dtype)
            
            nm = tf.linalg.norm(w1)
            w1 = w1 / nm
            c2 = Circuit(self.n, inputs=w1)
            loss = tf.math.real(vqe_energy_shortcut(c2, self.h0))
        
        grad = tape.gradient(loss, [cv, self.model.variables])
        for i, gr in enumerate(grad):
            if gr is None:
                if i == 0:
                    grad[i] = tf.zeros_like(cv)
                else:
                    grad[i] = tf.zeros_like(self.model.variables[i - 1])
        
        # Clear intermediate tensors      
        del w
        return loss, grad, f2, w1    
    # @tf.function  # type: ignore
    # def evaluation(self, cv: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    #     """
    #     VQNHE

    #     :param cv: [description]
    #     :type cv: Tensor
    #     :return: [description]
    #     :rtype: Tuple[Tensor, Tensor, Tensor]
    #     """
    #     with tf.GradientTape() as tape:
    #         tape.watch(cv)
    #         thetas = cv[-self.n:]
    #         # thetas = tf.cast(thetas, dtype=tf.float32)
    #         ry_gates = [ry_gate(theta) for theta in thetas]
    #         # ry_gates = tf.map_fn(ry_gate, thetas)
    #         C_y = tensor_product_gates(*ry_gates)
    #         w = self.circuit(cv).wavefunction()
    #         f2 = tf.reshape(self.model(self.base), [-1])
    #         f2 -= tf.math.reduce_mean(f2)           
    #         #f2 = tf.exp(f2)
    #         f2 = f2/tf.linalg.norm(f2)
    #         diagonal_matrix = tf.linalg.diag(f2)
    #         G = diagonal_matrix*(C_y.conj().T)
    #         G = tf.complex(G, tf.zeros_like(G))
    #         G = tf.cast(G, tf.complex128)
    #         # w1 = tf.multiply(tf.cast(f2, dtype=dtype), w)
    #         w = tf.reshape(w, (64, 1))
    #         w1=tf.matmul(G, w)
    #         nm = tf.linalg.norm(w1)
    #         w1 = w1 / nm
    #         c2 = Circuit(self.n, inputs=w1)
    #         if not self.shortcut:
    #             loss = tf.math.real(vqe_energy(c2, self.hamiltonian))
    #         else:
    #             loss = tf.math.real(vqe_energy_shortcut(c2, self.hamiltonian))
    #     grad = tape.gradient(loss, [cv, self.model.variables])
    #     for i, gr in enumerate(grad):
    #         if gr is None:
    #             if i == 0:
    #                 grad[i] = tf.zeros_like(cv)
    #             else:
    #                 grad[i] = tf.zeros_like(self.model.variables[i - 1])
    #     return loss, grad, w1, f2
    # @tf.function  # type: ignore
    # def evaluation(self, cv: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    #     """
    #     VQNHE

    #     :param cv: [description]
    #     :type cv: Tensor
    #     :return: [description]
    #     :rtype: Tuple[Tensor, Tensor, Tensor]
    #     """
    #     with tf.GradientTape() as tape:
    #         tape.watch(cv)
    #         w = self.circuit(cv).wavefunction()
    #         f2 = tf.reshape(self.model(self.base), [-1])
    #         f2 -= tf.math.reduce_mean(f2)
    #         f2 = tf.abs(f2)
    #         f2 = tf.cast(f2, tf.complex128)
    #         # f2 = (
    #         #     tf.cast(
    #         #         tf.clip_by_value(tf.math.real(f2), -self.cut, self.cut),
    #         #         tf.complex128,
    #         #     )
    #         #     + tf.cast(tf.math.imag(f2), tf.complex128) * 1.0j
    #         # )
    #         # f2 = tf.exp(f2)
    #         w1 = tf.multiply(tf.cast(f2, dtype=dtype), w)
    #         nm = tf.linalg.norm(w1)
    #         w1 = w1 / nm
    #         c2 = Circuit(self.n, inputs=w1)
    #         if not self.shortcut:
    #             loss = tf.math.real(vqe_energy(c2, self.hamiltonian))
    #         else:
    #             loss = tf.math.real(vqe_energy_shortcut(c2, self.hamiltonian))
    #     grad = tape.gradient(loss, [cv, self.model.variables])
    #     for i, gr in enumerate(grad):
    #         if gr is None:
    #             if i == 0:
    #                 grad[i] = tf.zeros_like(cv)
    #             else:
    #                 grad[i] = tf.zeros_like(self.model.variables[i - 1])
    #     return loss, grad, w1, f2

    @tf.function  # type: ignore
    def plain_evaluation(self, cv: Tensor) -> Tensor:
        """
        VQE

        :param cv: [description]
        :type cv: Tensor
        :return: [description]
        :rtype: Tensor
        """
        # print(tf.math.real(vqe_energy_shortcut(self.circuit(cv), self.hamiltonian)))
        with tf.GradientTape() as tape:
            c2 = self.circuit(cv, self.theta_ry, self.theta_rz)
            w1 = c2.wavefunction()
            # c = self.circuit(cv)
            # c0 = self.circuit(cv) 
            # c = noisy(c0,2*len(self.edge)) # epoch*len(self.edge)
            # loss
            # compute E_i(For Pi_i)
            loss = tf.math.real(vqe_energy_shortcut(c2, self.h0))
            # grad
            grad = tape.gradient(loss, cv)
        del c2
        return loss, grad, w1
    # def plain_evaluation(self, cv: Tensor) -> Tensor:
    #     """
    #     VQE

    #     :param cv: [description]
    #     :type cv: Tensor
    #     :return: [description]
    #     :rtype: Tensor
    #     """
    #     # print(tf.math.real(vqe_energy_shortcut(self.circuit(cv), self.hamiltonian)))
    #     with tf.GradientTape() as tape:

    #         c = self.circuit(cv)
    #         if not self.shortcut:
    #             loss = tf.math.real(vqe_energy(c, self.hamiltonian))
    #         else:
    #             loss = tf.math.real(vqe_energy_shortcut(c, self.hamiltonian))
    #     grad = tape.gradient(loss, cv)
    #     return loss, grad
    
    def training(
        self,
        maxiter: int = 5000,
        optq: Optional[Callable[[int], Any]] = None,
        optc: Optional[Callable[[int], Any]] = None,
        threshold: float = 1e-8,
        debug: int = 100,
        onlyq: int = 0,
        checkpoints: Optional[List[Tuple[int, float]]] = None,
        qon: int = 1
    ) -> Tuple[Array, Array, Array, int, List[float]]:
        loss_prev = 0
        loss_opt = 1e8
        j_opt = 0
        nm_opt = 1
        ccount = 0
        self.qcache = self.circuit_variable.numpy()
        self.ccache = self.model.get_weights()

        if not optc:
            optc = 0.001  # type: ignore
        if isinstance(optc, float) or isinstance(
            optc, tf.keras.optimizers.schedules.LearningRateSchedule
        ):
            optc = tf.keras.optimizers.Adam(optc)
        if isinstance(optc, tf.keras.optimizers.Optimizer):
            optcf = lambda _: optc
        else:
            optcf = optc  # type: ignore
        if not optq:
            optq = 0.01  # type: ignore
        if isinstance(optq, float) or isinstance(
            optq, tf.keras.optimizers.schedules.LearningRateSchedule
        ):
            optq = tf.keras.optimizers.Adam(optq)
        if isinstance(optq, tf.keras.optimizers.Optimizer):
            optqf = lambda _: optq
        else:
            optqf = optq  # type: ignore

        nm = tf.constant(1.0)
        times = []
        history = []
        qhist = []
        qgrad = []
        cgrad = []
        model_var = []
        amplitude_c = []
        try:
            for j in range(maxiter):
                if j < onlyq:
                    loss, grad = self.plain_evaluation(self.circuit_variable)
                    qhist.append(loss.numpy())
                    # qgrad.append(grad.numpy().reshape(-1))
                else:
                    loss, grad, nm, f2 = self.evaluation(self.circuit_variable)
                    # qgrad.append(grad[0].numpy().reshape(-1))
                    # ctmp=[]
                    # for tmp in grad[1]:
                        # ctmp=ctmp+list(tmp.numpy().reshape(-1))
                    # cgrad.append(nm)
                if not tf.math.is_finite(loss):
                    print("failed optimization since nan in %s tries" % j)
                    # in case numerical instability
                    break
                if np.abs(loss - loss_prev) < threshold:  # 0.3e-7
                    ccount += 1
                    if ccount >= 100:
                        print("finished in %s round" % j)
                        break
                history.append(loss.numpy())
                if checkpoints is not None:
                    bk = False
                    for rd, tv in checkpoints:
                        if j > rd and loss.numpy() > tv:
                            print("failed optimization, as checkpoint is not met")
                            bk = True
                            break
                    if bk:
                        break
                if debug > 0:
                    if j % debug == 0:
                        times.append(time.time())
                        print("energy estimation:", loss.numpy())

                        quantume, _ = self.plain_evaluation(self.circuit_variable)
                        print("quantum part energy: ", quantume.numpy())
                        if len(times) > 1:
                            print("running time: ", (times[-1] - times[-2]) / debug)
                loss_prev = loss
                if j < onlyq:
                    gradofc = [grad]
                    optqf(j).apply_gradients(zip(gradofc, [self.circuit_variable]))
                else:
                    gradofc = grad[0:1]
                if loss < loss_opt:
                    loss_opt = loss
                    nm_opt = nm
                    j_opt = j
                    self.qcache = self.circuit_variable.numpy()
                    self.ccache = self.model.get_weights()
                if j >= onlyq:
                    amplitude_c.append(f2.numpy())
                    optcf(j).apply_gradients(zip(grad[1], self.model.variables))                    
                    if j<qon:
                        optqf(j).apply_gradients(zip(gradofc, [self.circuit_variable]))
                        
                qgrad.append(self.circuit_variable.numpy())
                cgrad.append(self.model.variables)
                model_var.append(self.model.get_weights())
        except KeyboardInterrupt:
            pass

        quantume, _ = self.plain_evaluation(self.circuit_variable)
        print(
            "vqnhe prediction: ",
            loss_prev.numpy(),  # type: ignore
            "quantum part energy: ",
            quantume.numpy(),
            "classical model scale: ",
            self.model.variables[-1].numpy(),
        )
        print("----------END TRAINING------------")
        self.history += history[:j_opt]
        return (
            loss_opt.numpy(),  # type: ignore
            # np.real(nm_opt.numpy()),  # type: ignore
            model_var,
            qhist,
            j_opt,
            #history[:j_opt],
            history,
            qgrad,
            cgrad,
            amplitude_c
        )

    def multi_training(
        self,
        maxiter: int = 5000,
        optq: Optional[Callable[[int], Any]] = None,
        optc: Optional[Callable[[int], Any]] = None,
        threshold: float = 1e-8,
        debug: int = 150,
        onlyq: int = 0,
        checkpoints: Optional[List[Tuple[int, float]]] = None,
        tries: int = 10,
        initialization_func: Optional[Callable[[int], Dict[str, Any]]] = None,
        qon: int = 1,
    ) -> List[Dict[str, Any]]:
        # TODO(@refraction-ray): old multiple training implementation, we can use vmap infra for batched training
        rs = []
        try:
            for t in range(tries):
                print("---------- %s training loop ----------" % t)
                if initialization_func is not None:
                    weights = initialization_func(t)
                else:
                    weights = {}
                qweights = weights.get("q", None)
                cweights = weights.get("c", None)
                if cweights is None:
                    cweights = self.create_model(**self.model_params).get_weights()
                self.model.set_weights(cweights)
                if qweights is None:
                    self.circuit_variable = tf.Variable(
                        tf.random.normal(
                            mean=0.0,
                            stddev=self.circuit_stddev,
                            shape=[self.epochs, self.n, self.channel],
                            dtype=tf.float64,
                        )
                    )
                else:
                    self.circuit_variable = qweights
                    # qon=1
                self.history = []  # refresh the history
                r = self.training(
                    maxiter, optq, optc, threshold, debug, onlyq, checkpoints,qon
                )
                rs.append(
                    {
                        "energy": r[0],
                        # "norm": r[1],
                        "model_var": r[1],
                        "quantum_energy": r[2],
                        "iterations": r[3],
                        "history": r[4],
                        "qgrad": r[5],
                        "cgrad": r[6],
                        "amp_f2": r[7],
                        "model_weights": self.ccache,
                        "circuit_weights": self.qcache,
                    }
                )
        except KeyboardInterrupt:
            pass

        if rs:
            es = [r["energy"] for r in rs]
            ind = np.argmin(es)
            self.assign(rs[ind]["model_weights"], rs[ind]["circuit_weights"])  # type: ignore
            self.history = rs[ind]["history"]  # type: ignore
        return rs
