#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Aug  9 08:01:01 2025
exact (large)
@author: Mengzhen
"""

from functools import lru_cache
import functools as ft
from functools import partial
from itertools import product
import time
from typing import (
    List,
    Any,
    Tuple,
    Callable,
    Optional,
    Dict,
)

import numpy as np
import math
import tensorflow as tf
from tqdm import tqdm
from ..circuit import Circuit
from ..quantum import generate_local_hamiltonian
from .. import gates as G
from .. import channels, noisemodel, set_backend

from tensorflow.keras.layers import Input, Dense, Dropout, BatchNormalization
from tensorflow.keras.optimizers.schedules import LearningRateSchedule
# noise
# error1 = channels.generaldepolarizingchannel(0.0013, 1)
# error2 = channels.generaldepolarizingchannel(0.005, 2)
# # error2 = tc.channels.thermalrelaxationchannel(300, 400, 100, "AUTO", 0.1)
# readout_error = [0.998, 0.976]
# noise_conf = noisemodel.NoiseConf()
# noise_conf.add_noise("h", error1)
# noise_conf.add_noise("rz", error1)
# noise_conf.add_noise("rzz", error2)
# noise_conf.add_noise("readout", readout_error)
# # Apply noise to the circuit
# K = set_backend("tensorflow")

#
tf.compat.v1.enable_eager_execution()
Tensor = Any
Array = Any
Model = Any
dtype = np.complex128
# only guarantee compatible with float64 mode
# only support tf backend

x = np.array([[0, 1.0], [1.0, 0]], dtype=dtype)
y = np.array([[0, -1j], [1j, 0]], dtype=dtype)
z = np.array([[1, 0], [0, -1]], dtype=dtype)
xx = np.array([[0, 0, 0, 1], [0, 0, 1, 0], [0, 1, 0, 0], [1, 0, 0, 0]], dtype=dtype)
yy = np.array([[0, 0, 0, -1], [0, 0, 1, 0], [0, 1, 0, 0], [-1, 0, 0, 0]], dtype=dtype)
zz = np.array([[1, 0, 0, 0], [0, -1, 0, 0], [0, 0, -1, 0], [0, 0, 0, 1]], dtype=dtype)
swap = np.array([[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 1]], dtype=dtype)
s_dagger = np.array([[1, 0], [0, -1j]], dtype=dtype)
S = np.array([[1, 0], [0, 1j]], dtype=dtype)
Y2M = np.array([[np.cos(np.pi/4),np.sin(np.pi/4)], [-np.sin(np.pi/4),np.cos(np.pi/4)]], dtype=dtype)
Y2P = np.array([[np.cos(np.pi/4),-np.sin(np.pi/4)], [np.sin(np.pi/4),np.cos(np.pi/4)]], dtype=dtype)
X2M = np.array([[np.cos(np.pi/4),1j*np.sin(np.pi/4)], [1j*np.sin(np.pi/4),np.cos(np.pi/4)]], dtype=dtype)
X2P = np.array([[np.cos(np.pi/4),-1j*np.sin(np.pi/4)], [-1j*np.sin(np.pi/4),np.cos(np.pi/4)]], dtype=dtype)

pauli = [np.eye(2), x, y, z]

# Define the basis vectors
zero_state = np.array([1.0,0], dtype=dtype) 
one_state = np.array([0,1.0], dtype=dtype) 


# @lru_cache()
@lru_cache(maxsize=1000)
def paulistring(term: Tuple[int, ...]) -> Array:
    n = len(term)
    if n == 1:
        return pauli[term[0]]
    ps = np.kron(pauli[term[0]], paulistring(tuple(list(term)[1:])))
    return ps


def construct_matrix(ham: List[List[float]]) -> Array:
    # deprecated
    # only suitable for matrix of small Hilbert dimensions, say <14 qubits
    h = 0.0j
    for term in ham:
        term = list(term)
        for i, t in enumerate(term):
            if i > 0:
                term[i] = int(t)
        h += term[0] * paulistring(tuple(term[1:]))
    return h


# replace with QuOperator tensor_product approach for Hamiltonian construction
# i.e. using ``construct_matrix_v2``


def construct_matrix_tf(ham: List[List[float]], dtype: Any = tf.complex128) -> Tensor:
    # deprecated
    h = 0.0j
    for term in ham:
        term = list(term)
        for i, t in enumerate(term):
            if i > 0:
                term[i] = int(t)
        h += tf.cast(term[0], dtype=dtype) * tf.constant(
            paulistring(tuple(term[1:])), dtype=dtype
        )
    return h


_generate_local_hamiltonian = tf.function(generate_local_hamiltonian)


def construct_matrix_v2(ham: List[List[float]], dtype: Any = tf.complex128) -> Tensor:
    # deprecated
    s = len(ham[0]) - 1
    h = tf.zeros([2**s, 2**s], dtype=dtype)
    for term in tqdm(ham, desc="Hamiltonian building"):
        term = list(term)
        for i, t in enumerate(term):
            if i > 0:
                term[i] = int(t)
        local_matrix_list = [tf.constant(pauli[t], dtype=dtype) for t in term[1:]]
        h += tf.cast(term[0], dtype=dtype) * tf.cast(
            _generate_local_hamiltonian(*local_matrix_list), dtype=dtype
        )
    return h


def construct_matrix_v3(ham: List[List[float]], dtype: Any = tf.complex128) -> Tensor:
    from ..quantum import PauliStringSum2COO

    sparsem = PauliStringSum2COO([h[1:] for h in ham], [h[0] for h in ham])  # type: ignore
    return sparsem
    # densem = backend.to_dense(sparsem)
    # return tf.cast(densem, dtype)





def vqe_energy_shortcut(c: Circuit, h: Tensor) -> Tensor:
    from ..templates.measurements import operator_expectation
    return operator_expectation(c, h)






class Linear_real(tf.keras.layers.Layer):  # type: ignore
    """
    Dense layer with real weights, used for building real RBM
    """

    def __init__(self, units: int, input_dim: int, stddev: float = 0.1) -> None:
        super().__init__()
        self.wr = tf.Variable(
            initial_value=tf.random.normal(
                shape=[input_dim, units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )
        self.wi = tf.Variable(
            initial_value=tf.random.normal(
                shape=[input_dim, units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )
        self.br = tf.Variable(
            initial_value=tf.random.normal(
                shape=[units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )
        self.bi = tf.Variable(
            initial_value=tf.random.normal(
                shape=[units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )

    def call(self, inputs: Tensor) -> Tensor:
        inputs = tf.cast(inputs, dtype=dtype)
        return (
            tf.matmul(
                inputs,
                tf.cast(self.wr, dtype=dtype)
                + 1.0 * tf.cast(self.wi, dtype=dtype),
            )
            + tf.cast(self.br, dtype=dtype)
            + 1.0 * tf.cast(self.bi, dtype=dtype)
        )



class Linear(tf.keras.layers.Layer):  # type: ignore
    """
    Dense layer but with complex weights, used for building complex RBM
    """

    def __init__(self, units: int, input_dim: int, stddev: float = 0.1) -> None:
        super().__init__()
        self.wr = tf.Variable(
            initial_value=tf.random.normal(
                shape=[input_dim, units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )
        self.wi = tf.Variable(
            initial_value=tf.random.normal(
                shape=[input_dim, units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )
        self.br = tf.Variable(
            initial_value=tf.random.normal(
                shape=[units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )
        self.bi = tf.Variable(
            initial_value=tf.random.normal(
                shape=[units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )

    def call(self, inputs: Tensor) -> Tensor:
        inputs = tf.cast(inputs, dtype=dtype)
        return (
            tf.matmul(
                inputs,
                tf.cast(self.wr, dtype=dtype) + 1.0j * tf.cast(self.wi, dtype=dtype),
            )
            + tf.cast(self.br, dtype=dtype)
            + 1.0j * tf.cast(self.bi, dtype=dtype)
        )

class ModReLU(tf.keras.layers.Layer):
    def __init__(self, bias_init: float = 0.0, eps: float = 1e-8):
        super().__init__()
        self.bias_init = bias_init
        self.eps = eps

    def build(self, input_shape):
        self.b = self.add_weight(
            shape=(1,),
            initializer=tf.keras.initializers.Constant(self.bias_init),
            trainable=True,
            dtype=tf.float64,
            name="modrelu_b",
        )

    def call(self, z: tf.Tensor) -> tf.Tensor:
        r = tf.abs(z)
        scale = tf.nn.relu(r + self.b) / (r + self.eps)
        return tf.cast(scale, z.dtype) * z

class ZReLU(tf.keras.layers.Layer):
    def call(self, z: tf.Tensor) -> tf.Tensor:
        mask = tf.cast((tf.math.real(z) > 0.0) & (tf.math.imag(z) > 0.0), z.dtype)
        return z * mask

class ComplexDense(tf.keras.layers.Layer):
    def __init__(self, units: int, seed: int = None,
                 kernel_constraint=None, use_bias: bool = True):
        super().__init__()
        self.units = units
        self.seed = 0 if seed is None else seed
        self.kernel_constraint = kernel_constraint
        self.use_bias = use_bias
        self.dense_r = tf.keras.layers.Dense(
            units,
            use_bias=use_bias,
            kernel_initializer=tf.keras.initializers.HeNormal(seed=self.seed),
            bias_initializer="zeros",
            kernel_constraint=kernel_constraint,
            dtype=tf.float64,
        )
        self.dense_i = tf.keras.layers.Dense(
            units,
            use_bias=use_bias,
            kernel_initializer=tf.keras.initializers.HeNormal(seed=self.seed + 1),
            bias_initializer="zeros",
            kernel_constraint=kernel_constraint,
            dtype=tf.float64,
        )

    def call(self, x: tf.Tensor) -> tf.Tensor:
        xr = tf.math.real(x) if x.dtype.is_complex else tf.cast(x, tf.float64)
        xi = tf.math.imag(x) if x.dtype.is_complex else tf.zeros_like(xr)
        yr = self.dense_r(xr) - self.dense_i(xi)
        yi = self.dense_r(xi) + self.dense_i(xr)
        return tf.complex(yr, yi)

# def build_set_transformer_logf(n: int,
#                                d_model: int = 256,
#                                num_heads: int = 4,
#                                depth: int = 4,
#                                dtype_real=tf.float32):
#     inputs = tf.keras.Input(shape=(n,), dtype=dtype_real)

#     x = tf.keras.layers.Dense(d_model, kernel_initializer="he_normal")(inputs[..., tf.newaxis])  # (B, n, d_model)

#     for _ in range(depth):
#         attn = tf.keras.layers.MultiHeadAttention(
#             num_heads=num_heads,
#             key_dim=d_model // num_heads,
#             dropout=0.0,
#         )(x, x)
#         x = tf.keras.layers.Add()([x, attn])
#         x = tf.keras.layers.LayerNormalization(epsilon=1e-6)(x)

#         h = tf.keras.layers.Dense(4 * d_model, activation="gelu", kernel_initializer="he_normal")(x)
#         h = tf.keras.layers.Dense(d_model, kernel_initializer="he_normal")(h)
#         x = tf.keras.layers.Add()([x, h])
#         x = tf.keras.layers.LayerNormalization(epsilon=1e-6)(x)

#     pooled = tf.keras.layers.GlobalAveragePooling1D()(x)  # (B, d_model)

#     two = tf.keras.layers.Dense(2, kernel_initializer="zeros", bias_initializer="zeros")(pooled)  # (B, 2)
#     outputs = tf.keras.layers.Lambda(lambda t: tf.complex(t[..., 0], t[..., 1]), dtype=tf.complex64)(two)
#     return tf.keras.Model(inputs=inputs, outputs=outputs)


def build_set_transformer_logf(n: int,
                               d_model: int = 256,
                               num_heads: int = 4,
                               depth: int = 4,
                               real_bound: float = 8.0,
                               dtype_real=tf.float64):
    dtype_complex = tf.complex128 if dtype_real == tf.float64 else tf.complex64

    inputs = tf.keras.Input(shape=(n,), dtype=dtype_real)
    x = tf.keras.layers.Dense(
        d_model, kernel_initializer="he_normal", dtype=dtype_real
    )(inputs[..., tf.newaxis])  # (B, n, d_model)

    pos = tf.range(n)[tf.newaxis, :]
    pos_emb = tf.keras.layers.Embedding(
        input_dim=n, output_dim=d_model,
        embeddings_initializer="he_normal",
        dtype=dtype_real
    )(pos)  # (1, n, d_model)
    x = x + pos_emb  # (B, n, d_model)

    for _ in range(depth):
        attn_layer = tf.keras.layers.MultiHeadAttention(
            num_heads=num_heads,
            key_dim=d_model // num_heads,
            dropout=0.0,
            dtype=dtype_real
        )
        attn = attn_layer(query=x, value=x, key=x)
        x = tf.keras.layers.Add(dtype=dtype_real)([x, attn])
        x = tf.keras.layers.LayerNormalization(epsilon=1e-6, dtype=dtype_real)(x)

        h = tf.keras.layers.Dense(4 * d_model, activation=tf.nn.silu,
                                  kernel_initializer="he_normal", dtype=dtype_real)(x)
        h = tf.keras.layers.Dense(d_model, kernel_initializer="he_normal",
                                  dtype=dtype_real)(h)
        x = tf.keras.layers.Add(dtype=dtype_real)([x, h])
        x = tf.keras.layers.LayerNormalization(epsilon=1e-6, dtype=dtype_real)(x)

    pooled = tf.keras.layers.GlobalAveragePooling1D(dtype=dtype_real)(x)
    two = tf.keras.layers.Dense(
        2,
        kernel_initializer=tf.keras.initializers.RandomNormal(stddev=1e-3),
        bias_initializer="zeros",
        dtype=dtype_real
    )(pooled)

    out = tf.keras.layers.Lambda(
        lambda t: tf.complex(real_bound * tf.tanh(t[..., 0]), t[..., 1]),
        dtype=dtype_complex
    )(two)
    out = tf.keras.layers.Lambda(lambda z: tf.reshape(z, (-1,)), dtype=dtype_complex)(out)
    return tf.keras.Model(inputs=inputs, outputs=out)


def build_resmlp_logf(n: int, width: int = 512, depth: int = 10, dtype_real=tf.float64):
    dtype_complex = tf.complex128 if dtype_real == tf.float64 else tf.complex64

    inputs = tf.keras.Input(shape=(n,), dtype=dtype_real)
    x = tf.keras.layers.Dense(width, kernel_initializer="he_normal")(inputs)
    x = tf.keras.layers.Activation("gelu")(x)

    for _ in range(depth):
        h = tf.keras.layers.Dense(width, kernel_initializer="he_normal")(x)
        h = tf.keras.layers.Activation("gelu")(h)
        h = tf.keras.layers.Dense(width, kernel_initializer="he_normal")(h)
        x = tf.keras.layers.Add()([x, h])
        x = tf.keras.layers.LayerNormalization(epsilon=1e-6)(x)

    two = tf.keras.layers.Dense(
        2,
        kernel_initializer=tf.keras.initializers.RandomNormal(stddev=1e-3),
        bias_initializer="zeros",
        dtype=dtype_real
    )(x)
    outputs = tf.keras.layers.Lambda(
        lambda t: tf.complex(t[..., 0], t[..., 1]),
        dtype=dtype_complex
    )(two)
    return tf.keras.Model(inputs=inputs, outputs=outputs)

class JointSchedule(tf.keras.optimizers.schedules.LearningRateSchedule):  # type: ignore
    def __init__(
        self,
        steps: int = 300,
        pre_rate: float = 0.1,
        pre_decay: int = 400,
        post_rate: float = 0.001,
        post_decay: int = 4000,
        dtype: Any = tf.float64,
    ) -> None:
        super().__init__()
        self.steps = steps
        self.pre_rate = pre_rate
        self.pre_decay = pre_decay
        self.post_rate = post_rate
        self.post_decay = post_decay
        self.dtype = dtype

    def __call__(self, step: Tensor) -> Tensor:
        if step < self.steps:
            return tf.constant(self.pre_rate, dtype=self.dtype) * (1 / 2.0) ** (
                (tf.cast(step, dtype=self.dtype)) / self.pre_decay
            )
        else:
            return tf.constant(self.post_rate, dtype=self.dtype) * (1 / 2.0) ** (
                (tf.cast(step, dtype=self.dtype) - self.steps) / self.post_decay
            )


class VQNHE:
    def __init__(
        self,
        # num_G,
        # edges_G,
        theta_ry,
        theta_rz,
        n: int,
        h0,
        # hamiltonian: List[List[float]],
        model_params: Optional[Dict[str, Any]] = None,
        circuit_params: Optional[Dict[str, Any]] = None,
        shortcut: bool = False,
    ) -> None:
        self.n = n
        # self.num_G = num_G
        # self.edges_G = edges_G
        self.theta_ry = theta_ry
        self.theta_rz = theta_rz if theta_rz is not None else np.array([])
        if not model_params:
            model_params = {}
        self.model = self.create_model(**model_params)
        self.model_params = model_params
        self.cut = model_params.get("cut", 20)
        if not circuit_params:
            circuit_params = {"epochs": 2, "stddev": 0.1}
        self.epochs = circuit_params.get("epochs", 2)
        self.circuit_stddev = circuit_params.get("stddev", 0.1)
        self.channel = circuit_params.get("channel", 2)
        self.edge = circuit_params.get("edge")
        t = 2*n + len(self.edge)  
        self.circuit_variable = tf.Variable(
            tf.random.normal(
                mean=0.0,
                stddev=self.circuit_stddev,
                shape=[t],
                dtype=tf.float64,
            )
        )
        self.circuit = self.create_circuit(**circuit_params)
        self.base = tf.constant(list(product(*[[0, 1] for _ in range(n)])))
        # self.hamiltonian = hamiltonian
        self.h0=h0
        # self.h_sample = generate_sample_terms(self.hamiltonian)
        self.shortcut = shortcut
        self.history: List[float] = []
        # self.alpha = n**2 # n**[k/2] 
        # self.beta = 0.5
        # Precompute sparse Hamiltonian terms
        # self.hamiltonian_terms_tf = []
        # for term in self.hamiltonian:
        #     sparse_term = construct_matrix_v3([term], dtype=tf.complex128)
        #     self.hamiltonian_terms_tf.append(sparse_term)

    def assign(
        self, c: Optional[List[Tensor]] = None, q: Optional[Tensor] = None
    ) -> None:
        if c is not None:
            self.model.set_weights(c)
        if q is not None:
            self.circuit_variable.assign(q)

    def recover(self) -> None:
        try:
            self.assign(self.ccache, self.qcache)
        except AttributeError:
            pass

    def load(self, path: str) -> None:
        w = np.load(path, allow_pickle=True)
        self.assign(w["c"], w["q"])
        self.history = list(w["h"])

    def save(self, path: str) -> None:
        np.savez(path, c=self.ccache, q=self.qcache, h=np.array(self.history))

    def create_model(self, choose: str = "real", **kws: Any) -> Model:
        if choose == "real":
            return self.create_real_model(**kws)
        if choose == "complex":
            return self.create_complex_model(**kws)
        if choose == "real-rbm":
            return self.create_real_rbm_model(**kws)
        if choose == "complex-rbm":
            return self.create_complex_rbm_model(**kws)

    
    # def create_real_model(
    #     self,
    #     init_value: float = 0.1,
    #     max_value: float = 1.0,
    #     min_value: float = 0,
    #     depth: int = 2,
    #     width: int = 2,
    #     seed: int = None,
    #     **kws: Any,
    # ) -> Model:
        
    #     if seed is None:
    #         seed = np.random.randint(0, 1000000)

    #     model = tf.keras.Sequential()
        
    #     for i in range(depth):

    #         model.add(tf.keras.layers.Dense(
    #             width * self.n,
    #             kernel_initializer=tf.keras.initializers.HeNormal(seed=seed + i),
    #             kernel_constraint=tf.keras.constraints.MaxNorm(3),
    #             bias_initializer='zeros'
    #         ))

    #         model.add(tf.keras.layers.ELU())

    #         model.add(tf.keras.layers.Dropout(0.1))

    #     model.add(tf.keras.layers.Dense(
    #         1,
    #         activation='tanh',
    #         kernel_initializer=tf.keras.initializers.HeNormal(seed=seed + depth),
    #         kernel_constraint=tf.keras.constraints.MaxNorm(3)
    #     ))
        
    #     model.add(
    #         tf.keras.layers.Dense(
    #             1,
    #             activation=None,
    #             use_bias=False,
    #             kernel_initializer=tf.keras.initializers.Constant(value=init_value),
    #             kernel_constraint=tf.keras.constraints.MinMaxNorm(
    #                 min_value=min_value,
    #                 max_value=max_value,
    #             ),
    #         )
    #     )
        
    #     model.build([None, self.n])
    #     return model

    # mlp
    def create_real_model(
        self,
        init_value: float = 0.1,
        max_value: float = 5.0,  
        min_value: float = -5.0,  
        depth: int = 2,
        width: int = 2,
        seed: int = None,
        activation: str = "prelu",  
        dropout_rate: float = 0.1,
        **kws: Any,
    ) -> Model:

        if seed is None:
            seed = np.random.randint(0, 1000000)
    
        inputs = tf.keras.Input(shape=[self.n], dtype=tf.float64)
        x = inputs
    
        # Choose activation function
        if activation.lower() == "relu":
            Act = tf.keras.layers.ReLU
        elif activation.lower() == "gelu":
            Act = tf.keras.layers.Activation(lambda x: tf.nn.gelu(x))
        elif activation.lower() == "elu":
            Act = tf.keras.layers.ELU
        elif activation.lower() == "swish":
            Act = tf.keras.layers.Activation(lambda x: tf.nn.swish(x))
        elif activation.lower() == "prelu":
            Act = tf.keras.layers.PReLU
        else:
            Act = tf.keras.layers.ReLU  # default
    
        for i in range(depth):
            x = tf.keras.layers.Dense(
                width * self.n,
                use_bias=True,
                kernel_initializer=tf.keras.initializers.HeNormal(seed=seed + 10 * i),
                bias_initializer="zeros",
                kernel_constraint=tf.keras.constraints.MaxNorm(3),
                dtype=tf.float64,
            )(x)
            x = Act()(x)
            x = tf.keras.layers.Dropout(dropout_rate)(x)
    
        # Output layer - real-valued
        outputs = tf.keras.layers.Dense(
            1,
            activation=None,
            use_bias=True,
            kernel_initializer=tf.keras.initializers.HeNormal(seed=seed + 1000),
            kernel_constraint=tf.keras.constraints.MaxNorm(3),
            bias_initializer="zeros",
            dtype=tf.float64,
        )(x)
    
        # Apply scaling constraint
        outputs = tf.keras.layers.Dense(
            1,
            activation=None,
            use_bias=False,
            kernel_initializer=tf.keras.initializers.Constant(value=init_value),
            kernel_constraint=tf.keras.constraints.MinMaxNorm(min_value=min_value, max_value=max_value),
            dtype=tf.float64,
        )(outputs)
    
        model = tf.keras.Model(inputs=inputs, outputs=outputs)
        model.build([None, self.n])
        return model    

    # def create_complex_model(
    #     self,
    #     init_value: float = 0.0,
    #     max_value: float = 1.0,
    #     min_value: float = 0,
    #     d: list = [1,1,1,1],
    #     **kws: Any,
    # ) -> Model:
    #     inputs = tf.keras.layers.Input(shape=[self.n])
    #     x = tf.keras.layers.Dense(d[0] * self.n, activation="relu")(inputs)
    #     x = tf.keras.layers.Dense(d[1] * self.n, activation="relu")(x)

    #     lnr = tf.keras.layers.Dense(d[2]*self.n, activation="relu")(x)
    #     lnr = tf.keras.layers.Dense(d[2]*self.n, activation=None)(lnr)
    #     lnr = tf.math.log(tf.math.cosh(lnr))
    #     # lnr = lnr + inputs

    #     phi = tf.keras.layers.Dense(d[3]*self.n, activation="relu")(x)
    #     phi = tf.keras.layers.Dense(d[3]*self.n, activation="relu")(phi)
    #     # phi = phi + inputs

    #     lnr = tf.keras.layers.Dense(1, activation=None)(lnr)
    #     # lnr = tf.keras.layers.Dense(
    #     #     1,
    #     #     activation=None,
    #     #     use_bias=False,
    #     #     kernel_initializer=tf.keras.initializers.Constant(value=init_value),
    #     #     kernel_constraint=tf.keras.constraints.MinMaxNorm(
    #     #         min_value=min_value,
    #     #         max_value=max_value,
    #     #     ),
    #     # )(lnr)
    #     phi = tf.keras.layers.Dense(1, activation="tanh")(phi)
    #     lnr = tf.cast(lnr, dtype=tf.complex128)
    #     phi = tf.cast(phi, dtype=tf.complex128)
    #     phi = 3.14159j * phi
    #     outputs = lnr + phi
    #     model = tf.keras.Model(inputs=inputs, outputs=outputs)
    #     return model
    # cnn
    # def create_complex_model(
    #     self,
    #     init_value: float = 0.1,
    #     max_value: float = 5.0,  
    #     min_value: float = -5.0,  
    #     depth: int = 2,
    #     width: int = 2,
    #     seed: int = None,
    #     activation: str = "modrelu",  # "modrelu" or "zrelu"
    #     dropout_rate: float = 0.1,
    #     **kws: Any,
    # ) -> Model:

    #     if seed is None:
    #         seed = np.random.randint(0, 1000000)
    
    #     inputs = tf.keras.Input(shape=[self.n], dtype=tf.float64)
    #     z = tf.cast(inputs, tf.complex128)
    
    #     Act = ModReLU if activation.lower() == "modrelu" else ZReLU
    
    #     for i in range(depth):
    #         z = ComplexDense(width * self.n,
    #                          seed=seed + 10 * i,
    #                          kernel_constraint=tf.keras.constraints.MaxNorm(3),
    #                          use_bias=True)(z)
    #         z = Act()(z)
    #         z = tf.keras.layers.Dropout(dropout_rate)(z)
    
    #     yr = tf.keras.layers.Dense(
    #         1,
    #         activation=None,
    #         use_bias=True,
    #         kernel_initializer=tf.keras.initializers.HeNormal(seed=seed + 1000),
    #         kernel_constraint=tf.keras.constraints.MaxNorm(3),
    #         bias_initializer="zeros",
    #         dtype=tf.float64,
    #     )(tf.math.real(z))
    
    #     yi = tf.keras.layers.Dense(
    #         1,
    #         activation=None,
    #         use_bias=True,
    #         kernel_initializer=tf.keras.initializers.HeNormal(seed=seed + 1001),
    #         kernel_constraint=tf.keras.constraints.MaxNorm(3),
    #         bias_initializer="zeros",
    #         dtype=tf.float64,
    #     )(tf.math.imag(z))
    
    #     out_linear = tf.complex(yr, yi)
    
    #     scale_r = tf.keras.layers.Dense(
    #         1,
    #         activation=None,
    #         use_bias=False,
    #         kernel_initializer=tf.keras.initializers.Constant(value=init_value),
    #         kernel_constraint=tf.keras.constraints.MinMaxNorm(min_value=min_value, max_value=max_value),
    #         dtype=tf.float64,
    #     )(tf.math.real(out_linear))
    
    #     scale_i = tf.keras.layers.Dense(
    #         1,
    #         activation=None,
    #         use_bias=False,
    #         kernel_initializer=tf.keras.initializers.Constant(value=init_value),
    #         kernel_constraint=tf.keras.constraints.MinMaxNorm(min_value=min_value, max_value=max_value),
    #         dtype=tf.float64,
    #     )(tf.math.imag(out_linear))
    
    #     outputs = tf.complex(scale_r, scale_i)
    
    #     model = tf.keras.Model(inputs=inputs, outputs=outputs)
    #     model.build([None, self.n])
    #     return model
    # c-mlp
    def create_complex_model(
        self,
        init_value: float = 0.1,
        max_value: float = 5.0,  
        min_value: float = -5.0,  
        depth: int = 2,
        width: int = 2,
        seed: int = None,
        activation: str = "prelu",  
        dropout_rate: float = 0.1,
        **kws: Any,
    ) -> Model:

        if seed is None:
            seed = np.random.randint(0, 1000000)

        inputs = tf.keras.Input(shape=[self.n], dtype=tf.float64)
        x = inputs

        if activation.lower() == "relu":
            Act = tf.keras.layers.ReLU
        elif activation.lower() == "gelu":
            Act = tf.keras.layers.Activation(lambda x: tf.nn.gelu(x))
        elif activation.lower() == "elu":
            Act = tf.keras.layers.ELU
        elif activation.lower() == "swish":
            Act = tf.keras.layers.Activation(lambda x: tf.nn.swish(x))
        elif activation.lower() == "prelu":
            Act = tf.keras.layers.PReLU
        else:
            Act = tf.keras.layers.ReLU  # default

        for i in range(depth):
            x = tf.keras.layers.Dense(
                width * self.n,
                use_bias=True,
                kernel_initializer=tf.keras.initializers.HeNormal(seed=seed + 10 * i),
                bias_initializer="zeros",
                kernel_constraint=tf.keras.constraints.MaxNorm(3),
                dtype=tf.float64,
            )(x)
            x = Act()(x)
            x = tf.keras.layers.Dropout(dropout_rate)(x)
    
        # MinMaxNorm
        outputs = tf.keras.layers.Dense(
            2,  # real and imag
            activation=None,
            use_bias=True,
            kernel_initializer=tf.keras.initializers.HeNormal(seed=seed + 1000),
            kernel_constraint=tf.keras.constraints.MinMaxNorm(min_value=min_value, max_value=max_value),
            bias_initializer="zeros",
            dtype=tf.float64,
        )(x)
    
        final_outputs = tf.keras.layers.Dense(
            2, 
            activation=None,
            use_bias=False,
            kernel_initializer=tf.keras.initializers.Constant(value=init_value),
            dtype=tf.float64,
        )(outputs)

        complex_outputs = tf.complex(final_outputs[..., 0], final_outputs[..., 1])
    
        model = tf.keras.Model(inputs=inputs, outputs=complex_outputs)
        model.build([None, self.n])
        return model

    def create_real_rbm_model(self, stddev: float = 0.1, width: int = 2, num_hidden_layers: int = 2, **kws) -> tf.keras.Model:
        inputs = Input(shape=[self.n])
        x = Dense(width * self.n, activation='relu',
                  kernel_initializer=tf.keras.initializers.HeNormal(),
                  kernel_regularizer=tf.keras.regularizers.l2(0.01))(inputs)

        x = Dropout(0.3)(x)

        for _ in range(num_hidden_layers):
            x = Dense(width * self.n // (2 ** (_ + 1)), activation='elu',
                      kernel_initializer=tf.keras.initializers.HeNormal(),
                      kernel_regularizer=tf.keras.regularizers.l2(0.01))(x)
            x = Dropout(0.3)(x)

        x = tf.math.log(2 * tf.math.cosh(x))
        x = tf.reduce_sum(x, axis=-1)
        x = tf.reshape(x, [-1, 1])
        outputs = Dense(1, activation=None)(x)
        model = tf.keras.Model(inputs=inputs, outputs=outputs)
        return model
    


    def create_complex_rbm_model(
        self, stddev: float = 0.1, width: int = 2, **kws: Any
    ) -> Model:
        inputs = tf.keras.layers.Input(shape=[self.n])
        x = Linear(width * self.n, self.n, stddev=stddev)(inputs)
        x = tf.math.log(2 * tf.math.cosh(x))
        x = tf.reduce_sum(x, axis=-1)
        x = tf.reshape(x, [-1, 1])
        y = Linear(1, self.n, stddev=stddev)(inputs)
        outputs = y + x
        model = tf.keras.Model(inputs=inputs, outputs=outputs)
        return model
    # def create_complex_rbm_model(self,
    #                           width: int = 256,
    #                           depth: int = 4,
    #                           num_heads: int = 4,
    #                           **kws) -> Model:
    #     dtype_real = tf.float32
    #     model = build_set_transformer_logf(
    #         n=self.n,
    #         d_model=width,
    #         num_heads=num_heads,
    #         depth=depth,
    #         dtype_real=dtype_real,
    #     )
    #     return model

    # def create_complex_rbm_model(self, width: int = 512, depth: int = 10, use_float64: bool = False, **kws):
    #     dtype_real = tf.float64 if use_float64 else tf.float32
    #     return build_resmlp_logf(self.n, width=width, depth=depth, dtype_real=dtype_real)
    # def create_complex_rbm_model(self,
    #                           kind: str = "set",
    #                           width: int = 512,
    #                           depth: int = 10,
    #                           num_heads: int = 4,
    #                           set_depth: int = 4,
    #                           real_bound: float = 8.0,
    #                           use_float64: bool = True,
    #                           **kws) -> Model:
    #     dtype_real = tf.float64 if use_float64 else tf.float32
    #     if kind == "resmlp":
    #         return build_resmlp_logf(self.n, width=width, depth=depth, real_bound=real_bound, dtype_real=dtype_real)
    #     else:
    #         return build_set_transformer_logf(self.n, d_model=width, num_heads=num_heads,
    #                                           depth=set_depth, real_bound=real_bound, dtype_real=dtype_real)
    
    def create_circuit(
        self, choose: str = "hea", **kws: Any
    ) -> Callable[[Tensor], Tensor]:
        if choose == "hea":
            return self.create_hea_circuit(**kws)
        if choose == "hea0":
            return self.create_hea1_circuit(**kws)
        if choose == "hea1":
            return self.create_hea1_circuit(**kws)
        if choose == "hea2":
            return self.create_hea2_circuit(**kws)
        if choose == "hea3":
            return self.create_hea3_circuit(**kws)
        if choose == "hea4":
            return self.create_hea4_circuit(**kws)
        raise ValueError("no such choose option: %s" % choose)

    def create_hn_circuit(self, **kws: Any) -> Callable[[Tensor], Tensor]:
        def circuit(a: Tensor) -> Tensor:
            c = Circuit(self.n)
            for i in range(self.n):
                c.H(i)  # type: ignore
            return c

        return circuit

    def create_hea_circuit(
        self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, edge: Optional[List[int]] = None, **kws: Any
    ) -> Callable[[Tensor], Tensor]:
        if filled_qubit is None:
            filled_qubit = [0]

        def circuit(a: Tensor) -> Tensor:
            c = Circuit(self.n)
            if filled_qubit:
                for i in filled_qubit:
                    c.h(i)  # type: ignore

            t=0
            for epoch in range(epochs):
                for i in range(self.n):
                    c.rz(i, theta=a[t])  # type: ignore
                    t+=1
                for i in edge:
                    # c.rzz(i[0],i[1], theta=a[t])
                    # t+=1
                    c.rzz(i[0],i[1], theta=a[t])
                    # c.cx(i[0],i[1])
                    t+=1
            return c

        return circuit
    
    def create_hea0_circuit(
        self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, **kws: Any
    ) -> Callable[[Tensor], Tensor]:
        if filled_qubit is None:
            filled_qubit = [0]

        def circuit(a: Tensor) -> Tensor:
            c = Circuit(self.n)
            if filled_qubit:
                for i in filled_qubit:
                    c.h(i)  # type: ignore, HEA for vqe
            t=0
            for epoch in range(epochs):
                for i in range(self.n):
                    c.ry(i, theta=a[t])  # type: ignore
                    t+=1
                for i in range(self.n):
                    c.rz(i, theta=a[t])  # type: ignore
                    t+=1
                for i in range(self.n-1):
                    c.cx(i,i+1)
                    
            for i in range(self.n):
                c.ry(i, theta=a[t])  # type: ignore
                t+=1
            for i in range(self.n):
                c.rz(i, theta=a[t])
                t+=1
                # for i in range(self.n - 1):
                #     c.exp1(i, (i + 1), theta=a[epoch, i, 3], unitary=G._zz_matrix)  # type: ignore
            return c

        return circuit

    def create_hea1_circuit(
        self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, edge: Optional[List[int]] = None, **kws: Any
    ) -> Callable[[Tensor, Tensor, Tensor], Tensor]:
        if filled_qubit is None:
            filled_qubit = [0]

        def circuit(a: Tensor, theta_ry: Tensor, theta_rz: Tensor) -> Tensor:
            c = Circuit(self.n)
            if filled_qubit:
                for i in filled_qubit:
                    c.h(i) 
    
            t = 0
            gate_counter = 0  
    
            # brickwork
            def brickwork_connect(layer: int, n_qubits: int):
                offset = layer % 2
                return [(i, i+1) for i in range(offset, n_qubits-1, 2)]
    
            for epoch in range(epochs):
                # RX→RY→RZ
                rot_type = ['rx', 'ry', 'rz'][gate_counter % 3]
                for i in range(self.n):
                    if rot_type == 'rx':
                        c.rx(i, theta=a[t])
                    elif rot_type == 'ry':
                        c.ry(i, theta=a[t])
                    else:
                        c.rz(i, theta=a[t])
                    t += 1
                # gate_counter += 1
    
                # RXX→RYY→RZZ
                entang_type = ['rxx', 'ryy', 'rzz'][gate_counter % 3]
                connections = brickwork_connect(epoch, self.n)
                for q1, q2 in connections:
                    if entang_type == 'rxx':
                        c.rxx(q1, q2, theta=a[t])
                    elif entang_type == 'ryy':
                        c.ryy(q1, q2, theta=a[t])
                    else:
                        c.rzz(q1, q2, theta=a[t])
                    t += 1
                gate_counter += 1
    
            return c
        return circuit    

    def create_hea2_circuit(
        self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, edge: Optional[List[int]] = None, **kws: Any
    ) -> Callable[[Tensor, Tensor, Tensor], Tensor]:
        if filled_qubit is None:
            filled_qubit = [0]
        # hea for standard vqe
        def circuit(a: Tensor, theta_ry: Tensor, theta_rz: Tensor) -> Tensor:
            c = Circuit(self.n)
            t=0
            for epoch in range(epochs):
                for i in range(self.n):
                    # c.ry(i, theta=a[t])  # type: ignore
                    # t+=1
                    c.any(i,unitary=X2P)
                    c.rz(i,theta=a[t])
                    t +=1
                    c.any(i,unitary=X2M)
                for i in range(self.n):
                    c.rz(i, theta=a[t])  # type: ignore
                    t += 1
                for i in edge:
                    c.any(int(i[1]), unitary=Y2M)
                    c.cz(i[0], i[1])
                    c.any(int(i[1]), unitary=Y2P)
                    c.rz(int(i[1]), theta=a[t]) 
                    t += 1
                    c.any(int(i[1]), unitary=Y2M)
                    c.cz(i[0], i[1])
                    c.any(int(i[1]), unitary=Y2P)
            return c

        return circuit
    
    def create_hea3_circuit(
        self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, edge: Optional[List[int]] = None, **kws: Any
    ) -> Callable[[Tensor, Tensor, Tensor], Tensor]:
        if filled_qubit is None:
            filled_qubit = [0]
        # hea for sampling layerwise vqe
        def circuit(a: Tensor, theta_ry: Tensor, theta_rz: Tensor) -> Tensor:
            c = Circuit(self.n)
            t = 0  
            t_ry = 0 
            t_rz = 0    

            for epoch in range(epochs-1):
                for i in range(self.n):
                    c.ry(i, theta=theta_ry[t_ry])
                    t_ry += 1
                
                for i in range(self.n):
                    c.rz(i, theta=theta_rz[t_rz])
                    t_rz += 1
                
                for i in edge:
                    c.any(int(i[1]), unitary=Y2M)
                    c.cz(i[0], i[1])
                    c.any(int(i[1]), unitary=Y2P)
                    c.rz(int(i[1]), theta=theta_rz[t_rz])
                    t_rz += 1
                    c.any(int(i[1]), unitary=Y2M)
                    c.cz(i[0], i[1])
                    c.any(int(i[1]), unitary=Y2P)
            

            for i in range(self.n):
                c.ry(i, theta=a[t])  
                t += 1

            for i in range(self.n):
                c.rz(i, theta=a[t])  
                t += 1

            for i in edge:
                c.any(int(i[1]), unitary=Y2M)
                c.cz(i[0], i[1])
                c.any(int(i[1]), unitary=Y2P)
                c.rz(int(i[1]), theta=a[t]) 
                t += 1
                c.any(int(i[1]), unitary=Y2M)
                c.cz(i[0], i[1])
                c.any(int(i[1]), unitary=Y2P)
            
            return c
        return circuit

    def create_hea4_circuit(
        self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, edge: Optional[List[int]] = None, **kws: Any
    ) -> Callable[[Tensor, Tensor, Tensor], Tensor]:
        if filled_qubit is None:
            filled_qubit = [0]

        def circuit(a: Tensor, theta_ry: Tensor, theta_rz: Tensor) -> Tensor:
            c = Circuit(self.n)
            t_rz = 0  
            t_ry = 0  
            # params_per_layer = self.n + len(edge)  
            # for H2O, HF state
            # for i in range(5):
            #     c.x(i+2)
            #     c.x(i+9)
            
            for epoch in range(epochs-1):
                for i in range(self.n):
                    c.ry(i, theta=theta_ry[t_ry])
                    t_ry += 1
                for i in range(self.n):
                    c.rz(i, theta=theta_rz[t_rz])
                    t_rz+=1
                for i in edge:
                    c.any(int(i[1]), unitary=Y2M)
                    c.cz(i[0], i[1])
                    c.any(int(i[1]), unitary=Y2P)
                    c.rz(int(i[1]), theta=theta_rz[t_rz])
                    t_rz += 1
                    c.any(int(i[1]), unitary=Y2M)
                    c.cz(i[0], i[1])
                    c.any(int(i[1]), unitary=Y2P)
            t = 0  
            for i in range(self.n):
                c.ry(i, theta=theta_ry[t_ry])
                t_ry += 1
            for i in range(self.n):
                c.rz(i, theta=a[t])
                t += 1
            for i in edge:
                c.any(int(i[1]), unitary=Y2M)
                c.cz(i[0], i[1])
                c.any(int(i[1]), unitary=Y2P)
                c.rz(int(i[1]), theta=a[t])
                t += 1
                c.any(int(i[1]), unitary=Y2M)
                c.cz(i[0], i[1])
                c.any(int(i[1]), unitary=Y2P)
            
            return c
        return circuit
    
    # @tf.function
    def evaluation(self, cv: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
        with tf.GradientTape() as tape:
            c1 = self.circuit(cv, self.theta_ry, self.theta_rz)
            w = c1.wavefunction()
            f2 = tf.reshape(self.model(self.base), [-1])
            # svqnhe
            # # f2 = abs(f2) # positive svqnhe
            w1 = tf.multiply(tf.cast(f2, dtype=dtype), w)
            # for NN
            # w1 = tf.cast(f2, dtype=dtype)
            
            nm = tf.linalg.norm(w1)
            w1 = w1 / nm
            c2 = Circuit(self.n, inputs=w1)
            loss = tf.math.real(vqe_energy_shortcut(c2, self.h0))
        
        grad = tape.gradient(loss, [cv, self.model.variables])
        for i, gr in enumerate(grad):
            if gr is None:
                if i == 0:
                    grad[i] = tf.zeros_like(cv)
                else:
                    grad[i] = tf.zeros_like(self.model.variables[i - 1])
        
        # Clear intermediate tensors      
        del w
        return loss, grad, f2, w1
                       
    #@tf.function  # type: ignore
    def plain_evaluation(self, cv: Tensor) -> Tensor:
        """
        VQE

        :param cv: [description]
        :type cv: Tensor
        :return: [description]
        :rtype: Tensor
        """
        # print(tf.math.real(vqe_energy_shortcut(self.circuit(cv), self.hamiltonian)))
        with tf.GradientTape() as tape:
            c2 = self.circuit(cv, self.theta_ry, self.theta_rz)
            w1 = c2.wavefunction()
            # c = self.circuit(cv)
            # c0 = self.circuit(cv) 
            # c = noisy(c0,2*len(self.edge)) # epoch*len(self.edge)
            # loss
            # compute E_i(For Pi_i)
            loss = tf.math.real(vqe_energy_shortcut(c2, self.h0))
            # grad
            grad = tape.gradient(loss, cv)
        del c2
        return loss, grad, w1
    

    def training(
        self,
        maxiter: int = 5000,
        optq: Optional[Callable[[int], Any]] = None,
        optc: Optional[Callable[[int], Any]] = None,
        threshold: float = 1e-8,
        debug: int = 100,
        onlyq: int = 0,
        checkpoints: Optional[List[Tuple[int, float]]] = None,
        qon: int = 1
    ) -> Tuple[Array, Array, Array, int, List[float]]:
        loss_prev = 0
        loss_opt = 1e8
        j_opt = 0
        nm_opt = 1
        ccount = 0
        self.qcache = self.circuit_variable.numpy()
        self.ccache = self.model.get_weights()
        
        
        # strategy 0
        if not optc:
            optc = 0.001  # type: ignore
        if isinstance(optc, float) or isinstance(
            optc, tf.keras.optimizers.schedules.LearningRateSchedule
        ):
            optc = tf.keras.optimizers.Adam(optc)
            # optc = tf.keras.optimizers.Adam(learning_rate=1e-4, epsilon=1e-8, clipnorm=1.0)
            # optc = tf.keras.optimizers.RMSprop(optc)
            # optc = tf.keras.optimizers.AdamW(optc)
        
        if isinstance(optc, tf.keras.optimizers.Optimizer):
            optcf = lambda _: optc
        else:
            optcf = optc  # type: ignore
        if not optq:
            optq = 0.01  # type: ignore 0.01
        if isinstance(optq, float) or isinstance(
            optq, tf.keras.optimizers.schedules.LearningRateSchedule
        ):
            optq = tf.keras.optimizers.Adam(optq)
        if isinstance(optq, tf.keras.optimizers.Optimizer):
            optqf = lambda _: optq
        else:
            optqf = optq  # type: ignore

        nm = tf.constant(1.0)
        times = []
        history = []
        qhist = []
        qgrad = []
        cgrad = []
        model_var = []
        amplitude_c = []
        w1_results = []
        qnon = 0
        try:
            for j in range(maxiter):
                if j < onlyq:
                    loss, grad, w1 = self.plain_evaluation(self.circuit_variable)
                    qhist.append(loss.numpy())                    
                else:
                    # loss, grad, f2, energies_sign = self.evaluation_dict(self.circuit_variable,loss_samples_dict)
                    loss, grad, f2, w1 = self.evaluation(self.circuit_variable)
                if not tf.math.is_finite(loss):
                    print("failed optimization since nan in %s tries" % j)
                    # in case numerical instability
                    break
                # if np.abs(loss - loss_prev) < threshold and qnon==0:  # 0.3e-7
                #     ccount += 1
                #     if ccount >= 100:
                #         # print("finished in %s round" % j)
                #         break

                history.append(loss.numpy())
                if checkpoints is not None:
                    bk = False
                    for rd, tv in checkpoints:
                        if j > rd and loss.numpy() > tv:
                            print("failed optimization, as checkpoint is not met")
                            bk = True
                            break
                    if bk:
                        break
                if debug > 0:
                    if j % debug == 0:
                        times.append(time.time())
                        print("energy estimation:", loss.numpy())

                        # quantume, _ = self.plain_evaluation(self.circuit_variable)
                        # print("quantum part energy: ", quantume.numpy())
                        if len(times) > 1:
                            print("running time: ", (times[-1] - times[-2]) / debug)
                loss_prev = loss                
                if j < onlyq:
                    gradofc = [grad]
                    optqf(j).apply_gradients(zip(gradofc, [self.circuit_variable]))
                else:
                    gradofc = grad[0:1]
                if loss < loss_opt:
                    loss_opt = loss
                    nm_opt = nm
                    j_opt = j
                    self.qcache = self.circuit_variable.numpy()
                    self.ccache = self.model.get_weights()
                if j >= onlyq:
                    # amplitude_c.append(f2.numpy())
                    if j == maxiter-1:
                        amplitude_c.append(f2.numpy())                      
                    optcf(j).apply_gradients(zip(grad[1], self.model.variables))
                    if j<qon and qnon==0:
                        optqf(j).apply_gradients(zip(gradofc, [self.circuit_variable]))
                w1_results.append(w1.numpy())
                if j == maxiter-1: 
                    qgrad.append(self.circuit_variable.numpy())
                    cgrad.append(self.model.variables)
                    model_var.append(self.model.get_weights())
        except KeyboardInterrupt:
            pass

        # quantume, _ = self.plain_evaluation(self.circuit_variable)
        print(
            "vqnhe prediction: ",
            loss_prev.numpy(),  # type: ignore
            # "quantum part energy: ",
            # quantume.numpy(),
            "classical model scale: ",
            self.model.variables[-1].numpy(),
        )
        print("----------END TRAINING------------")
        self.history += history[:j_opt]
        return (
            loss_opt.numpy(),  # type: ignore
            #np.real(nm_opt.numpy()),  # type: ignore
            model_var,
            qhist,
            j_opt,
            # history[:j_opt+1],
            history,
            qgrad,
            cgrad,
            amplitude_c,
            w1_results
        )

    def multi_training(
        self,
        maxiter: int = 5000,
        optq: Optional[Callable[[int], Any]] = None,
        optc: Optional[Callable[[int], Any]] = None,
        threshold: float = 1e-8,
        debug: int = 150,
        onlyq: int = 0,
        checkpoints: Optional[List[Tuple[int, float]]] = None,
        tries: int = 10,
        initialization_func: Optional[Callable[[int], Dict[str, Any]]] = None,
        qon: int = 1,
    ) -> List[Dict[str, Any]]:
        # TODO(@refraction-ray): old multiple training implementation, we can use vmap infra for batched training
        rs = []
        try:
            for t in range(tries):
                print("---------- %s training loop ----------" % t)
                if initialization_func is not None:
                    weights = initialization_func(t)
                else:
                    weights = {}
                qweights = weights.get("q", None)
                cweights = weights.get("c", None)
                if cweights is None:
                    cweights = self.create_model(**self.model_params).get_weights()
                self.model.set_weights(cweights)
                if qweights is None:
                    self.circuit_variable = tf.Variable(
                        tf.random.normal(
                            mean=0.0,
                            stddev=self.circuit_stddev,
                            shape=[self.epochs, self.n, self.channel],
                            dtype=tf.float64,
                        )
                    )
                else:
                    self.circuit_variable = qweights
                    # qon=1
                self.history = []  # refresh the history
                r = self.training(
                    maxiter, optq, optc, threshold, debug, onlyq, checkpoints,qon
                )
                rs.append(
                    {
                        "energy": r[0],
                        "model_var": r[1],
                        "quantum_energy": r[2],
                        "iterations": r[3],
                        "history": r[4],
                        "qgrad": r[5],
                        "cgrad": r[6],
                        "amp_f2": r[7],
                        "wave": r[8],
                        "model_weights": self.ccache,
                        "circuit_weights": self.qcache,
                    }
                )
        except KeyboardInterrupt:
            pass

        if rs:
            es = [r["energy"] for r in rs]
            ind = np.argmin(es)
            self.assign(rs[ind]["model_weights"], rs[ind]["circuit_weights"])  # type: ignore
            self.history = rs[ind]["history"]  # type: ignore
        return rs

