#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 16 04:05:25 2024

VQNHE sampling (noise)

@author: Mengzhen
"""

from functools import lru_cache
import functools as ft
from functools import partial
from itertools import product
import time
from typing import (
    List,
    Any,
    Tuple,
    Callable,
    Optional,
    Dict,
)

import numpy as np
import math
import tensorflow as tf
from tqdm import tqdm
from ..circuit import Circuit
from ..quantum import generate_local_hamiltonian
from .. import gates as G
from .. import channels, noisemodel, set_backend

from tensorflow.keras.layers import Input, Dense, Dropout, BatchNormalization
from tensorflow.keras.optimizers.schedules import LearningRateSchedule
# noise
error1 = channels.generaldepolarizingchannel(0.0013, 1)
error2 = channels.generaldepolarizingchannel(0.005, 2)
# # error2 = tc.channels.thermalrelaxationchannel(300, 400, 100, "AUTO", 0.1)
# readout_error = [0.998, 0.976]
noise_conf = noisemodel.NoiseConf()
# noise_conf.add_noise("h", error1)
noise_conf.add_noise("rz", error1)
noise_conf.add_noise("rzz", error2)
# noise_conf.add_noise("readout", readout_error)
# # Apply noise to the circuit
K = set_backend("tensorflow")

#
tf.compat.v1.enable_eager_execution()
Tensor = Any
Array = Any
Model = Any
dtype = np.complex128
# only guarantee compatible with float64 mode
# only support tf backend

x = np.array([[0, 1.0], [1.0, 0]], dtype=dtype)
y = np.array([[0, -1j], [1j, 0]], dtype=dtype)
z = np.array([[1, 0], [0, -1]], dtype=dtype)
xx = np.array([[0, 0, 0, 1], [0, 0, 1, 0], [0, 1, 0, 0], [1, 0, 0, 0]], dtype=dtype)
yy = np.array([[0, 0, 0, -1], [0, 0, 1, 0], [0, 1, 0, 0], [-1, 0, 0, 0]], dtype=dtype)
zz = np.array([[1, 0, 0, 0], [0, -1, 0, 0], [0, 0, -1, 0], [0, 0, 0, 1]], dtype=dtype)
swap = np.array([[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 1]], dtype=dtype)
s_dagger = np.array([[1, 0], [0, -1j]], dtype=dtype)
S = np.array([[1, 0], [0, 1j]], dtype=dtype)
Y2M = np.array([[np.cos(np.pi/4),np.sin(np.pi/4)], [-np.sin(np.pi/4),np.cos(np.pi/4)]], dtype=dtype)
Y2P = np.array([[np.cos(np.pi/4),-np.sin(np.pi/4)], [np.sin(np.pi/4),np.cos(np.pi/4)]], dtype=dtype)
X2M = np.array([[np.cos(np.pi/4),1j*np.sin(np.pi/4)], [1j*np.sin(np.pi/4),np.cos(np.pi/4)]], dtype=dtype)
X2P = np.array([[np.cos(np.pi/4),-1j*np.sin(np.pi/4)], [-1j*np.sin(np.pi/4),np.cos(np.pi/4)]], dtype=dtype)

pauli = [np.eye(2), x, y, z]

# Define the basis vectors
zero_state = np.array([1.0,0], dtype=dtype) 
one_state = np.array([0,1.0], dtype=dtype) 


@lru_cache()
def paulistring(term: Tuple[int, ...]) -> Array:
    n = len(term)
    if n == 1:
        return pauli[term[0]]
    ps = np.kron(pauli[term[0]], paulistring(tuple(list(term)[1:])))
    return ps


def construct_matrix(ham: List[List[float]]) -> Array:
    # deprecated
    # only suitable for matrix of small Hilbert dimensions, say <14 qubits
    h = 0.0j
    for term in ham:
        term = list(term)
        for i, t in enumerate(term):
            if i > 0:
                term[i] = int(t)
        h += term[0] * paulistring(tuple(term[1:]))
    return h


# replace with QuOperator tensor_product approach for Hamiltonian construction
# i.e. using ``construct_matrix_v2``


def construct_matrix_tf(ham: List[List[float]], dtype: Any = tf.complex128) -> Tensor:
    # deprecated
    h = 0.0j
    for term in ham:
        term = list(term)
        for i, t in enumerate(term):
            if i > 0:
                term[i] = int(t)
        h += tf.cast(term[0], dtype=dtype) * tf.constant(
            paulistring(tuple(term[1:])), dtype=dtype
        )
    return h


_generate_local_hamiltonian = tf.function(generate_local_hamiltonian)


def construct_matrix_v2(ham: List[List[float]], dtype: Any = tf.complex128) -> Tensor:
    # deprecated
    s = len(ham[0]) - 1
    h = tf.zeros([2**s, 2**s], dtype=dtype)
    for term in tqdm(ham, desc="Hamiltonian building"):
        term = list(term)
        for i, t in enumerate(term):
            if i > 0:
                term[i] = int(t)
        local_matrix_list = [tf.constant(pauli[t], dtype=dtype) for t in term[1:]]
        h += tf.cast(term[0], dtype=dtype) * tf.cast(
            _generate_local_hamiltonian(*local_matrix_list), dtype=dtype
        )
    return h


def construct_matrix_v3(ham: List[List[float]], dtype: Any = tf.complex128) -> Tensor:
    from ..quantum import PauliStringSum2COO

    sparsem = PauliStringSum2COO([h[1:] for h in ham], [h[0] for h in ham])  # type: ignore
    return sparsem
    # densem = backend.to_dense(sparsem)
    # return tf.cast(densem, dtype)


# def vqe_energy(c: Circuit, h: List[List[float]], reuse: bool = True) -> Tensor:
#     loss = 0.0
#     for term in h:
#         ep = []
#         for i, t in enumerate(term[1:]):
#             if t == 3:
#                 ep.append((G.z(), [i]))  # type: ignore
#             elif t == 1:
#                 ep.append((G.x(), [i]))  # type: ignore
#             elif t == 2:
#                 ep.append((G.y(), [i]))  # type: ignore
#         if ep:
#             loss += term[0] * c.expectation(*ep, reuse=reuse)
#         else:
#             loss += term[0]

#     return loss
def pauli_matrix(pauli_op):
    if pauli_op == 1:
        return tf.constant([[0, 1], [1, 0]], dtype=tf.complex128)  # X
    elif pauli_op == 2:
        return tf.constant([[0, -1j], [1j, 0]], dtype=tf.complex128)  # Y
    elif pauli_op == 3:
        return tf.constant([[1, 0], [0, -1]], dtype=tf.complex128)  # Z
    else:
        return tf.eye(2, dtype=tf.complex128)  # I

def pauli_product(pauli_indices, pauli_ops):
    matrix = tf.eye(1, dtype=tf.complex128)
    for idx, op in zip(pauli_indices, pauli_ops):
        matrix = tf.experimental.numpy.kron(matrix, pauli_matrix(op))
    return matrix

def pauli_hamiltonian(term):
    pauli_ops = term[1:]
    pauli_indices = list(range(len(pauli_ops)))
    matrix = pauli_product(pauli_indices, pauli_ops)
    return matrix

# def ry_gate(theta):
#     cos_theta_2 = tf.cos(theta / 2)
#     sin_theta_2 = tf.sin(theta / 2)
#     return tf.reshape(tf.stack([cos_theta_2, -sin_theta_2, sin_theta_2, cos_theta_2]), [2, 2])

# def tensor_product_gates(*gates):
#     result = tf.eye(1, dtype=gates[0].dtype)
#     for gate in gates:
#         result = tf.experimental.numpy.kron(result, gate)
#     return result


def string_to_quantum_state(binary_string):
    states = []
    for char in binary_string:
        if char == '0':
            states.append(zero_state)
        elif char == '1':
            states.append(one_state)
    # Compute the tensor product of all states in the list
    quantum_state = ft.reduce(np.kron, states)
    return quantum_state

def v_and_sample(term, d):
    paulis_with_positions = term[1:]
    samp_num=int(1200)
    item = next((item for item in paulis_with_positions if item != 0), None)
    if item==3:
        samples=d.sample(allow_state=True, batch=samp_num, format="count_dict_bin")
    elif item==2:
        ind_2 = [i for i, x in enumerate(paulis_with_positions) if x == 2]
        d.cy(ind_2[0],ind_2[1])
        d.any(ind_2[0],unitary=s_dagger)
        d.h(ind_2[0])
        samples=d.sample(allow_state=True, batch=samp_num, format="count_dict_bin")
    else:
        ind_1 = [i for i, x in enumerate(paulis_with_positions) if x == 1]
        d.cx(ind_1[0],ind_1[1])
        d.h(ind_1[0])
        samples=d.sample(allow_state=True, batch=samp_num, format="count_dict_bin")
    return samples

def loss_dict_h(c,h):
    loss_dict = {}
    for term in h:
        d = c.copy() 
        counts = v_and_sample(term, d)
        loss_dict[str(term[1:])] = counts 
    all_outcomes = set()
    for key in loss_dict:
        for outcome in loss_dict[key]:
            all_outcomes.add(outcome)
    summed_values = {outcome: 0 for outcome in all_outcomes}
    for key in loss_dict:
        if '3' in key:
            for outcome, count in loss_dict[key].items():
                summed_values[outcome] += count
    for key in loss_dict:
        if '3' in key:
            loss_dict[key] = summed_values
    return loss_dict
# def B(C_y,item,bitstring,stq,stq_1,S_stq,f2,sz):
#     if not sz:
#         s0=int(bitstring[item])
#         s_star = 1-2*s0
#     else:
#         s0=int(bitstring[item])
#         s1=int(bitstring[sz[0]])
#         s_star=(1-2*s0)*(1-2*s1)
#     f_0 = np.dot(f2,stq)
#     f_1 = np.dot(f2,stq_1)
#     # f_0 = tf.tensordot(f2, stq, axes=1)
#     # f_1 = tf.tensordot(f2, stq_1, axes=1)
#     ind_0 = np.where(stq == 1)[0][0]
#     ind_1 = np.where(stq_1 == 1)[0][0]
#     # ind_0 = tf.where(stq == 1).numpy()[0][0]
#     # ind_1 = tf.where(stq_1 == 1).numpy()[0][0]
#     c00 = C_y[ind_0, ind_0]
#     c01 = C_y[ind_0, ind_1]
#     c10 = C_y[ind_1, ind_0]
#     c11 = C_y[ind_1, ind_1]
#     # Bvalue=0.5*f_0*f_1*(s_star*(c00*c11.conj()+S_stq**2*c10*c01.conj()) + S_stq*(c10*c11.conj()+c00*c01.conj()))
#     Bvalue=f_0*f_1*s_star*c00*c11
#     return Bvalue
    

# def measurement(C_y,item,pau,samples,f2,samp_num,sz):
#     Ep = 0
#     for bitstring, count in samples.items():
#         bitstring_f = bitstring
#         bitstring_f = bitstring[:item]+'0'+bitstring[item+1:]
#         stq = string_to_quantum_state(bitstring_f)
#         stq_tf = tf.constant(stq, dtype=tf.complex128)
#         #stq_1 = abs(np.dot(pau,stq))
#         stq_1_tf = tf.linalg.matvec(pau, stq_tf)
#         S0 = sum(stq_1_tf)
#         stq_1_tf = tf.cast(tf.abs(stq_1_tf), tf.complex128)
#         S1 = 1/S0
#         B01 = B(C_y,item,bitstring,stq_tf,stq_1_tf,S0,f2,sz)
#         # B10 = B(C_y,item,bitstring,stq_1_tf,stq_tf,S1,f2,sz)
#         probability = count / samp_num
#         Ep += probability*B01
#     return Ep

def B(item,bitstring,stq,stq_1,f2,sz):
    s0=int(bitstring[item])
    s_star = 1-2*s0
    if sz:
        s_star = 1
        for idx in range(len(sz)):
            s1=int(bitstring[sz[idx]])
            s_star=s_star*(1-2*s1)
    f_0 = tf.tensordot(f2, stq, axes=1)
    f_1 = tf.tensordot(f2, stq_1, axes=1)
    Bvalue=s_star*f_0*f_1
    return Bvalue
    

def measurement(item,pau,samples,f2,samp_num,sz):
    Ep = 0
    for bitstring, count in samples.items():  
        # bitstring = bitstring[::-1]
        bitstring_f = bitstring
        if not sz:
            bitstring_f = bitstring[:item]+'0'+bitstring[item+1:]
        stq = string_to_quantum_state(bitstring_f)
        stq_tf = tf.constant(stq, dtype=tf.complex128)
        #stq_1 = abs(np.dot(pau,stq))
        stq_1_tf = tf.linalg.matvec(pau, stq_tf)
        # S0 = sum(stq_1_tf)
        stq_1_tf = tf.cast(tf.abs(stq_1_tf), tf.complex128)
        # S1 = 1/S0
        B01 = B(item,bitstring,stq_tf,stq_1_tf,f2,sz)      
        probability = count / samp_num
        Ep += probability*B01
    return Ep


# def vqe_energy(C_y,c, h, f2, n):
#     exp_q=0
#     exp_c=0
#     sz=None
#     for term in h:
#         num = 0
#         d=c.copy()
#         samp_num=int(1200)
#         for i, t in enumerate(term[1:]):
#             if t == 3 and num==0:
#                 num=1
#                 pau = pauli_hamiltonian(term)
#                 pau_f2=tf.matmul(pau, tf.expand_dims(f2, axis=-1))
#                 f2_conj_column = tf.expand_dims(tf.math.conj(f2), axis=-1)
#                 fpf = tf.reduce_sum(tf.multiply(f2_conj_column, pau_f2))
#                 #exp_c = exp_c + (1/2**n)*term[0]*fpf
#                 exp_c = exp_c + term[0]*fpf
#             elif t == 1 and sum(term[1:i+2])==1:
#                 item1=i
#             elif t == 1 and sum(term[1:i+2])>1:
#                 d.cx(item1,i)
#                 d.h(item1)
#                 samples=d.sample(allow_state=True, batch=samp_num, format="count_dict_bin")
#                 pau = pauli_hamiltonian(term)
#                 exp_q = exp_q + term[0]*measurement(C_y,item1,pau,samples,f2,samp_num,sz)
#             elif t == 2 and sum(term[1:i+2])==2:
#                 item2=i
#             elif t == 2 and sum(term[1:i+2])>2:
#                 d.cy(item2,i)
#                 d.any(item2,unitary=s_dagger)
#                 d.h(item2)
#                 samples=d.sample(allow_state=True, batch=samp_num, format="count_dict_bin")
#                 pau = pauli_hamiltonian(term)
#                 exp_q = exp_q + term[0]*measurement(C_y,item2,pau,samples,f2,samp_num,sz)    
#     #loss = exp_c+exp_q
#     loss = exp_c+exp_q*(2**n)
#     return loss

def vqe_energy(h, f2, loss_dict):
    exp_n=0
    exp_d=0
    # sz=None
    for term in h:
        sz=[i for i, x in enumerate(term[1:]) if x == 3]
        non_zero_positions = [index for index, value in enumerate(term[1:]) if value != 0]        
        term_input_str = str(term[1:])
        samples = loss_dict[term_input_str]
        samp_num = sum(samples.values())
        pau = pauli_hamiltonian(term)
        pau = tf.constant(pau,dtype)
        exp_n = exp_n + term[0]*measurement(non_zero_positions[0],pau,samples,f2,samp_num,sz)        
    samples = loss_dict[str([3,3,0])]
    samp_num = sum(samples.values())
    for bitstring, count in samples.items():
        stq = string_to_quantum_state(bitstring)
        stq_tf = tf.constant(stq, dtype=tf.complex128)
        f_0 = tf.tensordot(f2, stq_tf, axes=1)          
        probability = count / samp_num
        exp_d = exp_d+probability*(f_0**2)
    loss = exp_n/exp_d
    return loss


def vqe_energy_shortcut(c: Circuit, h: Tensor) -> Tensor:
    from ..templates.measurements import operator_expectation
    return operator_expectation(c, h)


def qstep_energy(c, h):
    exp_q=0
    for term in h:
        d=c.copy()
        samp_num=int(1200)
        for i, t in enumerate(term[1:]):
            if t==1:
                d.h(i)
            elif t==2:
                d.any(i,unitary=s_dagger)
                d.h(i)
            # elif t==3:
            #     d.z(i)
        non_zero_positions = [index for index, value in enumerate(term[1:]) if value != 0]        
        samples=d.sample(allow_state=True, batch=samp_num, format="count_dict_bin")                        
        expectation_value = 0
        for bitstring, count in samples.items():              
            eigenvalue = 1
            for pos in non_zero_positions:
                if bitstring[pos] == '1':
                    eigenvalue *= -1                
            probability = count / samp_num
            expectation_value += eigenvalue * probability
        exp_q += term[0]*expectation_value
    return exp_q

def vqe_exp_dict(n,c,h):
    samp_num=int(1200)
    d1 = c.copy()
    d2 = c.copy()
    d3 = c.copy()
    vqe_dict = {}
    for i in range(n):
        d1.h(i)
        d2.any(i,unitary=s_dagger)
        d2.h(i)
    samples1=d1.sample(allow_state=True, batch=samp_num, format="count_dict_bin")
    samples2=d2.sample(allow_state=True, batch=samp_num, format="count_dict_bin")
    samples3=d3.sample(allow_state=True, batch=samp_num, format="count_dict_bin")
    for term in h:
        non_zero_positions = [index for index, value in enumerate(term[1:]) if value != 0]
        if 1 in term[1:]:
            expectation_value = 0
            for bitstring, count in samples1.items():              
                eigenvalue = 1
                for pos in non_zero_positions:
                    if bitstring[pos] == '1':
                        eigenvalue *= -1                
                probability = count / samp_num
                expectation_value += eigenvalue * probability
        elif 2 in term[1:]:
            expectation_value = 0
            for bitstring, count in samples2.items():              
                eigenvalue = 1
                for pos in non_zero_positions:
                    if bitstring[pos] == '1':
                        eigenvalue *= -1                
                probability = count / samp_num
                expectation_value += eigenvalue * probability
        else:
            expectation_value = 0
            for bitstring, count in samples3.items():              
                eigenvalue = 1
                for pos in non_zero_positions:
                    if bitstring[pos] == '1':
                        eigenvalue *= -1                
                probability = count / samp_num
                expectation_value += eigenvalue * probability
        vqe_dict[str(term[1:])] = expectation_value
    return vqe_dict

def qstep_energy_dict(h,vqe_dict):
    exp_q=0
    for term in h:
        expectation_value = vqe_dict[str(term[1:])]
        exp_q += term[0]*expectation_value
    return exp_q

# grad
def generate_sample_terms(h):
    h_sample = []  
    for term in h:
        weight = term[0]  
        paulis = term[1:]  
        if all(pauli in (0, 1) for pauli in paulis):
            for i, pauli in enumerate(paulis):
                if pauli == 1:
                    new_term = paulis[:i] + [2] + paulis[i+1:]
                    h_sample.append([1] + new_term)
    return h_sample


def v_and_sample_grad(term, d):
    paulis_with_positions = term[1:]
    samp_num=int(1200)
    ind_2 = [i for i, x in enumerate(paulis_with_positions) if x == 2]
    ind_1 = [i for i, x in enumerate(paulis_with_positions) if x == 1]
    for i in ind_1:
        for j in ind_2:
            d.cx(j, i)
            d.any(j,unitary=s_dagger)
            d.h(j)
    samples=d.sample(allow_state=True, batch=samp_num, format="count_dict_bin")
    return samples


def gradz_energy(h, n, index, edge_list, cv_size, samples_dict, f2):
    gradz_eny = 0
    samp_num = int(1200)
    updated_h = []  
    for term in h:
        weight, paulis = term[0], term[1:]
        sz = [0.5]
        if index < n:
            if paulis[index] == 1:
                new_paulis = paulis[:index] + [2] + paulis[index+1:]
                new_weight = -weight
                updated_h.append([new_weight] + new_paulis + sz)
            elif paulis[index] == 2:
                new_paulis = paulis[:index] + [1] + paulis[index+1:]
                new_weight = weight
                updated_h.append([new_weight] + new_paulis + sz)
        elif index < cv_size and index>=n:
            index_new = edge_list[index - n]
            current_val = (paulis[index_new[0]], paulis[index_new[1]])
            if current_val == (0, 0):
                new_weight = 0
                new_paulis = paulis
            elif current_val == (0, 1):
                new_paulis = paulis[:index_new[1]] + [2] + paulis[index_new[1]+1:]
                new_weight = -weight
                sz = [index_new[0]]
                updated_h.append([new_weight] + new_paulis + sz)                
            elif current_val == (0, 2):
                new_paulis = paulis[:index_new[1]] + [1] + paulis[index_new[1]+1:]
                new_weight = weight
                sz = [index_new[0]]
                updated_h.append([new_weight] + new_paulis + sz)                
            elif current_val == (1, 0):
                new_paulis = paulis[:index_new[0]] + [2] + paulis[index_new[0]+1:]
                new_weight = -weight
                sz = [index_new[1]]
                updated_h.append([new_weight] + new_paulis + sz)                
            elif current_val == (2, 0):
                new_paulis = paulis[:index_new[0]] + [1] + paulis[index_new[0]+1:]
                new_weight = weight
                sz = [index_new[1]]
                updated_h.append([new_weight] + new_paulis + sz)
            else:
                new_weight = 0
                new_paulis = paulis
    for update_term in updated_h:
        term_input = update_term[:-1]
        term_input_str = str(term_input[1:])
        samples = samples_dict[term_input_str]
        pau = pauli_hamiltonian(term_input)
        item2 = [i for i, x in enumerate(term_input[1:]) if x == 2][0]
        sz = [update_term[-1]]
        if sz[0]==0.5:
            sz=None
        gradz_eny = gradz_eny + term_input[0]*measurement(item2,pau,samples,f2,samp_num,sz)
    return gradz_eny


# stop sampling stragey
# def loss_sample(h, c):
#     loss_samples_dict = {}
#     for term in h:
#         num = 0
#         d=c.copy()
#         samp_num=int(1200)
#         for i, t in enumerate(term[1:]):
#             if t == 1 and sum(term[1:i+2])==1:
#                 item1=i
#             elif t == 1 and sum(term[1:i+2])>1:
#                 d.cx(item1,i)
#                 d.h(item1)
#                 samples=d.sample(allow_state=True, batch=samp_num, format="count_dict_bin")
#                 loss_samples_dict[str(term[1:])] = samples
#             elif t == 2 and sum(term[1:i+2])==2:
#                 item2=i
#             elif t == 2 and sum(term[1:i+2])>2:
#                 d.cy(item2,i)
#                 d.any(item2,unitary=s_dagger)
#                 d.h(item2)
#                 samples=d.sample(allow_state=True, batch=samp_num, format="count_dict_bin")
#                 loss_samples_dict[str(term[1:])] = samples
#     return loss_samples_dict

# def vqe_energy_sample_dict(C_y, h, f2, n, loss_samples_dict):
#     exp_q=0
#     exp_c=0
#     sz=None
#     for term in h:
#         num = 0
#         samp_num=int(1200)
#         for i, t in enumerate(term[1:]):
#             if t == 3 and num==0:
#                 num=1
#                 pau = pauli_hamiltonian(term)
#                 pau_f2=tf.matmul(pau, tf.expand_dims(f2, axis=-1))
#                 f2_conj_column = tf.expand_dims(tf.math.conj(f2), axis=-1)
#                 fpf = tf.reduce_sum(tf.multiply(f2_conj_column, pau_f2))
#                 #exp_c = exp_c + (1/2**n)*term[0]*fpf
#                 exp_c = exp_c + term[0]*fpf
#             elif t == 1 and sum(term[1:i+2])==1:
#                 item1=i
#             elif t == 1 and sum(term[1:i+2])>1:
#                 term_input_str = str(term[1:])
#                 samples = loss_samples_dict[term_input_str]
#                 pau = pauli_hamiltonian(term)
#                 exp_q = exp_q + term[0]*measurement(C_y,item1,pau,samples,f2,samp_num,sz)
#             elif t == 2 and sum(term[1:i+2])==2:
#                 item2=i
#             elif t == 2 and sum(term[1:i+2])>2:
#                 term_input_str = str(term[1:])
#                 samples = loss_samples_dict[term_input_str]
#                 pau = pauli_hamiltonian(term)
#                 exp_q = exp_q + term[0]*measurement(C_y,item2,pau,samples,f2,samp_num,sz)    
#     #loss = exp_c+exp_q
#     loss = exp_c+exp_q*(2**n)
#     return loss

x = K.implicit_randn(100)
def noisy(c: Circuit):
    # x = K.implicit_randn(nn)
    noisy_circuit = noisemodel.circuit_with_noise(c, noise_conf=noise_conf,status=x)
    return noisy_circuit



class Linear_real(tf.keras.layers.Layer):  # type: ignore
    """
    Dense layer with real weights, used for building real RBM
    """

    def __init__(self, units: int, input_dim: int, stddev: float = 0.1) -> None:
        super().__init__()
        self.wr = tf.Variable(
            initial_value=tf.random.normal(
                shape=[input_dim, units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )
        self.wi = tf.Variable(
            initial_value=tf.random.normal(
                shape=[input_dim, units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )
        self.br = tf.Variable(
            initial_value=tf.random.normal(
                shape=[units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )
        self.bi = tf.Variable(
            initial_value=tf.random.normal(
                shape=[units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )

    def call(self, inputs: Tensor) -> Tensor:
        inputs = tf.cast(inputs, dtype=dtype)
        return (
            tf.matmul(
                inputs,
                tf.cast(self.wr, dtype=dtype)
                + 1.0 * tf.cast(self.wi, dtype=dtype),
            )
            + tf.cast(self.br, dtype=dtype)
            + 1.0 * tf.cast(self.bi, dtype=dtype)
        )



class Linear(tf.keras.layers.Layer):  # type: ignore
    """
    Dense layer but with complex weights, used for building complex RBM
    """

    def __init__(self, units: int, input_dim: int, stddev: float = 0.1) -> None:
        super().__init__()
        self.wr = tf.Variable(
            initial_value=tf.random.normal(
                shape=[input_dim, units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )
        self.wi = tf.Variable(
            initial_value=tf.random.normal(
                shape=[input_dim, units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )
        self.br = tf.Variable(
            initial_value=tf.random.normal(
                shape=[units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )
        self.bi = tf.Variable(
            initial_value=tf.random.normal(
                shape=[units], stddev=stddev, dtype=tf.float64
            ),
            trainable=True,
        )

    def call(self, inputs: Tensor) -> Tensor:
        inputs = tf.cast(inputs, dtype=dtype)
        return (
            tf.matmul(
                inputs,
                tf.cast(self.wr, dtype=dtype) + 1.0j * tf.cast(self.wi, dtype=dtype),
            )
            + tf.cast(self.br, dtype=dtype)
            + 1.0j * tf.cast(self.bi, dtype=dtype)
        )


class JointSchedule(tf.keras.optimizers.schedules.LearningRateSchedule):  # type: ignore
    def __init__(
        self,
        steps: int = 300,
        pre_rate: float = 0.1,
        pre_decay: int = 400,
        post_rate: float = 0.001,
        post_decay: int = 4000,
        dtype: Any = tf.float64,
    ) -> None:
        super().__init__()
        self.steps = steps
        self.pre_rate = pre_rate
        self.pre_decay = pre_decay
        self.post_rate = post_rate
        self.post_decay = post_decay
        self.dtype = dtype

    def __call__(self, step: Tensor) -> Tensor:
        if step < self.steps:
            return tf.constant(self.pre_rate, dtype=self.dtype) * (1 / 2.0) ** (
                (tf.cast(step, dtype=self.dtype)) / self.pre_decay
            )
        else:
            return tf.constant(self.post_rate, dtype=self.dtype) * (1 / 2.0) ** (
                (tf.cast(step, dtype=self.dtype) - self.steps) / self.post_decay
            )


class VQNHE:
    def __init__(
        self,
        theta_ry,
        theta_rz,
        n: int,
        h0,
        hamiltonian: List[List[float]],
        model_params: Optional[Dict[str, Any]] = None,
        circuit_params: Optional[Dict[str, Any]] = None,
        shortcut: bool = False,
    ) -> None:
        self.n = n
        self.theta_ry = theta_ry
        self.theta_rz = theta_rz if theta_rz is not None else np.array([])
        if not model_params:
            model_params = {}
        self.model = self.create_model(**model_params)
        self.model_params = model_params
        self.cut = model_params.get("cut", 20)
        if not circuit_params:
            circuit_params = {"epochs": 2, "stddev": 0.1}
        self.epochs = circuit_params.get("epochs", 2)
        self.circuit_stddev = circuit_params.get("stddev", 0.1)
        self.channel = circuit_params.get("channel", 2)
        self.edge = circuit_params.get("edge")
        t = n + len(self.edge)  
        self.circuit_variable = tf.Variable(
            tf.random.normal(
                mean=0.0,
                stddev=self.circuit_stddev,
                shape=[t],
                dtype=tf.float64,
            )
        )
        self.circuit = self.create_circuit(**circuit_params)
        self.base = tf.constant(list(product(*[[0, 1] for _ in range(n)])))
        self.hamiltonian = hamiltonian
        self.h0=h0
        self.h_sample = generate_sample_terms(self.hamiltonian)
        self.shortcut = shortcut
        self.history: List[float] = []

    def assign(
        self, c: Optional[List[Tensor]] = None, q: Optional[Tensor] = None
    ) -> None:
        if c is not None:
            self.model.set_weights(c)
        if q is not None:
            self.circuit_variable.assign(q)

    def recover(self) -> None:
        try:
            self.assign(self.ccache, self.qcache)
        except AttributeError:
            pass

    def load(self, path: str) -> None:
        w = np.load(path, allow_pickle=True)
        self.assign(w["c"], w["q"])
        self.history = list(w["h"])

    def save(self, path: str) -> None:
        np.savez(path, c=self.ccache, q=self.qcache, h=np.array(self.history))

    def create_model(self, choose: str = "real", **kws: Any) -> Model:
        if choose == "real":
            return self.create_real_model(**kws)
        if choose == "complex":
            return self.create_complex_model(**kws)
        if choose == "real-rbm":
            return self.create_real_rbm_model(**kws)
        if choose == "complex-rbm":
            return self.create_complex_rbm_model(**kws)

    # def create_real_model(
    #     self,
    #     init_value: float = 0.1,
    #     max_value: float = 1.0,
    #     min_value: float = 0,
    #     depth: int = 2,
    #     width: int = 2,
    #     **kws: Any,
    # ) -> Model:

    #     model = tf.keras.Sequential()
    #     for _ in range(depth):
    #         model.add(tf.keras.layers.Dense(width * self.n, activation=partial(tf.nn.leaky_relu, alpha=0.01)))

    #     model.add(tf.keras.layers.Dense(1, activation="tanh"))
    #     model.add(
    #         tf.keras.layers.Dense(
    #             1,
    #             activation=None,
    #             use_bias=False,
    #             kernel_initializer=tf.keras.initializers.Constant(value=init_value),
    #             kernel_constraint=tf.keras.constraints.MinMaxNorm(
    #                 min_value=min_value,
    #                 max_value=max_value,
    #             ),
    #         )
    #     )
    #     model.build([None, self.n])
    #     return model
    
    # def create_real_model(
    #     self,
    #     init_value: float = 0.1,
    #     max_value: float = 1.0,
    #     min_value: float = 0,
    #     depth: int = 2,
    #     width: int = 2,
    #     activation: str = 'elu',  
    #     **kws: Any,
    # ) -> Model:

    #     model = tf.keras.Sequential()

    #     if depth <= 3:
    #         activation_fn = 'elu'
    #     else:
    #         activation_fn = 'selu'
            
    #     for _ in range(depth):
    #         model.add(tf.keras.layers.Dense(
    #             width * self.n,
    #             activation=activation_fn,
    #             kernel_initializer='he_normal' if activation_fn != 'selu' else 'lecun_normal'
    #         ))
    #         model.add(tf.keras.layers.Dropout(0.1))

    #     model.add(tf.keras.layers.Dense(1, activation='softplus'))

    #     model.add(tf.keras.layers.Dense(1, activation=None, use_bias=False,...))
        
    #     return model
    
    def create_real_model(
        self,
        init_value: float = 0.1,
        max_value: float = 1.0,
        min_value: float = 0,
        depth: int = 2,
        width: int = 2,
        seed: int = None,
        **kws: Any,
    ) -> Model:
        
        if seed is None:
            seed = np.random.randint(0, 1000000)

        model = tf.keras.Sequential()
        
        for i in range(depth):

            model.add(tf.keras.layers.Dense(
                width * self.n,
                kernel_initializer=tf.keras.initializers.HeNormal(seed=seed + i),
                kernel_constraint=tf.keras.constraints.MaxNorm(3),
                bias_initializer='zeros'
            ))

            model.add(tf.keras.layers.ELU())

            model.add(tf.keras.layers.Dropout(0.1))

        model.add(tf.keras.layers.Dense(
            1,
            activation='tanh',
            kernel_initializer=tf.keras.initializers.HeNormal(seed=seed + depth),
            kernel_constraint=tf.keras.constraints.MaxNorm(3)
        ))
        
        model.add(
            tf.keras.layers.Dense(
                1,
                activation=None,
                use_bias=False,
                kernel_initializer=tf.keras.initializers.Constant(value=init_value),
                kernel_constraint=tf.keras.constraints.MinMaxNorm(
                    min_value=min_value,
                    max_value=max_value,
                ),
            )
        )
        
        model.build([None, self.n])
        return model
    

    def create_complex_model(
        self,
        init_value: float = 0.0,
        max_value: float = 1.0,
        min_value: float = 0,
        d: list = [1,1,1,1],
        **kws: Any,
    ) -> Model:
        inputs = tf.keras.layers.Input(shape=[self.n])
        x = tf.keras.layers.Dense(d[0] * self.n, activation="relu")(inputs)
        x = tf.keras.layers.Dense(d[1] * self.n, activation="relu")(x)

        lnr = tf.keras.layers.Dense(d[2]*self.n, activation="relu")(x)
        lnr = tf.keras.layers.Dense(d[2]*self.n, activation=None)(lnr)
        lnr = tf.math.log(tf.math.cosh(lnr))
        # lnr = lnr + inputs

        phi = tf.keras.layers.Dense(d[3]*self.n, activation="relu")(x)
        phi = tf.keras.layers.Dense(d[3]*self.n, activation="relu")(phi)
        # phi = phi + inputs

        lnr = tf.keras.layers.Dense(1, activation=None)(lnr)
        # lnr = tf.keras.layers.Dense(
        #     1,
        #     activation=None,
        #     use_bias=False,
        #     kernel_initializer=tf.keras.initializers.Constant(value=init_value),
        #     kernel_constraint=tf.keras.constraints.MinMaxNorm(
        #         min_value=min_value,
        #         max_value=max_value,
        #     ),
        # )(lnr)
        phi = tf.keras.layers.Dense(1, activation="tanh")(phi)
        lnr = tf.cast(lnr, dtype=tf.complex128)
        phi = tf.cast(phi, dtype=tf.complex128)
        phi = 3.14159j * phi
        outputs = lnr + phi
        model = tf.keras.Model(inputs=inputs, outputs=outputs)
        return model

    # def create_real_rbm_model(
    #     self, stddev: float = 0.1, width: int = 2, **kws: Any
    # ) -> Model:
    #     inputs = tf.keras.layers.Input(shape=[self.n])
    #     x = tf.keras.layers.Dense(width * self.n, activation=None)(inputs)
    #     x = tf.math.log(2 * tf.math.cosh(x))
    #     x = tf.reduce_sum(x, axis=-1)
    #     x = tf.reshape(x, [-1, 1])
    #     y = tf.keras.layers.Dense(1, activation=None)(inputs)
    #     outputs = y + x
    #     model = tf.keras.Model(inputs=inputs, outputs=outputs)
    #     return model
    # def create_real_rbm_model(
    #     self, 
    #     stddev: float = 0.1, 
    #     width: int = 2, 
    #     **kws: Any
    # ) -> tf.keras.Model:
    #     initializer = tf.keras.initializers.RandomNormal(stddev=stddev)

    #     inputs = tf.keras.layers.Input(shape=[self.n])

    #     x = tf.keras.layers.Dense(
    #         width * self.n, 
    #         activation=None,
    #         kernel_initializer=initializer,
    #         bias_initializer=initializer
    #     )(inputs)
    #     x = tf.math.log(2 * tf.math.cosh(x))
    #     x = tf.reduce_sum(x, axis=-1, keepdims=True)  
    #     y = tf.keras.layers.Dense(
    #         1, 
    #         activation=None,
    #         kernel_initializer=initializer,
    #         bias_initializer=initializer
    #     )(inputs)
    #     outputs = y + x
    #     model = tf.keras.Model(inputs=inputs, outputs=outputs, name='real_rbm')
        
    #     return model
    
    # def create_real_rbm_model(self, stddev: float = 0.1, width: int = 2, num_hidden_layers: int = 2, **kws) -> tf.keras.Model:
    #     inputs = tf.keras.layers.Input(shape=[self.n])
    #     x = tf.keras.layers.Dense(width * self.n, activation='relu', 
    #                                 kernel_initializer=tf.random_normal_initializer(stddev=stddev),
    #                                 kernel_regularizer=tf.keras.regularizers.l2(0.01))(inputs)
    #     for _ in range(num_hidden_layers):
    #         x = tf.keras.layers.Dense(width * self.n // 2, activation='leaky_relu', 
    #                                     kernel_initializer=tf.random_normal_initializer(stddev=stddev),
    #                                     kernel_regularizer=tf.keras.regularizers.l2(0.01))(x)            
    #     x = tf.math.log(2 * tf.math.cosh(x))
    #     x = tf.reduce_sum(x, axis=-1)
    #     x = tf.reshape(x, [-1, 1])
    #     outputs = tf.keras.layers.Dense(1, activation=None)(x)
    #     model = tf.keras.Model(inputs=inputs, outputs=outputs)
    #     return model
    
    def create_real_rbm_model(self, stddev: float = 0.1, width: int = 2, num_hidden_layers: int = 2, **kws) -> tf.keras.Model:
        inputs = Input(shape=[self.n])
        x = Dense(width * self.n, activation='relu',
                  kernel_initializer=tf.keras.initializers.HeNormal(),
                  kernel_regularizer=tf.keras.regularizers.l2(0.01))(inputs)

        x = Dropout(0.3)(x)

        for _ in range(num_hidden_layers):
            x = Dense(width * self.n // (2 ** (_ + 1)), activation='elu',
                      kernel_initializer=tf.keras.initializers.HeNormal(),
                      kernel_regularizer=tf.keras.regularizers.l2(0.01))(x)
            x = Dropout(0.3)(x)

        x = tf.math.log(2 * tf.math.cosh(x))
        x = tf.reduce_sum(x, axis=-1)
        x = tf.reshape(x, [-1, 1])
        outputs = Dense(1, activation=None)(x)
        model = tf.keras.Model(inputs=inputs, outputs=outputs)
        return model
    
    # def create_real_rbm_model(
    #     self, stddev: float = 0.1, width: int = 2, **kws: Any
    # ) -> Model:
    #     inputs = tf.keras.layers.Input(shape=[self.n])
    #     x = Linear_real(width * self.n, self.n, stddev=stddev)(inputs)
    #     x = tf.math.log(2 * tf.math.cosh(x))
    #     x = tf.reduce_sum(x, axis=-1)
    #     x = tf.reshape(x, [-1, 1])
    #     y = Linear_real(1, self.n, stddev=stddev)(inputs)
    #     outputs = y + x
    #     model = tf.keras.Model(inputs=inputs, outputs=outputs)
    #     return model    

    def create_complex_rbm_model(
        self, stddev: float = 0.1, width: int = 2, **kws: Any
    ) -> Model:
        inputs = tf.keras.layers.Input(shape=[self.n])
        x = Linear(width * self.n, self.n, stddev=stddev)(inputs)
        x = tf.math.log(2 * tf.math.cosh(x))
        x = tf.reduce_sum(x, axis=-1)
        x = tf.reshape(x, [-1, 1])
        y = Linear(1, self.n, stddev=stddev)(inputs)
        outputs = y + x
        model = tf.keras.Model(inputs=inputs, outputs=outputs)
        return model

    def create_circuit(
        self, choose: str = "hea", **kws: Any
    ) -> Callable[[Tensor], Tensor]:
        if choose == "hea":
            return self.create_hea_circuit(**kws)
        if choose == "hea2":
            return self.create_hea2_circuit(**kws)
        if choose == "hn":
            return self.create_hn_circuit(**kws)
        if choose == "hea3":
            return self.create_hea3_circuit(**kws)
        if choose == "hea4":
            return self.create_hea4_circuit(**kws)
        raise ValueError("no such choose option: %s" % choose)

    def create_hn_circuit(self, **kws: Any) -> Callable[[Tensor], Tensor]:
        def circuit(a: Tensor) -> Tensor:
            c = Circuit(self.n)
            for i in range(self.n):
                c.H(i)  # type: ignore
            return c

        return circuit

    def create_hea_circuit(
        self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, edge: Optional[List[int]] = None, **kws: Any
    ) -> Callable[[Tensor], Tensor]:
        if filled_qubit is None:
            filled_qubit = [0]

        def circuit(a: Tensor) -> Tensor:
            c = Circuit(self.n)
            if filled_qubit:
                for i in filled_qubit:
                    c.h(i)  # type: ignore

            t=0
            for epoch in range(epochs):
                for i in range(self.n):
                    c.rz(i, theta=a[t])  # type: ignore
                    t+=1
                for i in edge:
                    # c.rzz(i[0],i[1], theta=a[t])
                    # t+=1
                    c.rzz(i[0],i[1], theta=a[t])
                    # c.cx(i[0],i[1])
                    t+=1
            return c

        return circuit
    

    def create_hea1_circuit(
        self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, edge: Optional[List[int]] = None, **kws: Any
    ) -> Callable[[Tensor], Tensor]:
        if filled_qubit is None:
            filled_qubit = [0]

        def circuit(a: Tensor) -> Tensor:
            c = Circuit(self.n)
            if filled_qubit:
                for i in filled_qubit:
                    c.h(i)  # type: ignore

            t=0
            for epoch in range(epochs):
                for i in range(self.n):
                    c.ry(i, theta=a[t])
                    t+=1
                    c.rz(i, theta=a[t])
                    t+=1
                for j in range(int(self.n/2)):
                    c.cx(2*j+1,2*j)
                for i in range(self.n):
                    if i>0 and i<self.n-1:
                        c.ry(i,a[t])                        
                        t+=1
                        c.rz(i,a[t])
                        t+=1
                for j in range(int(self.n/2)):
                    if j>0 and j<int(self.n/2):
                        c.cx(2*j,2*j-1)
            return c

        return circuit

    # def create_hea2_circuit(
    #     self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, **kws: Any
    # ) -> Callable[[Tensor], Tensor]:
    #     if filled_qubit is None:
    #         filled_qubit = [0]

    #     def circuit(a: Tensor) -> Tensor:
    #         c = Circuit(self.n)
    #         if filled_qubit:
    #             for i in filled_qubit:
    #                 c.h(i)  # type: ignore
    #         t=0
    #         for epoch in range(epochs):
    #             for i in range(self.n):
    #                 c.ry(i, theta=a[t])  # type: ignore
    #                 t+=1
    #             for i in range(self.n):
    #                 c.rz(i, theta=a[t])  # type: ignore
    #                 t+=1
    #             for i in range(self.n-1):
    #                 c.cx(i,i+1)
                    
    #         for i in range(self.n):
    #             c.ry(i, theta=a[t])  # type: ignore
    #             t+=1
    #         for i in range(self.n):
    #             c.rz(i, theta=a[t])
    #             t+=1
    #             # for i in range(self.n - 1):
    #             #     c.exp1(i, (i + 1), theta=a[epoch, i, 3], unitary=G._zz_matrix)  # type: ignore
    #         return c

    #     return circuit
    def create_hea2_circuit(
        self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, edge: Optional[List[int]] = None, **kws: Any
    ) -> Callable[[Tensor, Tensor, Tensor], Tensor]:
        if filled_qubit is None:
            filled_qubit = [0]
            
        def circuit(a: Tensor, theta_ry: Tensor, theta_rz: Tensor) -> Tensor:
            c = Circuit(self.n)
            t=0
            for epoch in range(epochs):
                for i in range(self.n):
                    # c.ry(i, theta=a[t])  # type: ignore
                    # t+=1
                    c.any(i,unitary=X2P)
                    c.rz(i,theta=a[t])
                    t +=1
                    c.any(i,unitary=X2M)
                for i in range(self.n):
                    c.rz(i, theta=a[t])  # type: ignore
                for i in edge:
                    c.any(int(i[1]), unitary=Y2M)
                    c.cz(i[0], i[1])
                    c.any(int(i[1]), unitary=Y2P)
                    c.rz(int(i[1]), theta=a[t]) 
                    t += 1
                    c.any(int(i[1]), unitary=Y2M)
                    c.cz(i[0], i[1])
                    c.any(int(i[1]), unitary=Y2P)
            return c

        return circuit
    
    def create_hea3_circuit(
        self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, edge: Optional[List[int]] = None, **kws: Any
    ) -> Callable[[Tensor, Tensor, Tensor], Tensor]:
        if filled_qubit is None:
            filled_qubit = [0]

        def circuit(a: Tensor, theta_ry: Tensor, theta_rz: Tensor) -> Tensor:
            c = Circuit(self.n)
            t = 0  
            t_ry = 0 
            t_rz = 0    

            for epoch in range(epochs-1):
                for i in range(self.n):
                    c.any(i,unitary=X2P)
                    c.rz(i,theta=theta_ry[t_ry])
                    t_ry+=1
                    c.any(i,unitary=X2M)
                    # c.ry(i, theta=theta_ry[t_ry])
                    # t_ry += 1
                
                for i in range(self.n):
                    c.rz(i, theta=theta_rz[t_rz])
                    t_rz += 1
                
                for i in edge:
                    c.any(int(i[1]), unitary=Y2M)
                    c.cz(i[0], i[1])
                    c.any(int(i[1]), unitary=Y2P)
                    c.rz(int(i[1]), theta=theta_rz[t_rz])
                    t_rz += 1
                    c.any(int(i[1]), unitary=Y2M)
                    c.cz(i[0], i[1])
                    c.any(int(i[1]), unitary=Y2P)
            

            for i in range(self.n):
                c.any(i,unitary=X2P)
                c.rz(i,theta=a[t_ry])
                t +=1
                c.any(i,unitary=X2M)
                # c.ry(i, theta=a[t])  
                # t += 1

            for i in range(self.n):
                c.rz(i, theta=a[t])  
                t += 1

            for i in edge:
                c.any(int(i[1]), unitary=Y2M)
                c.cz(i[0], i[1])
                c.any(int(i[1]), unitary=Y2P)
                c.rz(int(i[1]), theta=a[t]) 
                t += 1
                c.any(int(i[1]), unitary=Y2M)
                c.cz(i[0], i[1])
                c.any(int(i[1]), unitary=Y2P)
            
            return c
        return circuit

    def create_hea4_circuit(
        self, epochs: int = 2, filled_qubit: Optional[List[int]] = None, edge: Optional[List[int]] = None, **kws: Any
    ) -> Callable[[Tensor, Tensor, Tensor], Tensor]:
        if filled_qubit is None:
            filled_qubit = [0]

        def circuit(a: Tensor, theta_ry: Tensor, theta_rz: Tensor) -> Tensor:
            c = Circuit(self.n)
            t_rz = 0  
            t_ry = 0  
            # params_per_layer = self.n + len(edge)  
            
            for epoch in range(epochs-1):
                for i in range(self.n):
                    c.any(i,unitary=X2P)
                    c.rz(i,theta=theta_ry[t_ry])
                    t_ry+=1
                    c.any(i,unitary=X2M)
                    # c.ry(i, theta=theta_ry[t_ry])
                    # t_ry += 1
                for i in range(self.n):
                    c.rz(i, theta=theta_rz[t_rz])
                    t_rz+=1
                for i in edge:
                    c.any(int(i[1]), unitary=Y2M)
                    c.cz(i[0], i[1])
                    c.any(int(i[1]), unitary=Y2P)
                    c.rz(int(i[1]), theta=theta_rz[t_rz])
                    t_rz += 1
                    c.any(int(i[1]), unitary=Y2M)
                    c.cz(i[0], i[1])
                    c.any(int(i[1]), unitary=Y2P)
            t = 0  
            for i in range(self.n):
                c.any(i,unitary=X2P)
                c.rz(i,theta=theta_ry[t_ry])
                t_ry+=1
                c.any(i,unitary=X2M)
                # c.ry(i, theta=theta_ry[t_ry])
                # t_ry += 1
            for i in range(self.n):
                c.rz(i, theta=a[t])
                t += 1
            for i in edge:
                c.any(int(i[1]), unitary=Y2M)
                c.cz(i[0], i[1])
                c.any(int(i[1]), unitary=Y2P)
                c.rz(int(i[1]), theta=a[t])
                t += 1
                c.any(int(i[1]), unitary=Y2M)
                c.cz(i[0], i[1])
                c.any(int(i[1]), unitary=Y2P)
            
            return c
        return circuit
    
    #@tf.function  # type: ignore
    def evaluation(self, cv: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
        with tf.GradientTape() as tape:
            # c1 = self.circuit(cv, self.theta_ry, self.theta_rz)
            c1 = noisy(self.circuit(cv,self.theta_ry, self.theta_rz))
            loss_dict=loss_dict_h(c1,self.hamiltonian)
            f2 = tf.reshape(self.model(self.base), [-1])
            f2 -= tf.math.reduce_mean(f2)
            f2 = tf.abs(f2)        
            f2 = tf.cast(f2, tf.complex128) 
            # f2 = f2/tf.linalg.norm(f2)
            samples_dict = {}
            for term in self.h_sample:
                d = c1.copy() 
                counts = v_and_sample_grad(term, d)
                samples_dict[str(term[1:])] = counts
            grads = []
            cv_size = self.n+len(self.edge)
            for i in range(cv_size):
                grad_i = gradz_energy(
                    self.hamiltonian, 
                    self.n, 
                    i, 
                    self.edge, 
                    cv_size, 
                    samples_dict, 
                    f2
                )
                grads.append(grad_i)
            
            exp_n = 0
            exp_d = 0
            for term in self.hamiltonian:
                sz = [i for i, x in enumerate(term[1:]) if x == 3]
                non_zero_positions = [index for index, value in enumerate(term[1:]) if value != 0]
                term_input_str = str(term[1:])
                samples = loss_dict[term_input_str]
                samp_num = sum(samples.values())
                pau = pauli_hamiltonian(term)
                pau = tf.constant(pau, dtype=tf.complex128)
                exp_n = exp_n + term[0] * measurement(
                    non_zero_positions[0],
                    pau,
                    samples,
                    f2,
                    samp_num,
                    sz
                )
            
            samples = loss_dict[str(self.hamiltonian[self.n+2][1:])]
            samp_num = sum(samples.values())
            for bitstring, count in samples.items():
                stq = string_to_quantum_state(bitstring)
                stq_tf = tf.constant(stq, dtype=tf.complex128)
                f_0 = tf.tensordot(f2, stq_tf, axes=1)
                probability = count / samp_num
                exp_d = exp_d + probability * (f_0**2)
                
            energy = exp_n/exp_d
            loss = tf.math.real(energy)
            
            nn_grads = tape.gradient(loss, self.model.variables)
            
            return loss, (tf.math.real(tf.constant(grads/exp_d)), nn_grads), f2
    

    #@tf.function  # type: ignore
    def plain_evaluation(self, cv: Tensor) -> Tensor:
        """
        VQE

        :param cv: [description]
        :type cv: Tensor
        :return: [description]
        :rtype: Tensor
        """
        # print(tf.math.real(vqe_energy_shortcut(self.circuit(cv), self.hamiltonian)))
        with tf.GradientTape() as tape:
            # c = self.circuit(cv, self.theta_ry, self.theta_rz)
            c = noisy(self.circuit(cv, self.theta_ry, self.theta_rz))
            vqe_dict_c = vqe_exp_dict(self.n,c,self.hamiltonian)
            # c = noisy(c0,2*len(self.edge)) # epoch*len(self.edge)
            theta_plus = cv.numpy()
            theta_minus = cv.numpy()
            grad_q = np.zeros(2*(2*self.n+len(self.edge))) # hea2
            for i in range(len(grad_q)):
                theta_plus[i] += np.pi / 2
                theta_minus[i] -= np.pi / 2
                cplus = noisy(self.circuit(theta_plus,self.theta_ry, self.theta_rz))
                cminus = noisy(self.circuit(theta_minus,self.theta_ry, self.theta_rz))
                vqe_dict_cplus = vqe_exp_dict(self.n,cplus,self.hamiltonian)
                vqe_dict_cminus = vqe_exp_dict(self.n,cminus,self.hamiltonian)
                energy_plus = qstep_energy_dict(self.hamiltonian,vqe_dict_cplus)         
                energy_minus = qstep_energy_dict(self.hamiltonian,vqe_dict_cminus)       
                grad_q[i] = (energy_plus - energy_minus) / 2                       
            if not self.shortcut:
                loss = tf.math.real(qstep_energy_dict(self.hamiltonian,vqe_dict_c))
            else:
                loss = tf.math.real(vqe_energy_shortcut(c, self.h0))
        # grad = tape.gradient(loss, cv)
        grad = tf.constant(grad_q)
        return loss, grad
    
    def evaluation_dict(self, cv: Tensor, loss_samples_dict) -> Tuple[Tensor, Tensor, Tensor]:
        """
        VQNHE qon stop
        """
        with tf.GradientTape() as tape:
            tape.watch(cv)
            # c1 = self.circuit(cv)
            # c0 = self.circuit(cv)
            # c_noise = noisy(c0,len(self.edge))
            # c1 = c_noise
            f2 = tf.reshape(self.model(self.base), [-1])
            f2 -= tf.math.reduce_mean(f2)
            f2 = tf.abs(f2)            
            f2 = tf.cast(f2, tf.complex128) 
            #f2 = tf.exp(f2)    
            # f2 = tf.abs(f2)
            # f2 = f2/tf.linalg.norm(f2)
            #f2 = f2/np.sqrt(sum(f2**2)) 
            exp_n = 0
            exp_d = 0
            for term in self.hamiltonian:
                sz = [i for i, x in enumerate(term[1:]) if x == 3]
                non_zero_positions = [index for index, value in enumerate(term[1:]) if value != 0]
                term_input_str = str(term[1:])
                samples = loss_samples_dict[term_input_str]
                samp_num = sum(samples.values())
                pau = pauli_hamiltonian(term)
                pau = tf.constant(pau, dtype=tf.complex128)
                exp_n = exp_n + term[0] * measurement(
                    non_zero_positions[0],
                    pau,
                    samples,
                    f2,
                    samp_num,
                    sz
                )
            
            samples = loss_samples_dict[str(self.hamiltonian[self.n+2][1:])]
            samp_num = sum(samples.values())
            for bitstring, count in samples.items():
                stq = string_to_quantum_state(bitstring)
                stq_tf = tf.constant(stq, dtype=tf.complex128)
                f_0 = tf.tensordot(f2, stq_tf, axes=1)
                probability = count / samp_num
                exp_d = exp_d + probability * (f_0**2)
                
            energy = exp_n/exp_d
            if not self.shortcut:
                #loss = tf.math.real(vqe_energy(c2, self.hamiltonian))
                # loss0 = vqe_energy(C_y,c1, self.hamiltonian,f2,self.n)
                loss = tf.math.real(energy)
                #loss = tf.math.real(loss0)*(2**self.n)
            else:
                loss = tf.math.real(vqe_energy_shortcut(c1, self.h0))
            grad = tape.gradient(loss, [cv, self.model.variables])
            for i, gr in enumerate(grad):
                if gr is None:
                    if i == 0:
                        grad[i] = tf.zeros_like(cv)
                        # grad[i] = tf.constant(grad_q*0.1)
                    else:
                        grad[i] = tf.zeros_like(self.model.variables[i - 1])
        return loss, grad, f2
    
    def training(
        self,
        maxiter: int = 5000,
        optq: Optional[Callable[[int], Any]] = None,
        optc: Optional[Callable[[int], Any]] = None,
        threshold: float = 1e-8,
        debug: int = 100,
        onlyq: int = 0,
        checkpoints: Optional[List[Tuple[int, float]]] = None,
        qon: int = 1
    ) -> Tuple[Array, Array, Array, int, List[float]]:
        loss_prev = 0
        loss_opt = 1e8
        j_opt = 0
        nm_opt = 1
        ccount = 0
        self.qcache = self.circuit_variable.numpy()
        self.ccache = self.model.get_weights()
        
        # strategy 2
        # initial_learning_rate = 0.001
        # second_learning_rate = 0.00005
        # if not optc:
        #     optc = tf.keras.optimizers.Adam(learning_rate=initial_learning_rate) 
        # elif isinstance(optc, (float, tf.keras.optimizers.schedules.LearningRateSchedule)):
        #     optc = tf.keras.optimizers.Adam(learning_rate=optc) 
        # elif isinstance(optc, tf.keras.optimizers.Optimizer):
        #     optc = optc 
        # strategy 1
        # class CustomLearningRateSchedule(LearningRateSchedule):
        #     def __init__(self, initial_learning_rate, decay_rate, decay_steps):
        #         self.initial_learning_rate = initial_learning_rate
        #         self.decay_rate = decay_rate
        #         self.decay_steps = decay_steps

        #     def __call__(self, epoch):
        #         return self.initial_learning_rate * (self.decay_rate ** (epoch / self.decay_steps))
        # initial_learning_rate = 0.001
        # decay_rate = 0.1
        # decay_steps = 100
        # lr_schedule = CustomLearningRateSchedule(initial_learning_rate, decay_rate, decay_steps)

        # if not optc:
        #     optc = tf.keras.optimizers.Adam(learning_rate=lr_schedule)  
        # elif isinstance(optc, (float, tf.keras.optimizers.schedules.LearningRateSchedule)):
        #     optc = tf.keras.optimizers.Adam(learning_rate=optc)  
        # elif isinstance(optc, tf.keras.optimizers.Optimizer):
        #     optc = optc
        
        # strategy 0
        if not optc:
            optc = 0.001  # type: ignore
        if isinstance(optc, float) or isinstance(
            optc, tf.keras.optimizers.schedules.LearningRateSchedule
        ):
            optc = tf.keras.optimizers.Adam(optc)
        
        if isinstance(optc, tf.keras.optimizers.Optimizer):
            optcf = lambda _: optc
        else:
            optcf = optc  # type: ignore
        if not optq:
            optq = 0.01  # type: ignore 0.01
        if isinstance(optq, float) or isinstance(
            optq, tf.keras.optimizers.schedules.LearningRateSchedule
        ):
            optq = tf.keras.optimizers.Adam(optq)
        if isinstance(optq, tf.keras.optimizers.Optimizer):
            optqf = lambda _: optq
        else:
            optqf = optq  # type: ignore

        nm = tf.constant(1.0)
        times = []
        history = []
        qhist = []
        qgrad = []
        cgrad = []
        model_var = []
        amplitude_c = []
        qnon = 0
        try:
            for j in range(maxiter):
                # strategy 2
                # if qnon == 1:
                #     optc.learning_rate = second_learning_rate
                # else:
                #     optc.learning_rate = initial_learning_rate
                if j==qon:
                    loss_samples_dict = loss_dict_h(noisy(self.circuit(self.circuit_variable,self.theta_ry,self.theta_rz)),self.hamiltonian)
                if j < onlyq:
                    loss, grad = self.plain_evaluation(self.circuit_variable)
                    qhist.append(loss.numpy())
                    # qgrad.append(grad.numpy().reshape(-1))
                # elif j>=onlyq and qnon==0:
                elif j>=onlyq and j<qon:
                    loss, grad, f2 = self.evaluation(self.circuit_variable)
                    # qgrad.append(grad[0].numpy().reshape(-1))
                    # ctmp=[]
                    # for tmp in grad[1]:
                        # ctmp=ctmp+list(tmp.numpy().reshape(-1))
                    # cgrad.append(nm)  
                else:
                    loss, grad, f2 = self.evaluation_dict(self.circuit_variable,loss_samples_dict)
                if not tf.math.is_finite(loss):
                    print("failed optimization since nan in %s tries" % j)
                    # in case numerical instability
                    break
                if np.abs(loss - loss_prev) < threshold and qnon==0:  # 0.3e-7
                    ccount += 1
                    if ccount >= 100:
                        # print("finished in %s round" % j)
                        break
                        # qnon = 1
                        # loss_samples_dict = loss_dict_h(self.circuit(self.circuit_variable),self.hamiltonian)
                        # loss_samples_dict = loss_sample(self.hamiltonian, self.circuit(self.circuit_variable))
                history.append(loss.numpy())
                if checkpoints is not None:
                    bk = False
                    for rd, tv in checkpoints:
                        if j > rd and loss.numpy() > tv:
                            print("failed optimization, as checkpoint is not met")
                            bk = True
                            break
                    if bk:
                        break
                if debug > 0:
                    if j % debug == 0:
                        times.append(time.time())
                        print("energy estimation:", loss.numpy())

                        # quantume, _ = self.plain_evaluation(self.circuit_variable)
                        # print("quantum part energy: ", quantume.numpy())
                        if len(times) > 1:
                            print("running time: ", (times[-1] - times[-2]) / debug)
                loss_prev = loss                
                if j < onlyq:
                    gradofc = [grad]
                    optqf(j).apply_gradients(zip(gradofc, [self.circuit_variable]))
                else:
                    gradofc = grad[0:1]
                if loss < loss_opt:
                    loss_opt = loss
                    nm_opt = nm
                    j_opt = j
                    self.qcache = self.circuit_variable.numpy()
                    self.ccache = self.model.get_weights()
                if j >= onlyq:
                    amplitude_c.append(f2.numpy())
                    optcf(j).apply_gradients(zip(grad[1], self.model.variables))
                    if j<qon and qnon==0:
                        optqf(j).apply_gradients(zip(gradofc, [self.circuit_variable]))
                        
                qgrad.append(self.circuit_variable.numpy())
                cgrad.append(self.model.variables)
                model_var.append(self.model.get_weights())
        except KeyboardInterrupt:
            pass

        # quantume, _ = self.plain_evaluation(self.circuit_variable)
        print(
            "vqnhe prediction: ",
            loss_prev.numpy(),  # type: ignore
            # "quantum part energy: ",
            # quantume.numpy(),
            "classical model scale: ",
            self.model.variables[-1].numpy(),
        )
        print("----------END TRAINING------------")
        self.history += history[:j_opt]
        return (
            loss_opt.numpy(),  # type: ignore
            #np.real(nm_opt.numpy()),  # type: ignore
            model_var,
            qhist,
            j_opt,
            # history[:j_opt+1],
            history,
            qgrad,
            cgrad,
            amplitude_c
        )

    def multi_training(
        self,
        maxiter: int = 5000,
        optq: Optional[Callable[[int], Any]] = None,
        optc: Optional[Callable[[int], Any]] = None,
        threshold: float = 1e-8,
        debug: int = 150,
        onlyq: int = 0,
        checkpoints: Optional[List[Tuple[int, float]]] = None,
        tries: int = 10,
        initialization_func: Optional[Callable[[int], Dict[str, Any]]] = None,
        qon: int = 1,
    ) -> List[Dict[str, Any]]:
        # TODO(@refraction-ray): old multiple training implementation, we can use vmap infra for batched training
        rs = []
        try:
            for t in range(tries):
                print("---------- %s training loop ----------" % t)
                if initialization_func is not None:
                    weights = initialization_func(t)
                else:
                    weights = {}
                qweights = weights.get("q", None)
                cweights = weights.get("c", None)
                if cweights is None:
                    cweights = self.create_model(**self.model_params).get_weights()
                self.model.set_weights(cweights)
                if qweights is None:
                    self.circuit_variable = tf.Variable(
                        tf.random.normal(
                            mean=0.0,
                            stddev=self.circuit_stddev,
                            shape=[self.epochs, self.n, self.channel],
                            dtype=tf.float64,
                        )
                    )
                else:
                    self.circuit_variable = qweights
                    # qon=1
                self.history = []  # refresh the history
                r = self.training(
                    maxiter, optq, optc, threshold, debug, onlyq, checkpoints,qon
                )
                rs.append(
                    {
                        "energy": r[0],
                        "model_var": r[1],
                        "quantum_energy": r[2],
                        "iterations": r[3],
                        "history": r[4],
                        "qgrad": r[5],
                        "cgrad": r[6],
                        "amp_f2": r[7],
                        "model_weights": self.ccache,
                        "circuit_weights": self.qcache,
                    }
                )
        except KeyboardInterrupt:
            pass

        if rs:
            es = [r["energy"] for r in rs]
            ind = np.argmin(es)
            self.assign(rs[ind]["model_weights"], rs[ind]["circuit_weights"])  # type: ignore
            self.history = rs[ind]["history"]  # type: ignore
        return rs

