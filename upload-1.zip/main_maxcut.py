#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb 17 01:25:45 2025
maxcut main

@author: Mengzhen
"""
import numpy as np
import pandas as pd
import math
import cmath
import tensorcircuit as tc
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
from qiskit_nature.drivers import UnitsType, Molecule
from qiskit_nature.drivers.second_quantization import (
    ElectronicStructureDriverType,
    ElectronicStructureMoleculeDriver,
)
from qiskit_nature.problems.second_quantization import ElectronicStructureProblem
from qiskit_nature.converters.second_quantization import QubitConverter
from qiskit_nature.mappers.second_quantization import JordanWignerMapper
from qiskit_nature.transformers.second_quantization.electronic import FreezeCoreTransformer, ActiveSpaceTransformer
# from qiskit.aqua.operators import WeightedPauliOperator
from qiskit.quantum_info import Pauli, state_fidelity, SparsePauliOp
import matplotlib.pyplot as plt
# from scipy.linalg import expm
from scipy.sparse.linalg import expm
from scipy import sparse
from scipy.optimize import minimize
import tensorflow as tf
import warnings
from functools import partial
import functools as ft
import pickle
# from keras.utils import plot_model
warnings.simplefilter(action='ignore', category=FutureWarning)
tc.set_backend("tensorflow")
tc.set_dtype("complex128")

def str2WeightedPaulis_H2D(H2D):
    h = []
    terms = H2D.split('+')
    for term in terms:
        if term:  
            term = term.strip('+')
            weight, pauli_str = term.split('*')
            pauli_list = [pauli for pauli in pauli_str if pauli in 'XYZI']
            weight = float(weight)
            h.append([weight] + [int(pauli == 'X') + 2*int(pauli == 'Y') + 3*int(pauli == 'Z') for pauli in pauli_list])
    return h

def str2WeightedPaulis(s):
	s = s.strip()
	IXYZ = ['I', 'X', 'Y', 'Z']
	prev_idx = 0
	coefs = []
	paulis = []
	is_coef = True
	for idx, c in enumerate(s + '+'):
		if idx == 0: continue
		if is_coef and c in IXYZ:
			coef = complex(s[prev_idx : idx].replace('i', 'j'))
			coefs.append(coef)
			is_coef = False
			prev_idx = idx
		if not is_coef and c in ['+', '-']:
			label = s[prev_idx : idx]
			paulis.append(Pauli(label))
			is_coef = True
			prev_idx = idx
	return SparsePauliOp(paulis,coefs)
dtype=np.complex128
X = np.array([[0, 1.0], [1.0, 0]], dtype=dtype)
Y = np.array([[0, -1j], [1j, 0]], dtype=dtype)
Z = np.array([[1, 0], [0, -1]], dtype=dtype)
I = np.array([[1, 0], [0, 1]], dtype=dtype)
             
def tran(tin):
    if tin=='I':
        return '0'
    if tin=='X':
        return '1'
    if tin=='Y':
        return '2'
    if tin=='Z':
        return '3'
    else:
        return tin
def Fedtest(ex,GS):
    SS=[]
    for x in GS:
        SS.append(state_fidelity(ex,w[:,x]))
    SS=np.array(SS)
    return SS
def mykron(ma, mb, *list):
    """
    :param ma: matrix a
    :param mb: matrix b
    :param *List: a set of matrices
    :return:  kron(ma,mb,list[0],....,list[n-1])
    """
    # k1=tran(ma).copy()
    # k2=tran(mb).copy()
    out = np.kron(ma,mb)
    if len(list) != 0:
        # print(out)
        out = mykron(out, *list)
    return out
def lshift(s,n):
    return s[n:]+s[:n]

def dtheta(params,H):
    N=np.size(params)
    A=np.zeros([N,N],dtype=np.complex128)
    C=np.zeros(N,dtype=np.complex128)
    dpdt=[]
    cp=1/np.sqrt(2)
    a=np.pi/2
    phi=E(params)
    for i in range(N):
        ptmp1=params.copy().reshape(-1)
        ptmp2=params.copy().reshape(-1)
        ptmp1[i]+=a
        ptmp2[i]-=a    
        dp=cp*(E(ptmp1.reshape(params.shape))-E(ptmp2.reshape(params.shape)))
        dpdt.append(dp)
    for i in range(N):
        for j in range(N):
            # phi=Lv(params,wavefunction)
            A[i,j]=(dpdt[i].conj().dot(dpdt[j])).real#+dpdt[i].conj().dot(phi)*dpdt[j].conj().dot(phi)
    for i in range(N):
        # phi=Lv(params,wavefunction)
        C[i]=(dpdt[i].conj().dot(H.dot(phi))).real
    dx=np.linalg.pinv(A.real).dot(-C)
    return dx.real

def commutator(A,B):
    return A.dot(B)-B.dot(A)

def anticommutator(A,B):
    return A.dot(B)+B.dot(A)

def convert_sparse_matrix_to_sparse_tensor(X):
    coo = X.tocoo()
    indices = np.mat([coo.row, coo.col]).transpose()
    return tf.SparseTensor(indices, coo.data, coo.shape)

def Mtheta(theta):
    M=tc.Circuit(nqu)
    j=0
    for i in range(nqu):
        M.rx(i,theta=theta[j])
        j+=1
    for i in range(nqu):
        M.ry(i,theta=theta[j]) 
        j+=1
    return M.matrix().numpy()

def E(theta):
    u=cir(theta).state()
    return u.numpy()

def EN(v,H):
    # v=E(theta)
    return (v.conj().dot(H.dot(v))).real
# def sexpm(H):
#     I=H.copy()
#     I[I!=0]=0
#     return I-H+0.5*H.dot(H)
def cost(theta,H):
    v=E(theta)
    return EN(v,H)
    # return 1-state_fidelity(v, w[:,GS])

# def mS(theta):
#     u=E(theta)
#     v=w[:,GS].reshape(-1)
#     wh=v.conj()*v
#     u=wh*u
#     u/=np.sqrt(u.conj().dot(u))
#     return state_fidelity(u, w[:,GS])

def mS(u):
    # u=E(theta)
    v=w[:,GS].reshape(-1)
    wh=v.conj()*v
    u=wh*u
    u/=np.sqrt(u.conj().dot(u))
    return state_fidelity(u, w[:,GS])

def mA(theta):
    u=E(theta)
    u=u.conj()*(u)
    u/=np.sqrt(u)
    v=w[:,GS].reshape(-1)
    wh=v.conj()*v
    wh/=np.sqrt(wh)
    return state_fidelity(u, wh)

def eS(w,H):
    wh=abs(w.reshape(-1))
    u=np.ones(len(wh))
    u=w.reshape(-1)/wh*u
    u/=np.sqrt(u.conj().dot(u))
    return u.conj().dot(H.dot(u))

def S(H):
    Hp=H.copy()
    I=H*0
    I.setdiag(1)
    Hp[Hp<0]=0
    Hp.setdiag(0)
    
    Hn=H.copy()
    Hn[Hn>0]=0
    Hn.setdiag(H.diagonal())
    Hb=Hn-Hp
    # eHb=expm(-Hb)
    # eH=expm(-H)
    # eHb=I-0.1*Hb+0.01*Hb.dot(Hb)
    # eH=I-0.1*H+0.01*H.dot(H)
    return Hp
#%% maxcut Heisenberg (power 2)
import numpy as np
from itertools import combinations

dist = [1, 1, 1, 1]
d = dist[1:]  
h = dist[0]   
J = d * h     

na = 12 #(10,135)
nb = 1
n = na * nb

edge = list(combinations(range(n), 2))

H2D = ""
H2D1 = ""
# X→Y→Z 
for pauli, coeff in zip(["X", "Y", "Z"], J):
    for u, v in edge:
        term = ["I"] * n
        term[u] = pauli
        term[v] = pauli
        H2D += f"+{coeff}*{''.join(term)}"

for pauli, coeff in zip(["X", "Y", "Z"], J):
    for u, v in edge:
        term = ["I"] * n
        term[u] = pauli
        term[v] = pauli
        H2D1 += f"+{coeff}{''.join(term)}"

#%% maxcut Heisenberg (power 3)
from itertools import combinations
dist = [1, 1, 1, 1]
d = dist[1:]  
h = dist[0]   
J = d * h     

na = 9
nb = 1
n = na * nb

edge = list(combinations(range(n), 3))

H2D = ""
H2D1 = ""
# X→Y→Z 
for pauli, coeff in zip(["X", "Y", "Z"], J):
    for nodes in edge:
        term = ["I"] * n
        for node in nodes:
            term[node] = pauli
        H2D += f"+{coeff}*{''.join(term)}"

for pauli, coeff in zip(["X", "Y", "Z"], J):
    for nodes in edge:
        term = ["I"] * n
        for node in nodes:
            term[node] = pauli
        H2D1 += f"+{coeff}{''.join(term)}"
#%% maxcut Heisenberg (power 4)
import numpy as np
from itertools import combinations

dist = [1, 1, 1, 1]
d = dist[1:]  
h = dist[0]   
J = d * h     

na = 12
nb = 1
n = na * nb

edge = list(combinations(range(n), 4))

H2D = ""
H2D1 = ""
# X→Y→Z 
for pauli, coeff in zip(["X", "Y", "Z"], J):
    for nodes in edge:
        term = ["I"] * n
        for node in nodes:
            term[node] = pauli
        H2D += f"+{coeff}*{''.join(term)}"

for pauli, coeff in zip(["X", "Y", "Z"], J):
    for nodes in edge:
        term = ["I"] * n
        for node in nodes:
            term[node] = pauli
        H2D1 += f"+{coeff}{''.join(term)}"
        
#%% brickwork circuit
def generate_brickwork_edges(nodes):
    edges = []
    n = len(nodes)   
    if n < 2:
        return edges 
    if n % 2 != 0:       
        for i in range(0, n-1, 2):
            edges.append((nodes[i], nodes[i + 1]))
        for i in range(1, n, 2):
            edges.append((nodes[i], nodes[i + 1]))
    if n % 2 == 0:
        for i in range(0, n, 2):
            edges.append((nodes[i], nodes[i + 1]))
        for i in range(1, n-1, 2):
            edges.append((nodes[i], nodes[i + 1]))
    return edges
nodes = list(range(n))
edge = generate_brickwork_edges(nodes)
#%% brickwork suitable for device
import networkx as nx
G_device = nx.grid_2d_graph(2, 3)
edge_d = G_device.edges()
edge = []
for (i1, j1), (i2, j2) in edge_d:
    node1 = i1 * 3 + j1
    node2 = i2 * 3 + j2
    edge.append((node1, node2))
#%% keep last k terms of hamiltonian string
def keep_last_k_terms(hamiltonian_string, k):
    if k <= 0:
        return ""
    terms = hamiltonian_string.split('+')[1:]  
    if k >= len(terms):
        return hamiltonian_string  

    last_k_terms = terms[-k:]
    return '+' + '+'.join(last_k_terms)

k = 198
H2D = keep_last_k_terms(H2D, k)
H2D1 = keep_last_k_terms(H2D1, k)

#%% maxcut
import networkx as nx
def initial_param(t, theta=None, a=None, weights=None):
    return weights
def ry_gate(theta):
    return tf.convert_to_tensor([
        [tf.cos(theta / 2), -tf.sin(theta / 2)],
        [tf.sin(theta / 2), tf.cos(theta / 2)]
    ], dtype=tf.float32)
def tensor_product_gates(*gates):
    operators = [tf.linalg.LinearOperatorFullMatrix(gate) for gate in gates]
    result = tf.linalg.LinearOperatorKronecker(operators)
    return result.to_dense()

def maxcut_test(G,result_x):
    color_map = []
    for i in range(len(G.nodes())):
        if result_x[i]==-1:
            color_map.append('red') 
        else:
            color_map.append('blue') 
            
    group_A = [i for i, color in enumerate(color_map) if color == 'red']
    group_B = [i for i, color in enumerate(color_map) if color == 'blue']
    cut_size = nx.algorithms.cut_size(G, group_A)
       
    return group_A, group_B, cut_size


# G = nx.grid_2d_graph(3, 3)
# G = nx.convert_node_labels_to_integers(G)
# pos = nx.spring_layout(G)
# nx.draw(G, pos, with_labels=True, node_color='lightblue')
# plt.show()
# G = nx.erdos_renyi_graph(n=45, p=0.3)  # edge prob = 0.3
# G = nx.erdos_renyi_graph(n=1485, p=0.01)
num_G = 0.5*len(G.edges())+0.25*(len(G.nodes())-1)
edges_G = G.edges()
# print("V:", list(G.nodes()))
# print("E:", list(G.edges()))
# save
# import os
# base_dir = "/home/Mengzhen/signproblem/result/maxcut"
# filename = "G45_0.gml"
# os.makedirs(base_dir, exist_ok=True)
# full_path = os.path.join(base_dir, filename)
# nx.write_gml(G, full_path)

# load
# G= nx.read_gml(full_path, label=None) 
# plot
# pos = nx.spring_layout(G)
# nx.draw(G, pos, with_labels=True, node_color='lightblue')
# plt.show()

#%% sign-vqnhe, sampling
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
H=str2WeightedPaulis(H2D1).to_matrix(sparse=1)
u,w=sparse.linalg.eigs(H,k=4,which='SR')
GS=np.where(abs(u-min(u))<1e-5)[0]
wh=abs(w[:,GS].reshape(-1))
wh/=np.sqrt(wh.conj().dot(wh))
h0=convert_sparse_matrix_to_sparse_tensor(H)
h = str2WeightedPaulis_H2D(H2D)
epoch = 1
max_epochs = 2
gradient_threshold = 1e-3
previous_f2 = None
theta_ry = np.ones(n) * 0.5 * np.pi  
theta_rz = np.array([]) 
best_histories = []
pretrained_weights = None
previous_best_f2 = []
best_results_all = []
Eny = [0]
while epoch <= max_epochs:
    fq = list(range(n))       
    if previous_f2 is not None:
        thetas = tf.Variable(np.random.rand(n) * 2 * np.pi - np.pi, dtype=tf.float32)
        optimizer = tf.keras.optimizers.Adam(learning_rate=0.01)
        previous_f2_real = tf.cast(tf.math.real(previous_f2), tf.float32)
        # complex
        # previous_f2_real = tf.cast(tf.abs(previous_f2), tf.float32)
        # Optimization loop to match previous f2
        for _ in range(1000):  # 1000,1500
            with tf.GradientTape() as tape:
                ry_gates = [ry_gate(theta) for theta in thetas]
                C_y = tensor_product_gates(*ry_gates)
                loss = tf.reduce_sum(tf.abs(C_y - tf.linalg.diag(previous_f2_real)) ** 2)            
            gradients = tape.gradient(loss, thetas)
            if gradients is not None:
                optimizer.apply_gradients([(gradients, thetas)])                
        theta_ry = np.concatenate([theta_ry, thetas.numpy()])
        print(f"\nComplete training of theta_ry")
        
        pretrain_tries = 5
        best_pretrain_energy = float('inf')
        best_pretrain_weights = None        
        print(f"\nPre-training neural network for epoch {epoch}")        
        for pretrain_idx in range(pretrain_tries):
            print(f"Pre-training attempt {pretrain_idx + 1}/{pretrain_tries}")           
            vqeinstance_pretrain = VQNHE(
                num_G,
                edges_G,
                theta_ry,
                theta_rz,
                n,
                h0,
                h,
                {"depth": 3, "width": 2, "choose": "real"},
                # {"depth": 5, "width": 3, "choose": "real"},
                {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea4"},
                shortcut=False,
            )
    
            t = n + len(edge)
            zero_theta = np.zeros(t)
            
            init_dict = {
                "q": tf.Variable(zero_theta),
                "c": None
            }
            
            rs_pretrain = vqeinstance_pretrain.multi_training(
                tries=1,
                maxiter=150, #150,200
                threshold=1E-7 * 0.5,
                onlyq=0,
                debug=30,
                qon=0,
                initialization_func=lambda try_idx: init_dict
            )
                
            current_pretrain_energy = rs_pretrain[0]['history'][-1]

            if current_pretrain_energy < best_pretrain_energy:
                best_pretrain_energy = current_pretrain_energy
                best_pretrain_weights = rs_pretrain[0]['model_weights']
                print(f"New best pre-training energy: {best_pretrain_energy}")
        
        print(f"\nBest pre-training energy achieved: {best_pretrain_energy}")
        pretrained_weights = best_pretrain_weights
    
    num_tries = 5 #5
    best_energy = float('inf')
    best_results = None
    best_circuit = None
    best_history_current_epoch = None
    
    print(f"\nStarting main training for Epoch {epoch}")
    
    for try_idx in range(num_tries):
        print(f"Epoch {epoch}, Try {try_idx + 1}/{num_tries}")
        
        vqeinstance = VQNHE(
            num_G,
            edges_G,
            theta_ry,
            theta_rz,
            n,
            h0,
            h,
            {"depth": 3, "width": 2, "choose": "real"},
            # {"depth": 5, "width": 3, "choose": "real"},
            # {"width":2, "stddev": 0.01, "choose": "complex-rbm"},
            {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea4"},
            shortcut=False,
        )
        
        cir = vqeinstance.circuit
        t = n + len(edge)  
        # theta = (np.random.rand(t)-0.5)*2*np.pi
        if previous_f2 is not None:
            theta = np.zeros(t)
        else:
            theta = (np.random.rand(t)-0.5)*2*np.pi

        init_params = {"q": tf.Variable(theta)}
        if pretrained_weights is not None:
            init_params["c"] = pretrained_weights
        # test = int(100+50*(epoch-1))
        rs1 = vqeinstance.multi_training(
            tries=1,
            maxiter=50, #50,100
            threshold=1E-7 * 0.5,
            onlyq=0,
            debug=10,
            qon=50,
            initialization_func=partial(initial_param, weights=init_params)
        )
        
        current_energy = rs1[0]['history'][-1]
        
        if current_energy < best_energy:
            best_energy = current_energy
            best_results = rs1[0]
            best_circuit = vqeinstance
            best_history_current_epoch = rs1[0]['history']
            print(f"New best energy in epoch {epoch}: {best_energy}")
    
    best_histories.append({
        'epoch': epoch,
        'history': best_history_current_epoch,
        'final_energy': best_energy,
        'model_weights': best_results['model_weights'],
        'pretrained_weights': pretrained_weights  
    })
    
    Eny.append(best_energy)
    previous_f2 = best_results['amp_f2'][-1]
    previous_best_f2.append(previous_f2)
    best_results_all.append(best_results)
    
    if len(Eny) > 1:
        gradient = np.abs(np.gradient(Eny)).mean()
        if gradient > gradient_threshold:
            qv = best_results_all[-1]['qgrad'][-1]
            theta_rz = np.concatenate([theta_rz, qv])
            epoch += 1
            print(f"Gradient {gradient:.2e} greater than threshold, increasing epoch to {epoch}")
            print(f"Current theta_rz shape: {theta_rz.shape}")
        else:
            break
    else:
        break

result_vqnhe = best_results_all[-1]['sign'][-1]
vqnhe_A, vqnhe_B, vqnhe_maxcut = maxcut_test(G,result_vqnhe)

# with open('signproblem/result/maxcut/exp/noise/g45_0_vqnhe_positiveNN_less_p2.pkl', 'wb') as f:
#     pickle.dump(best_results_all, f)

# with open('signproblem/result/maxcut/exp/noise/g45_0_vqnhe_noisetest.pkl', 'rb') as f:
#     noisetest = pickle.load(f)
#%% save, for numerical maxcut problem
# with open('signproblem/result/maxcut/exp/maxcut45_vqnhe_2.pkl', 'wb') as f:
#     pickle.dump(best_results_all, f)

# with open('signproblem/result/maxcut/maxcut18_vqnhe_2_c53.pkl', 'wb') as f:
#     pickle.dump(best_results_all, f)
# maxcut9_vqnhe_0_e1: 9 vertex, G9_0, epoch=1, c32, 50*1
# maxcut9_vqnhe_0_2e1: epoch=1, 100*1
# maxcut9_vqnhe_0: epoch=2, c32, 50*2
# maxcut9_vqnhe_0_c53: epoch=2, c53, 100*2
#%% svqnhe benchmark, maxcut Heisenberg (power 2/3/4)
import os
from tensorcircuit.applications.vqes import VQNHE, JointSchedule

save_dir = "/home/Mengzhen/signproblem/result/maxcut_graph_benchmark/"
# graph_filename = os.path.join(save_dir, f"maxcut_graph_n{n_l}_idx{i}.pkl")
# with open(graph_filename, "wb") as f:
#     pickle.dump(G, f)

#n_list = [135, 570, 1305] # qubit 10, 20, 30
# n_list = [198]
n_list = [1485]
# n_list = [135]
num_graphs = 1

H=str2WeightedPaulis(H2D1).to_matrix(sparse=1)
u,w=sparse.linalg.eigs(H,k=4,which='SR')
GS=np.where(abs(u-min(u))<1e-5)[0]
wh=abs(w[:,GS].reshape(-1))
wh/=np.sqrt(wh.conj().dot(wh))
h0=convert_sparse_matrix_to_sparse_tensor(H)
h = str2WeightedPaulis_H2D(H2D)
max_epochs = 1
gradient_threshold = 1e-3

svqnhe_cut_results = {}

for n_l in n_list:
    cut_edges_list = []
    for i in range(num_graphs):
        i = i+4
        # load graph
        graph_filename = os.path.join(save_dir, f"maxcut_graph_n{n_l}_idx{i}.pkl")
        with open(graph_filename, "rb") as f:
            G = pickle.load(f)
        num_G = 0.5*len(G.edges())+0.25*(len(G.nodes())-1)
        edges_G = G.edges()
        # svqnhe
        epoch = 1
        previous_f2 = None
        theta_ry = np.ones(n) * 0.5 * np.pi  
        theta_rz = np.array([]) 
        best_histories = []
        pretrained_weights = None
        previous_best_f2 = []
        best_results_all = []
        Eny = [0]
        while epoch <= max_epochs:
            fq = list(range(n))       
            if previous_f2 is not None:
                thetas = tf.Variable(np.random.rand(n) * 2 * np.pi - np.pi, dtype=tf.float32)
                optimizer = tf.keras.optimizers.Adam(learning_rate=0.01)
                previous_f2_real = tf.cast(tf.math.real(previous_f2), tf.float32)
                # complex
                # previous_f2_real = tf.cast(tf.abs(previous_f2), tf.float32)
                # Optimization loop to match previous f2
                for _ in range(1000):  # 1000,1500
                    with tf.GradientTape() as tape:
                        ry_gates = [ry_gate(theta) for theta in thetas]
                        C_y = tensor_product_gates(*ry_gates)
                        loss = tf.reduce_sum(tf.abs(C_y - tf.linalg.diag(previous_f2_real)) ** 2)            
                    gradients = tape.gradient(loss, thetas)
                    if gradients is not None:
                        optimizer.apply_gradients([(gradients, thetas)])                
                theta_ry = np.concatenate([theta_ry, thetas.numpy()])
                print(f"\nComplete training of theta_ry")
                
                pretrain_tries = 2
                best_pretrain_energy = float('inf')
                best_pretrain_weights = None        
                print(f"\nPre-training neural network for epoch {epoch}")        
                for pretrain_idx in range(pretrain_tries):
                    print(f"Pre-training attempt {pretrain_idx + 1}/{pretrain_tries}")           
                    vqeinstance_pretrain = VQNHE(
                        num_G,
                        edges_G,
                        theta_ry,
                        theta_rz,
                        n,
                        h0,
                        h,
                        # {"depth": 3, "width": 6, "choose": "real"},
                        {"depth": 3, "width": 10, "choose": "real"},
                        # {"depth": 3, "width": 6, "choose": "complex"},
                        # {"width":2, "stddev": 0.01, "choose": "complex-rbm",
                         # "current_epoch": epoch}, 
                        # {"depth": 3, "width": 6, "choose": "complex", "current_epoch": epoch},
                        # {"width":256, "stddev": 0.01, "choose": "complex-rbm"},
                        # {"width":10, "set_depth":2, "stddev": 0.01, "choose": "complex-rbm"},
                        {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea4"},
                        shortcut=False,
                    )
            
                    t = n + len(edge)
                    zero_theta = np.zeros(t)
                    
                    init_dict = {
                        "q": tf.Variable(zero_theta),
                        "c": None
                    }
                    
                    rs_pretrain = vqeinstance_pretrain.multi_training(
                        tries=1,
                        maxiter=100, #150,200,300
                        threshold=1E-7 * 0.5,
                        onlyq=0,
                        debug=50,
                        qon=0,
                        initialization_func=lambda try_idx: init_dict
                    )
                        
                    current_pretrain_energy = rs_pretrain[0]['history'][-1]

                    if current_pretrain_energy < best_pretrain_energy:
                        best_pretrain_energy = current_pretrain_energy
                        best_pretrain_weights = rs_pretrain[0]['model_weights']
                        print(f"New best pre-training energy: {best_pretrain_energy}")
                
                print(f"\nBest pre-training energy achieved: {best_pretrain_energy}")
                pretrained_weights = best_pretrain_weights
            
            # num_tries = int(2+3*(epoch-1)*(epoch-2)) #5
            # num_tries = int(5-4*(epoch-1))
            num_tries = 2
            best_energy = float('inf')
            best_results = None
            best_circuit = None
            best_history_current_epoch = None
            
            print(f"\nStarting main training for Epoch {epoch}")
            
            for try_idx in range(num_tries):
                print(f"Epoch {epoch}, Try {try_idx + 1}/{num_tries}")
                
                vqeinstance = VQNHE(
                    num_G,
                    edges_G,
                    theta_ry,
                    theta_rz,
                    n,
                    h0,
                    h,
                    # {"depth": 3, "width": 6, "choose": "real"},
                    {"depth": 3, "width": 10, "choose": "real"},
                    # {"depth": 3, "width": 6, "choose": "complex"},
                    # {"width":2, "stddev": 0.01, "choose": "complex-rbm",
                     # "current_epoch": epoch}, 
                    # {"depth": 3, "width": 6, "choose": "complex", "current_epoch": epoch},
                    # {"width":256, "stddev": 0.01, "choose": "complex-rbm"},
                    # {"width":10, "set_depth":2, "stddev": 0.01, "choose": "complex-rbm"},
                    {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea4"},
                    shortcut=False,
                )
                
                cir = vqeinstance.circuit
                t = n + len(edge)  
                theta = (np.random.rand(t)-0.5)*2*np.pi
                # if previous_f2 is not None:
                #     theta = np.zeros(t)
                # else:
                #     theta = (np.random.rand(t)-0.5)*2*np.pi

                init_params = {"q": tf.Variable(theta)}
                if pretrained_weights is not None:
                    init_params["c"] = pretrained_weights
                # test = int(30+540*(epoch-1))
                # test = int(300+400*(epoch-1))
                rs1 = vqeinstance.multi_training(
                    tries=1,
                    maxiter=600, 
                    threshold=1E-7 * 0.5,
                    onlyq=0,
                    debug=60,
                    qon=0,
                    initialization_func=partial(initial_param, weights=init_params)
                )
                
                current_energy = rs1[0]['history'][-1]
                
                if current_energy < best_energy:
                    best_energy = current_energy
                    best_results = rs1[0]
                    best_circuit = vqeinstance
                    best_history_current_epoch = rs1[0]['history']
                    print(f"New best energy in epoch {epoch}: {best_energy}")
            
            best_histories.append({
                'epoch': epoch,
                'history': best_history_current_epoch,
                'final_energy': best_energy,
                'model_weights': best_results['model_weights'],
                'pretrained_weights': pretrained_weights  
            })
            
            Eny.append(best_energy)
            previous_f2 = best_results['amp_f2'][-1]
            previous_best_f2.append(previous_f2)
            best_results_all.append(best_results)
            
            if len(Eny) > 1:
                gradient = np.abs(np.gradient(Eny)).mean()
                if gradient > gradient_threshold:
                    qv = best_results_all[-1]['qgrad'][-1]
                    theta_rz = np.concatenate([theta_rz, qv])
                    epoch += 1
                    print(f"Gradient {gradient:.2e} greater than threshold, increasing epoch to {epoch}")
                    print(f"Current theta_rz shape: {theta_rz.shape}")
                else:
                    break
            else:
                break
        
        # result_hist = best_results_all[-1]['history']
        # min_index = result_hist.index(min(result_hist))
        # result_vqnhe = best_results_all[-1]['sign'][min_index]
        result_vqnhe = best_results_all[-1]['sign'][-1]
        vqnhe_A, vqnhe_B, vqnhe_maxcut = maxcut_test(G,result_vqnhe)
        cut_edges_list.append(vqnhe_maxcut)
        
        print(f"n={n_l}, graph {i+1}/{num_graphs}, cut_edges={vqnhe_maxcut}")

    svqnhe_cut_results[n_l] = cut_edges_list

# with open('/home/Mengzhen/signproblem/result/maxcut_benchmark_results/test/g1485_1_vqnhe_mlp36_e2.pkl', 'wb') as f:
#     pickle.dump(best_results_all, f)
# with open('/home/Mengzhen/signproblem/result/maxcut_benchmark_results/g1485/i4_q-mlp310_e2_0.pkl', 'wb') as f:
#     pickle.dump(best_results_all, f)
# with open('/home/Mengzhen/signproblem/result/maxcut_benchmark_results/g1485/i4_mlp310_nn_0.pkl', 'wb') as f:
#     pickle.dump(best_results_all, f)

# with open('signproblem/result/maxcut_benchmark_results/test/g1485_1_vqnhe_qcset_e1_2.pkl', 'rb') as f:
#     result_vqnhe_test = pickle.load(f)
# result_vqnhe=result_vqnhe_test[-1]['sign'][-1]
# vqnhe_A, vqnhe_B, vqnhe_maxcut = maxcut_test(G,result_vqnhe)
# vqnhe_maxcut
# test_cut=[]
# for i in range(570):
#     result_vqnhe = best_results_all[-1]['sign'][i]
#     vqnhe_A, vqnhe_B, vqnhe_maxcut = maxcut_test(G,result_vqnhe)
#     test_cut.append(vqnhe_maxcut)
# max(test_cut)
# total_params = sum(np.prod(var.shape) for var in cv if isinstance(var, tf.Variable))
#%% vqe: hea1
def num_param(n, epochs):
    total = n*epochs
    for epoch in range(epochs):
        if n % 2 == 1:  
            total += (n - 1) // 2
        else:  
            if epoch % 2 == 0:  
                total += n // 2
            else:  
                total += (n // 2) - 1                
    return total


from tensorcircuit.applications.vqes import VQNHE, JointSchedule
H=str2WeightedPaulis(H2D1).to_matrix(sparse=1)
u,w=sparse.linalg.eigs(H,k=4,which='SR')
GS=np.where(abs(u-min(u))<1e-5)[0]
wh=abs(w[:,GS].reshape(-1))
wh/=np.sqrt(wh.conj().dot(wh))
h0=convert_sparse_matrix_to_sparse_tensor(H)
h = str2WeightedPaulis_H2D(H2D)
epoch = 1 #n
max_epochs = 2 #n
gradient_threshold = 1e-3
previous_f2 = None
theta_ry = np.ones(n) * 0.5 * np.pi  
theta_rz = np.array([]) 
best_histories = []
pretrained_weights = None
previous_best_f2 = []
best_results_all = []
Eny = [0]
while epoch <= max_epochs:
    fq = list(range(n)) 
    num_tries = 5 #5
    best_energy = float('inf')
    best_results = None
    best_circuit = None
    best_history_current_epoch = None
    
    print(f"\nStarting main training for Epoch {epoch}")
    
    for try_idx in range(num_tries):
        print(f"Epoch {epoch}, Try {try_idx + 1}/{num_tries}")
        
        vqeinstance = VQNHE(
            num_G,
            edges_G,
            theta_ry,
            theta_rz,
            n,
            h0,
            h,
            {"depth": 3, "width": 2, "choose": "real"},
            # {"depth": 5, "width": 3, "choose": "real"},
            # {"width":2, "stddev": 0.01, "choose": "complex-rbm"},
            {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": n, "choose": "hea1"},
            shortcut=False,
        )
        
        cir = vqeinstance.circuit
        # t =  num_param(n, max_epochs)
        t =  num_param(n, n)
        if epoch==1:
            theta = (np.random.rand(t)-0.5)*2*np.pi
        else:
            theta = qv
        # theta = (np.random.rand(t)-0.5)*2*np.pi
        init_params = {"q": tf.Variable(theta)}
        if pretrained_weights is not None:
            init_params["c"] = pretrained_weights
        
        rs1 = vqeinstance.multi_training(
            tries=1,
            maxiter=100,
            threshold=1E-7 * 0.5,
            onlyq=100, #50,100
            debug=20,
            qon=0,
            initialization_func=partial(initial_param, weights=init_params)
        )
        
        current_energy = rs1[0]['history'][-1]
        
        if current_energy < best_energy:
            best_energy = current_energy
            best_results = rs1[0]
            best_circuit = vqeinstance
            best_history_current_epoch = rs1[0]['history']
            print(f"New best energy in epoch {epoch}: {best_energy}")
    
    best_histories.append({
        'epoch': epoch,
        'history': best_history_current_epoch,
        'final_energy': best_energy,
        'model_weights': best_results['model_weights'],
        'pretrained_weights': pretrained_weights  
    })
    
    Eny.append(best_energy)
    # previous_f2 = best_results['amp_f2'][-1]
    previous_best_f2.append(previous_f2)
    best_results_all.append(best_results)
    
    if len(Eny) > 1:
        gradient = np.abs(np.gradient(Eny)).mean()
        if gradient > gradient_threshold:
            qv = best_results_all[-1]['qgrad'][-1]
            # qv = best_circuit.circuit_variable.numpy()
            # theta_rz = np.concatenate([theta_rz, best_circuit.circuit_variable.numpy()])
            epoch += 1
            print(f"Gradient {gradient:.2e} greater than threshold, increasing epoch to {epoch}")
            print(f"Current theta_rz shape: {theta_rz.shape}")
        else:
            break
    else:
        break
result_hea1 = best_results_all[-1]['sign'][-1]
hea1_A, hea1_B, hea1_maxcut = maxcut_test(G,result_hea1)
with open('signproblem/result/maxcut/maxcut18_hea1_1_c53.pkl', 'wb') as f:
    pickle.dump(best_results_all, f)

#%% hea2
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
H=str2WeightedPaulis(H2D1).to_matrix(sparse=1)
u,w=sparse.linalg.eigs(H,k=4,which='SR')
GS=np.where(abs(u-min(u))<1e-5)[0]
wh=abs(w[:,GS].reshape(-1))
wh/=np.sqrt(wh.conj().dot(wh))
h0=convert_sparse_matrix_to_sparse_tensor(H)
h = str2WeightedPaulis_H2D(H2D)
epoch = 1
max_epochs = 2
gradient_threshold = 1e-3
previous_f2 = None
theta_ry = np.ones(n) * 0.5 * np.pi  
theta_rz = np.array([]) 
best_histories = []
pretrained_weights = None
previous_best_f2 = []
best_results_all = []
Eny = [0]
while epoch <= max_epochs:
    fq = list(range(n)) 
    num_tries = 5 #5
    best_energy = float('inf')
    best_results = None
    best_circuit = None
    best_history_current_epoch = None
    
    print(f"\nStarting main training for Epoch {epoch}")
    
    for try_idx in range(num_tries):
        print(f"Epoch {epoch}, Try {try_idx + 1}/{num_tries}")
        
        vqeinstance = VQNHE(
            num_G,
            edges_G,
            theta_ry,
            theta_rz,
            n,
            h0,
            h,
            {"depth": 3, "width": 2, "choose": "real"},
            # {"depth": 5, "width": 3, "choose": "real"},
            # {"width":2, "stddev": 0.01, "choose": "complex-rbm"},
            {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": max_epochs, "choose": "hea2"},
            shortcut=False,
        )
        
        cir = vqeinstance.circuit
        # t =  num_param(n, epoch)
        t = (2*n + len(edge))*max_epochs
        if epoch==1:
            theta = (np.random.rand(t)-0.5)*2*np.pi
        else:
            theta = qv
        # theta = (np.random.rand(t)-0.5)*2*np.pi

        init_params = {"q": tf.Variable(theta)}
        if pretrained_weights is not None:
            init_params["c"] = pretrained_weights
        
        rs1 = vqeinstance.multi_training(
            tries=1,
            maxiter=50,#50,100
            threshold=1E-7 * 0.5,
            onlyq=50,
            debug=10,
            qon=0,
            initialization_func=partial(initial_param, weights=init_params)
        )
        
        current_energy = rs1[0]['history'][-1]
        
        if current_energy < best_energy:
            best_energy = current_energy
            best_results = rs1[0]
            best_circuit = vqeinstance
            best_history_current_epoch = rs1[0]['history']
            print(f"New best energy in epoch {epoch}: {best_energy}")
    
    best_histories.append({
        'epoch': epoch,
        'history': best_history_current_epoch,
        'final_energy': best_energy,
        'model_weights': best_results['model_weights'],
        'pretrained_weights': pretrained_weights  
    })
    
    Eny.append(best_energy)
    # previous_f2 = best_results['amp_f2'][-1]
    previous_best_f2.append(previous_f2)
    best_results_all.append(best_results)
    
    if len(Eny) > 1:
        gradient = np.abs(np.gradient(Eny)).mean()
        if gradient > gradient_threshold:
            qv = best_results_all[-1]['qgrad'][-1]
            # qv = best_circuit.circuit_variable.numpy()
            # theta_rz = np.concatenate([theta_rz, best_circuit.circuit_variable.numpy()])
            epoch += 1
            print(f"Gradient {gradient:.2e} greater than threshold, increasing epoch to {epoch}")
            print(f"Current theta_rz shape: {theta_rz.shape}")
        else:
            break
    else:
        break
result_hea2 = best_results_all[-1]['sign'][-1]
hea2_A, hea2_B, hea2_maxcut = maxcut_test(G,result_hea2)
# with open('signproblem/result/maxcut/maxcut9_hea2_0.pkl', 'wb') as f:
#     pickle.dump(best_results_all, f)

#%% hea3
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
H=str2WeightedPaulis(H2D1).to_matrix(sparse=1)

def initial_param(t, theta=None, a=None, weights=None):
    return weights

u,w=sparse.linalg.eigs(H,k=4,which='SR')
GS=np.where(abs(u-min(u))<1e-5)[0]
wh=abs(w[:,GS].reshape(-1))
wh/=np.sqrt(wh.conj().dot(wh))
h0=convert_sparse_matrix_to_sparse_tensor(H)
h = str2WeightedPaulis_H2D(H2D)
epoch = 1
max_epochs = 2
gradient_threshold = 1e-3
previous_f2 = None
theta_ry = np.array([])
theta_rz = np.array([]) 
Eny = [0]
best_histories = []
previous_best_weights = None
previous_best_f2 = []
best_results_all = []
num_tries = 5
while epoch <= max_epochs:
    fq = list(range(n)) 
    best_energy = float('inf')
    best_results = None
    best_circuit = None
    best_history_current_epoch = None         
    for try_idx in range(num_tries):
        print(f"Epoch {epoch}, Try {try_idx + 1}/{num_tries}")            
        vqeinstance = VQNHE(
            num_G,
            edges_G,
            theta_ry,
            theta_rz,
            n,
            h0,
            h,
            {"depth": 3, "width": 2, "choose": "real"},
            # {"width":3, "stddev": 0.01, "choose": "real-rbm"},
            {"filled_qubit": fq, "edge": edge, "stddev": 0.01, "channel": 1, "epochs": epoch, "choose": "hea3"},
            shortcut=False,
        )
        
        cir = vqeinstance.circuit
        t = 2*n + len(edge)  
        theta = (np.random.rand(t)-0.5)*2*np.pi
        # if epoch==1:
        #     theta[:n] = np.ones(n) * 0.5 * np.pi
        init_params = {"q": tf.Variable(theta)}
        if previous_best_weights is not None:
            init_params["c"] = previous_best_weights
        rs1 = vqeinstance.multi_training(
            tries=1,
            maxiter=50,
            threshold=1E-7 * 0.5,
            onlyq=50,
            debug=10,
            qon=0,
            initialization_func=partial(initial_param, weights=init_params)
        )
        
        current_energy = rs1[0]['history'][-1]
        
        if current_energy < best_energy:
            best_energy = current_energy
            best_results = rs1[0]
            best_circuit = vqeinstance
            best_history_current_epoch = rs1[0]['history']
            print(f"New best energy: {best_energy}")
    best_histories.append({
    'epoch': epoch,
    'history': best_history_current_epoch,
    'final_energy': best_energy
    })
    Eny.append(best_energy)
    best_results_all.append(best_results)
    
    if len(Eny) > 1:
        gradient = np.abs(np.gradient(Eny)).mean()
        if gradient > gradient_threshold:
            qv = best_results_all[-1]['qgrad'][-1]
            # qv = best_circuit.circuit_variable.numpy()
            theta_rz = np.concatenate([theta_rz, qv[n:]])
            theta_ry = np.concatenate([theta_ry, qv[:n]])
            epoch += 1
            print(f"Gradient {gradient:.2e} greater than threshold, increasing epoch to {epoch}")
        else:
            break
    else:
        break
result_hea3 = best_results_all[1]['sign'][-1]
hea3_A, hea3_B, hea3_maxcut = maxcut_test(G,result_hea3)
with open('signproblem/result/maxcut/maxcut18_hea3_1.pkl', 'wb') as f:
    pickle.dump(best_results_all, f)
    
#%% analysis
import matplotlib.pyplot as plt
import numpy as np

# Data (example values)
algorithms = ['sign-VQNHE', 'brickwork-VQE', 'sign-VQE']
n9_metrics = [[0.925, 0.95833], [0.86667, 0.9], [0.85, 0.89167]]  # 9-node, [Param1, Param2]
n45_metrics = [[1, 1], [0.88219, 0.83228], [0.84737, 0.83737]]  # 45-node

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

# Subplot 1: 9-node results
x = np.arange(len(algorithms))
width = 0.35
ax1.bar(x - width/2, [n9[0] for n9 in n9_metrics], width, label='Param Set 1', color='blue')
ax1.bar(x + width/2, [n9[1] for n9 in n9_metrics], width, label='Param Set 2', color='lightblue')
ax1.set_xticks(x)
ax1.set_xticklabels(algorithms)
ax1.set_title('9-vertex Graph')
ax1.set_ylabel('Relative solution quality (Log Scale)')
ax1.set_yscale('log')

# Subplot 2: 45-node results
ax2.bar(x - width/2, [n45[0] for n45 in n45_metrics], width, color='blue', label='Param Set 1')
ax2.bar(x + width/2, [n45[1] for n45 in n45_metrics], width, color='lightblue', label='Param Set 2')
ax2.set_xticks(x)
ax2.set_xticklabels(algorithms)
ax2.set_title('45-vertex Graph')
ax2.set_yscale('log')

# Highlight sign-VQNHE bars
# for ax in [ax1, ax2]:
#     ax.patches[0].set_edgecolor('red')  # First bar (sign-VQNHE, Param1)
#     ax.patches[1].set_edgecolor('red')  # First bar (sign-VQNHE, Param2)

plt.legend()
plt.show()
#%% 2 plot (9,45)
import matplotlib.pyplot as plt
import numpy as np

# Set default font size
plt.rcParams['font.size'] = 10

# Sample data for first subplot
data_9_vertices = {
    'sign-VQNHE': [0.925, 0.95833],
    'brickwork-VQE': [0.86667, 0.9],
    'sign-VQE': [0.85, 0.89167]
}

data_45_vertices = {
    'sign-VQNHE': [1, 1],
    'brickwork-VQE': [0.88219, 0.83228],
    'sign-VQE': [0.91185, 0.83737]
}

# Define problem sizes and algorithm names
problem_sizes = ['9 vertices', '45 vertices']
algorithms = ['sign-\nVQNHE', 'brickwork-\nVQE', 'sign-\nVQE']
data = [data_9_vertices, data_45_vertices]

# Bar settings
bar_width = 0.1
spacing = 0.05
group_spacing = 0.1

# Calculate bar positions
x = np.arange(len(problem_sizes)) * (len(algorithms) * (bar_width * 2 + spacing) + group_spacing)
positions = []
for i in range(len(problem_sizes)):
    for j in range(len(algorithms)):
        pos = x[i] + j * (bar_width * 2 + spacing)
        positions.append([pos, pos + bar_width])

# Create the figure with two subplots
fig, (ax, ax1) = plt.subplots(1, 2, figsize=(12, 6))

# First subplot: Algorithm Performance Comparison
colors = ['blue', 'lightblue']
for i, problem_size in enumerate(problem_sizes):
    for j, algo in enumerate(algorithms):
        values = data[i][algo.replace('\n', '')]
        ax.bar(positions[i * len(algorithms) + j][0], values[0], bar_width,
               label='Param Set 1' if i == 0 and j == 0 else None, color=colors[0])
        ax.bar(positions[i * len(algorithms) + j][1], values[1], bar_width,
               label='Param Set 2' if i == 0 and j == 0 else None, color=colors[1])

ax.set_xlabel('Problem Size')
ax.set_ylabel('Relative Solution Quality')
ax.set_ylim(0.8, 1.02)

# Center x-ticks under each problem size group
tick_positions = [
    (positions[i * len(algorithms)][0] + positions[i * len(algorithms) + len(algorithms) - 1][1]) / 2
    for i in range(len(problem_sizes))
]
ax.set_xticks(tick_positions)
ax.set_xticklabels(problem_sizes)

# Add algorithm labels below bars
for i, problem_size in enumerate(problem_sizes):
    for j, algo in enumerate(algorithms):
        pos = positions[i * len(algorithms) + j]
        ax.text(pos[0] + bar_width / 2, -0.08, algo, ha='center', va='top',
                rotation=45, transform=ax.get_xaxis_transform())

ax.legend(fontsize=10)

# Second subplot: Measurement Cost
groups = ['Vertex[9]', 'Vertex[18]', 'Vertex[30]', 'Vertex[45]']
index = np.arange(len(groups))

data1 = np.array([10, 19, 31, 46])
data2 = np.array([72, 132, 210, 306])
data3 = np.array([108, 168, 240, 324])

bars1 = ax1.bar(index, data1, bar_width*2, label='sign-VQNHE', color='blue')
bars2 = ax1.bar(index + bar_width*2, data2, bar_width*2, label='brickwork-VQE', color='green')
bars3 = ax1.bar(index + 2 * bar_width*2, data3, bar_width*2, label='sign-VQE', color='red')

# Add text annotations above each bar
for bar in bars1:
    yval = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width() / 2, yval + 0.5, int(yval), ha='center', va='bottom')

for bar in bars2:
    yval = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width() / 2, yval + 0.5, int(yval), ha='center', va='bottom')

for bar in bars3:
    yval = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width() / 2, yval + 0.5, int(yval), ha='center', va='bottom')

# Customize second subplot
ax1.set_xlabel('Model', fontsize=10)
ax1.set_ylabel('Measurement Cost', fontsize=10)
ax1.set_xticks(index + bar_width)  # Center ticks under the group
ax1.set_xticklabels(groups, fontsize=10)
ax1.set_yscale('log')
ax1.legend(fontsize=10)

# Adjust layout and display
plt.tight_layout()
plt.show()
#%% 
import matplotlib.pyplot as plt
import numpy as np

# Set default font size
plt.rcParams['font.size'] = 8

# Sample data for first subplot
data_9_vertices = {
    'sign-VQNHE': [0.925, 0.95833],
    'brickwork-VQE': [0.86667, 0.9],
    'sign-VQE': [0.89167, 0.89167]
}

std_9_vertices = {
    'sign-VQNHE': [0.06614, 0.07217],
    'brickwork-VQE': [0.11547, 0.1],
    'sign-VQE': [0.10104, 0.10104]
}

data_45_vertices = {
    'sign-VQNHE': [1, 1],
    'brickwork-VQE': [0.85451, 0.83956],
    'sign-VQE': [0.86372, 0.80396]
}

std_45_vertices = {
    'sign-VQNHE': [0, 0],
    'brickwork-VQE': [0.07185, 0.01131],
    'sign-VQE': [0.0178, 0.07305]
}

# Define problem sizes and algorithm names
problem_sizes = ['9 vertices', '45 vertices']
# algorithms = ['sign-\nVQNHE', 'brickwork-\nVQE', 'sign-\nVQE']
algorithms = ['sign-VQNHE', 'brickwork-VQE', 'sign-VQE']
data = [data_9_vertices, data_45_vertices]

# Bar settings
bar_width = 0.1
spacing = 0.05
group_spacing = 0.1

# Calculate bar positions
x = np.arange(len(problem_sizes)) * (len(algorithms) * (bar_width * 2 + spacing) + group_spacing)
positions = []
for i in range(len(problem_sizes)):
    for j in range(len(algorithms)):
        pos = x[i] + j * (bar_width * 2 + spacing)
        positions.append([pos, pos + bar_width])

# Create the figure with three subplots stacked vertically
fig, (ax, ax1, ax2) = plt.subplots(3, 1, figsize=(8, 12), sharex=False)

# First subplot: Algorithm Performance Comparison (9 and 45 vertices)
colors = ['blue', 'lightblue']
for i, problem_size in enumerate(problem_sizes):
    for j, algo in enumerate(algorithms):
        # values = data[i][algo.replace('\n', '')]
        values = data[i][algo]
        ax.bar(positions[i * len(algorithms) + j][0], values[0], bar_width,
               label='Param Set 1' if i == 0 and j == 0 else None, color=colors[0])
        ax.bar(positions[i * len(algorithms) + j][1], values[1], bar_width,
               label='Param Set 2' if i == 0 and j == 0 else None, color=colors[1])

ax.set_ylabel('Relative Solution Quality')
ax.set_ylim(0.8, 1.02)
ax.set_title('(a) Algorithm Performance (9 and 45 Vertices, p=0.3)')

# Center x-ticks under each problem size group
tick_positions = [
    (positions[i * len(algorithms)][0] + positions[i * len(algorithms) + len(algorithms) - 1][1]) / 2
    for i in range(len(problem_sizes))
]
ax.set_xticks(tick_positions)
ax.set_xticklabels(problem_sizes)

# Add algorithm labels below bars
for i, problem_size in enumerate(problem_sizes):
    for j, algo in enumerate(algorithms):
        pos = positions[i * len(algorithms) + j]
        ax.text(pos[0] + bar_width / 2, -0.1, algo, ha='center', va='top',
                rotation=0, transform=ax.get_xaxis_transform())

ax.legend(fontsize=8)
ax.grid(True, linestyle='--', alpha=0.7)

# Second subplot: Measurement Cost
groups = ['Vertex[9]', 'Vertex[18]', 'Vertex[30]', 'Vertex[45]']
index = np.arange(len(groups))

data1 = np.array([10, 19, 31, 46])
data2 = np.array([72, 132, 210, 306])
data3 = np.array([108, 168, 240, 324])

bars1 = ax1.bar(index, data1, bar_width*2, label='sign-VQNHE', color='blue')
bars2 = ax1.bar(index + bar_width*2, data2, bar_width*2, label='brickwork-VQE', color='green')
bars3 = ax1.bar(index + 2 * bar_width*2, data3, bar_width*2, label='sign-VQE', color='red')

# Add text annotations above each bar
for bar in bars1:
    yval = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width() / 2, yval + 0.5, int(yval), ha='center', va='bottom')

for bar in bars2:
    yval = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width() / 2, yval + 0.5, int(yval), ha='center', va='bottom')

for bar in bars3:
    yval = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width() / 2, yval + 0.5, int(yval), ha='center', va='bottom')

# Customize second subplot
# ax1.set_xlabel('Model')
ax1.set_ylabel('Measurement Cost')
ax1.set_xticks(index + bar_width)  # Center ticks under the group
ax1.set_xticklabels(groups)
ax1.set_yscale('log')
ax1.set_title('(b) Measurement Cost Across Vertex Sizes')
ax1.legend(fontsize=8)
ax1.grid(True, linestyle='--', alpha=0.7)

# Third subplot: Relative Solution Quality for 1485 Vertices
methods = ['sign-VQNHE', 'FEM', 'NN', 'SA']
means = [0.9989, 0.9989, 0.9800, 0.8066]
stds = [0.002287121, 0.001373268, 0.008665233, 0.006121756]

x_pos = np.arange(len(methods))
ax2.errorbar(x_pos, means, yerr=stds, fmt='o-', capsize=5, capthick=1, ecolor='gray', marker='o', markersize=6, linewidth=1.5, label='Relative Solution Quality')
ax2.set_xlabel('Method')
ax2.set_ylabel('Relative Solution Quality')
ax2.set_ylim(0.75, 1.01)
ax2.set_xticks(x_pos)
ax2.set_xticklabels(methods)
ax2.set_title('(c) Algorithm Performance (1485 Vertices, p=0.01)')
ax2.grid(True, linestyle='--', alpha=0.7)
ax2.legend()

# Adjust layout and display
plt.tight_layout()
# plt.savefig('maxcut_performance_stacked_plots.png', dpi=300)
plt.show()
#%% plot for COPs
import matplotlib.pyplot as plt
import numpy as np

# Set default font size
plt.rcParams['font.size'] = 16

# Sample data for first subplot
data_9_vertices = {
    'sign-VQNHE': [0.925, 0.95833],
    'brickwork-VQE': [0.86667, 0.9],
    'sign-VQE': [0.89167, 0.89167]
}

std_9_vertices = {
    'sign-VQNHE': [0.06614, 0.07217],
    'brickwork-VQE': [0.11547, 0.1],
    'sign-VQE': [0.10104, 0.10104]
}

data_45_vertices = {
    'sign-VQNHE': [1, 1],
    'brickwork-VQE': [0.85451, 0.83956],
    'sign-VQE': [0.86372, 0.80396]
}

std_45_vertices = {
    'sign-VQNHE': [0, 0],
    'brickwork-VQE': [0.07185, 0.01131],
    'sign-VQE': [0.0178, 0.07305]
}

# Define problem sizes and algorithm names
problem_sizes = ['9 vertices', '45 vertices']
# algorithms = ['sign-\nVQNHE', 'brickwork-\nVQE', 'sign-\nVQE']
algorithms = ['sign-VQNHE', 'brickwork-VQE', 'sign-VQE']
data = [data_9_vertices, data_45_vertices]
std_data = [std_9_vertices, std_45_vertices]
# Bar settings
bar_width = 0.1
spacing = 0.05
group_spacing = 0.1

# Calculate bar positions
x = np.arange(len(problem_sizes)) * (len(algorithms) * (bar_width * 2 + spacing) + group_spacing)
positions = []
for i in range(len(problem_sizes)):
    for j in range(len(algorithms)):
        pos = x[i] + j * (bar_width * 2 + spacing)
        positions.append([pos, pos + bar_width])

fig, (ax, ax1, ax2, ax_3) = plt.subplots(4, 1, figsize=(14, 18), sharex=False)

# First subplot: Algorithm Performance with error bars (0.5 * std)
colors = ['blue', 'lightblue']
for i, problem_size in enumerate(problem_sizes):
    for j, algo in enumerate(algorithms):
        values = data[i][algo]
        stds = std_data[i][algo]

        # Bar for Param Set 1 (left half)
        ax.bar(positions[i * len(algorithms) + j][0], values[0], bar_width,
               color=colors[0],label='Param Set 1' if i == 0 and j == 0 else None)
        # Error bar for Param Set 1
        ax.errorbar(positions[i * len(algorithms) + j][0] , values[0],
                    yerr=0.5 * stds[0], fmt='none', ecolor='gray', capsize=3, capthick=1)
        
        # Bar for Param Set 2 (right half)
        ax.bar(positions[i * len(algorithms) + j][1], values[1], bar_width,
               color=colors[1],label='Param Set 2' if i == 0 and j == 0 else None)
        # Error bar for Param Set 2
        ax.errorbar(positions[i * len(algorithms) + j][1], values[1],
                    yerr=0.5 * stds[1], fmt='none', ecolor='gray', capsize=3, capthick=1)

ax.set_ylabel('Relative Solution Quality')
ax.set_ylim(0.7, 1.05)
ax.set_title('(a) Algorithm Performance on MaxCut (9 and 45 Vertices, p=0.3)')

# Center x-ticks under each problem size group
tick_positions = [
    (positions[i * len(algorithms)][0] + positions[i * len(algorithms) + len(algorithms) - 1][1]) / 2
    for i in range(len(problem_sizes))
]
ax.set_xticks(tick_positions)
ax.set_xticklabels(problem_sizes)

# Add algorithm labels below bars
for i, problem_size in enumerate(problem_sizes):
    for j, algo in enumerate(algorithms):
        pos = positions[i * len(algorithms) + j]
        ax.text(pos[0] + bar_width / 2, -0.1, algo, ha='center', va='top',
                rotation=0, transform=ax.get_xaxis_transform())

ax.legend(fontsize=16)
ax.grid(True, linestyle='--', alpha=0.7)

# Second subplot: Measurement Cost
groups = ['Vertex[9]', 'Vertex[18]', 'Vertex[30]', 'Vertex[45]']
index = np.arange(len(groups))

data1 = np.array([10, 19, 31, 46])
data2 = np.array([72, 132, 210, 306])
data3 = np.array([108, 168, 240, 324])

bars1 = ax1.bar(index, data1, bar_width*2, label='sign-VQNHE', color='blue')
bars2 = ax1.bar(index + bar_width*2, data2, bar_width*2, label='brickwork-VQE', color='green')
bars3 = ax1.bar(index + 2 * bar_width*2, data3, bar_width*2, label='sign-VQE', color='red')

# Add text annotations above each bar
for bar in bars1:
    yval = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width() / 2, yval + 0.5, int(yval), ha='center', va='bottom')

for bar in bars2:
    yval = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width() / 2, yval + 0.5, int(yval), ha='center', va='bottom')

for bar in bars3:
    yval = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width() / 2, yval + 0.5, int(yval), ha='center', va='bottom')

# Customize second subplot
# ax1.set_xlabel('Model')
ax1.set_ylabel('Measurement Cost')
ax1.set_xticks(index + bar_width)  # Center ticks under the group
ax1.set_xticklabels(groups)
ax1.set_yscale('log')
ax1.set_title('(b) Measurement Cost Across Vertex Sizes')
ax1.legend(fontsize=16)
ax1.grid(True, linestyle='--', alpha=0.7)

# Third subplot: Relative Solution Quality for 1485 Vertices
methods = ['sign-VQNHE', 'FEM', 'NN', 'SA']
means = [0.9989, 0.9989, 0.9800, 0.8066]
stds = [0.002287121, 0.001373268, 0.008665233, 0.006121756]

x_pos = np.arange(len(methods))
ax2.errorbar(x_pos, means, yerr=stds, fmt='o-', capsize=5, capthick=1, ecolor='gray', marker='o', markersize=6, linewidth=1.5, label='Relative Solution Quality')
ax2.set_xlabel('Method')
ax2.set_ylabel('Relative Solution Quality')
ax2.set_ylim(0.75, 1.01)
ax2.set_xticks(x_pos)
ax2.set_xticklabels(methods)
ax2.set_title('(c) Algorithm Performance on MaxCut (1485 Vertices, p=0.01)')
ax2.grid(True, linestyle='--', alpha=0.7)
ax2.legend()

# MaxClique
methods_clique = ['sign-VQNHE', 'Greedy', 'NN', 'VQNHE', 'FEM']
means_clique = [1.000, 0.889, 0.815, 0.815, 0.259]
stds_clique = [0.000, 0, 0.128, 0.128, 0.064]

x_pos_clique = np.arange(len(methods_clique))
ax_3.errorbar(x_pos_clique, means_clique, yerr=stds_clique, fmt='o-', capsize=5, capthick=1,
              ecolor='gray', marker='o', markersize=6, linewidth=1.5, color='purple')
ax_3.set_xlabel('Method')
ax_3.set_ylabel('Relative Clique Quality')
ax_3.set_ylim(0, 1.05)
ax_3.set_xticks(x_pos_clique)
ax_3.set_xticklabels(methods_clique, rotation=0, ha='center')
ax_3.set_title('(d) Algorithm Performance on MaxClique (135 Vertices, p=0.5)')
ax_3.grid(True, linestyle='--', alpha=0.7)


# Adjust layout and display
plt.tight_layout()
import os
save_dir = "/home/Mengzhen/signproblem/result/"
os.makedirs(save_dir, exist_ok=True)

plt.savefig(os.path.join(save_dir, 'cop_scaling_four_subplots.png'), 
            dpi=300, bbox_inches='tight')

plt.show()

#%% Goemans-Williamson method
import cvxpy as cp

def goemans_williamson_maxcut(G,seed=None):
    if seed is not None:
        np.random.seed(seed)
    n = G.number_of_nodes()    
    # SDP
    X = cp.Variable((n, n), symmetric=True)
    constraints = [X >> 0]  
    constraints += [cp.diag(X) == 1]  
    
    # max 1/4 * sum_{i,j} w_ij * (1 - X_ij)
    L = np.zeros((n, n))
    for i, j in G.edges():
        L[i,j] = L[j,i] = 1  # weight=1
    
    objective = cp.Maximize(0.25 * cp.sum(cp.multiply(L, (1 - X))))
    prob = cp.Problem(objective, constraints)
    prob.solve()
    
    X_val = X.value
    try:
        V = np.linalg.cholesky(X_val)
    except np.linalg.LinAlgError:
        # Cholesky
        eigvals, eigvecs = np.linalg.eigh(X_val)
        V = eigvecs @ np.diag(np.sqrt(np.maximum(eigvals, 0)))

    r = np.random.normal(0, 1, n)
    r = r / np.linalg.norm(r)

    signs = np.sign(V @ r)

    cut_value = 0
    for i, j in G.edges():
        if signs[i] != signs[j]:
            cut_value += 1
            
    partition_A = np.where(signs > 0)[0]
    partition_B = np.where(signs <= 0)[0]
    
    return partition_A.tolist(), partition_B.tolist(), cut_value
# repeat
def gw_maxcut_with_repetitions(G, num_trials=2,seed=None):
    if seed is not None:
        np.random.seed(seed)
    best_cut = 0
    best_partition = None   
    for i in range(num_trials):
        try:
            partition_A, partition_B, cut_value = goemans_williamson_maxcut(G,seed=seed+i)
            if cut_value > best_cut:
                best_cut = cut_value
                best_partition = (partition_A, partition_B)
        except Exception as e:
            continue            
    return best_partition[0], best_partition[1], best_cut

gw_A, gw_B, gw_maxcut = gw_maxcut_with_repetitions(G,seed=1)

#%% dwave SimulatedAnnealingSampler
import networkx as nx
import matplotlib.pyplot as plt
from dwave.system import DWaveSampler, EmbeddingComposite
from dimod import BinaryQuadraticModel, SimulatedAnnealingSampler, BINARY
# import dwave.inspector

G = nx.erdos_renyi_graph(n=45, p=0.3)

# Formulate the Max-Cut BQM
bqm = BinaryQuadraticModel.empty(BINARY)
for i in G.nodes:
    bqm.add_variable(i)  # Linear terms (initially zero)
for i, j in G.edges:
    bqm.add_quadratic(i, j, 1)  # Quadratic term for each edge (weight=1)

# Adjust BQM for Max-Cut: minimize -sum_{(i,j) in E} (2*x_i*x_j - x_i - x_j)
for i, j in G.edges:
    bqm.quadratic[(i, j)] = 2  # Coefficient for x_i*x_j
    bqm.linear[i] -= 1         # Coefficient for -x_i
    bqm.linear[j] -= 1         # Coefficient for -x_j

sampler = SimulatedAnnealingSampler()
sampleset = sampler.sample(bqm, num_reads=1000)

best_solution = sampleset.first.sample
# energy = sampleset.first.energy
# print("Best solution:", best_solution)
print("Energy:", energy)

cut_edges = sum(1 for i, j in G.edges if best_solution[i] != best_solution[j])
print("Cut size:", cut_edges)

# dwave.inspector.show(sampleset)
#%% dwave benchmark
import os
import pickle
import networkx as nx
from dimod import BinaryQuadraticModel, SimulatedAnnealingSampler, BINARY

save_dir = "/home/Mengzhen/signproblem/result/maxcut_graph_benchmark/"
n_list = [135, 570, 1305]
num_graphs = 10

dwave_cut_results = {}

for n in n_list:
    cut_edges_list = []
    for i in range(num_graphs):
        # load graph
        graph_filename = os.path.join(save_dir, f"maxcut_graph_n{n}_idx{i}.pkl")
        with open(graph_filename, "rb") as f:
            G = pickle.load(f)

        # BQM
        bqm = BinaryQuadraticModel.empty(BINARY)
        for node in G.nodes:
            bqm.add_variable(node)
        for u, v in G.edges:
            bqm.add_quadratic(u, v, 2)
            bqm.linear[u] -= 1
            bqm.linear[v] -= 1

        # dwave
        sampler = SimulatedAnnealingSampler()
        sampleset = sampler.sample(bqm, num_reads=5,num_sweeps=1000)
        best_solution = sampleset.first.sample
        # energy = sampleset.first.energy
        cut_edges = sum(1 for u, v in G.edges if best_solution[u] != best_solution[v])
        cut_edges_list.append(cut_edges)
        
        print(f"n={n}, graph {i+1}/{num_graphs}, cut_edges={cut_edges}")

    dwave_cut_results[n] = cut_edges_list

# save
# with open("home/Mengzhen/signproblem/result/maxcut_benchmark_results/maxcut_dwave_cut_edges.pkl", "wb") as f:
#     pickle.dump(dwave_cut_results, f)






