# -*- coding: utf-8 -*-
"""
Created on Mon Jul 25 11:32:16 2022

@author: chick
"""
import numpy as np
import tensorcircuit as tc
from tensorcircuit.applications.vqes import VQNHE, JointSchedule
from qiskit_nature.drivers import UnitsType, Molecule
from qiskit_nature.drivers.second_quantization import (
    ElectronicStructureDriverType,
    ElectronicStructureMoleculeDriver,
)
from qiskit_nature.problems.second_quantization import ElectronicStructureProblem
from qiskit_nature.converters.second_quantization import QubitConverter
from qiskit_nature.mappers.second_quantization import JordanWignerMapper
from qiskit_nature.transformers.second_quantization.electronic import FreezeCoreTransformer, ActiveSpaceTransformer
from qiskit.aqua.operators import WeightedPauliOperator
from qiskit.quantum_info import Pauli, state_fidelity
import matplotlib.pyplot as plt
# from scipy.linalg import expm
from scipy.sparse.linalg import expm
from scipy import sparse
from scipy.optimize import minimize
import tensorflow as tf
import warnings
from functools import partial
# from keras.utils import plot_model
warnings.simplefilter(action='ignore', category=FutureWarning)
tc.set_backend("tensorflow")
tc.set_dtype("complex128")
def str2WeightedPaulis(s):
	s = s.strip()
	IXYZ = ['I', 'X', 'Y', 'Z']
	prev_idx = 0
	coefs = []
	paulis = []
	is_coef = True
	for idx, c in enumerate(s + '+'):
		if idx == 0: continue
		if is_coef and c in IXYZ:
			coef = complex(s[prev_idx : idx].replace('i', 'j'))
			coefs.append(coef)
			is_coef = False
			prev_idx = idx
		if not is_coef and c in ['+', '-']:
			label = s[prev_idx : idx]
			paulis.append(Pauli(label))
			is_coef = True
			prev_idx = idx
	return WeightedPauliOperator([[c, p] for (c,p) in zip(coefs, paulis)])
dtype=np.complex128
X = np.array([[0, 1.0], [1.0, 0]], dtype=dtype)
Y = np.array([[0, -1j], [1j, 0]], dtype=dtype)
Z = np.array([[1, 0], [0, -1]], dtype=dtype)
I = np.array([[1, 0], [0, 1]], dtype=dtype)
             
def tran(tin):
    if tin=='I':
        return '0'
    if tin=='X':
        return '1'
    if tin=='Y':
        return '2'
    if tin=='Z':
        return '3'
    else:
        return tin
def Fedtest(ex,GS):
    SS=[]
    for x in GS:
        SS.append(state_fidelity(ex,w[:,x]))
    SS=np.array(SS)
    return SS
def mykron(ma, mb, *list):
    """
    :param ma: matrix a
    :param mb: matrix b
    :param *List: a set of matrices
    :return:  kron(ma,mb,list[0],....,list[n-1])
    """
    # k1=tran(ma).copy()
    # k2=tran(mb).copy()
    out = np.kron(ma,mb)
    if len(list) != 0:
        # print(out)
        out = mykron(out, *list)
    return out
def lshift(s,n):
    return s[n:]+s[:n]
def J1J2(na,nb,J1,J2):
    Sl=[]
    Hl=[]
    Sb=[['X','X'],['Y','Y'],['Z','Z']]
    # 0  1  2  3
    # 4  5  6  7
    # 8  9 10 11
    #12 13 14 15
    #J1 periodic
    edge=[]
    edges=[]
    n=na*nb
    for i in range(na):
        for j in range(nb-1):
            a=i*nb+j
            b=i*nb+np.mod(j+1,nb)
            if a!=b:
                edge.append([a,b])
    for i in range(na-1):
        for j in range(nb):
            a=i*nb+j
            b=np.mod((i+1),na)*nb+j
            if a!=b:
                edge.append([a,b])
            
    # for i in range(n):
    for i in edge:
        edges.append(i)
        for j in Sb:
            init=list('I'*n)
            tmp=[]
            # a=np.mod(i,n)
            # b=np.mod(i+1,n)
            a=i[0]
            b=i[1]
            init[a]=j[0]
            init[b]=j[1]
            Sl.append(str(J1)+''.join(init))
            for k in list(init):
                tmp.append(tran(k))
            Hl.append([J1,tmp])
    #J2 periodic
    edge=[]
    n=na*nb
    for i in range(na):
        for j in range(nb-2):
            a=i*nb+j
            b=i*nb+np.mod(j+2,nb)
            if a!=b and [b,a] not in edge:
                edge.append([a,b])
    
    for i in range(na-2):
        for j in range(nb):
            a=i*nb+j
            b=np.mod((i+2),na)*nb+j
            if a!=b and [b,a] not in edge:
                edge.append([a,b])
            
    for i in edge:
        edges.append(i)
        for j in Sb:
            init=list('I'*n)
            # a=np.mod(i,n)
            # b=np.mod(i+2,n)
            a=i[0]
            b=i[1]
            init[a]=j[0]
            init[b]=j[1]
            Sl.append(str(J2)+''.join(init))
            
    a='1'+'I'*n
    H=0*str2WeightedPaulis(a).to_opflow().to_spmatrix()
    Hy=0*str2WeightedPaulis(a).to_opflow().to_spmatrix()
    Hx=0*str2WeightedPaulis(a).to_opflow().to_spmatrix()
    for i in Sl:
        H+=str2WeightedPaulis(i).to_opflow().to_spmatrix()
        if 'X' in list(i):
            Hx+=str2WeightedPaulis(i).to_opflow().to_spmatrix()
        if 'Y' in list(i):
            Hy+=str2WeightedPaulis(i).to_opflow().to_spmatrix()
        # else:
            # H+=str2WeightedPaulis(i).to_opflow().to_spmatrix()
    return H,edges,Hy,Hx
        
def dtheta(params,H):
    N=np.size(params)
    A=np.zeros([N,N],dtype=np.complex128)
    C=np.zeros(N,dtype=np.complex128)
    dpdt=[]
    cp=1/np.sqrt(2)
    a=np.pi/2
    phi=E(params)
    for i in range(N):
        ptmp1=params.copy().reshape(-1)
        ptmp2=params.copy().reshape(-1)
        ptmp1[i]+=a
        ptmp2[i]-=a    
        dp=cp*(E(ptmp1.reshape(params.shape))-E(ptmp2.reshape(params.shape)))
        dpdt.append(dp)
    for i in range(N):
        for j in range(N):
            # phi=Lv(params,wavefunction)
            A[i,j]=(dpdt[i].conj().dot(dpdt[j])).real#+dpdt[i].conj().dot(phi)*dpdt[j].conj().dot(phi)
    for i in range(N):
        # phi=Lv(params,wavefunction)
        C[i]=(dpdt[i].conj().dot(H.dot(phi))).real
    dx=np.linalg.pinv(A.real).dot(-C)
    return dx.real

def commutator(A,B):
    return A.dot(B)-B.dot(A)

def anticommutator(A,B):
    return A.dot(B)+B.dot(A)

def convert_sparse_matrix_to_sparse_tensor(X):
    coo = X.tocoo()
    indices = np.mat([coo.row, coo.col]).transpose()
    return tf.SparseTensor(indices, coo.data, coo.shape)

def Mtheta(theta):
    M=tc.Circuit(nqu)
    j=0
    for i in range(nqu):
        M.rx(i,theta=theta[j])
        j+=1
    for i in range(nqu):
        M.ry(i,theta=theta[j]) 
        j+=1
    return M.matrix().numpy()

def E(theta):
    u=cir(theta).state()
    return u.numpy()

def EN(v,H):
    # v=E(theta)
    return (v.conj().dot(H.dot(v))).real
# def sexpm(H):
#     I=H.copy()
#     I[I!=0]=0
#     return I-H+0.5*H.dot(H)
def cost(theta,H):
    v=E(theta)
    return EN(v,H)
    # return 1-state_fidelity(v, w[:,GS])

# def mS(theta):
#     u=E(theta)
#     v=w[:,GS].reshape(-1)
#     wh=v.conj()*v
#     u=wh*u
#     u/=np.sqrt(u.conj().dot(u))
#     return state_fidelity(u, w[:,GS])

def mS(theta):
    u=E(theta)
    v=w[:,GS].reshape(-1)
    wh=np.sqrt(v.conj()*v)
    u=wh*u
    u/=np.sqrt(u.conj().dot(u))
    return state_fidelity(u, w[:,GS])

def mA(u):
    v=w[:,GS].reshape(-1)
    wh=np.sqrt(v.conj()*v)
    u=wh*u
    u/=np.sqrt(u.conj().dot(u))
    return state_fidelity(u, w[:,GS])

def eS(w,H):
    wh=abs(w.reshape(-1))
    u=np.ones(len(wh))
    u=w.reshape(-1)/wh*u
    u/=np.sqrt(u.conj().dot(u))
    return u.conj().dot(H.dot(u))

def S(theta):
    u=E(theta)
    Hp=H.copy()
    I=H*0
    I.setdiag(1)
    Hp[Hp<0]=0
    Hp.setdiag(0)
    
    Hn=H.copy()
    Hn[Hn>0]=0
    Hn.setdiag(H.diagonal())
    Hb=Hn-Hp
    eHb=expm(-Hb)
    eH=expm(-H)
    eHb=I-0.1*Hb+0.01*Hb.dot(Hb)
    eH=I-0.1*H+0.01*H.dot(H)
    # return Hp
    return ((u.conj().dot(eHb.dot(u))-u.conj().dot(eH.dot(u)))
            /u.conj().dot(eH.dot(u))).real
    # w=w.reshape(-1)
    # select=abs(w)>1e-3maxiter=100
    # return min(np.sign(u[select]).dot(np.sign(w[select]))
    
#%% Sign Test
def creatHd(n,edges):
    Hd=[]
    for i in range(nqu):
        ls=['I']*n
        ls[i]='Y'
        ls='1'+''.join(ls)
        Hd.append(str2WeightedPaulis(ls).to_opflow().to_spmatrix())
    return Hd

def initial_param(t, theta, a):
    v=E(theta)
    sf.append(EN(v,H))
    # maxiter=1
    # if di!=0:
    #     for i in range(maxiter):
    #         # Htmp=H.copy()
    #         theta+=dtheta(theta,H).reshape(theta.shape)*0.5
    #         v=E(theta)
    #         print(mS(theta),state_fidelity(E(theta), w[:,GS]))#(w[:,GS],E(theta)))
    #         print(EN(v,H))
    #         sf.append(EN(v,H))
    nsi.append(mS(theta))
    print('VITE done')
    return {"q": tf.Variable(theta)}
# histn=0
def initial_VITE(t, theta, a):
    v=E(theta)
    sf.append(EN(v,H))
    maxiter=300
    tmpn=[]
    for i in range(maxiter):
        # Htmp=H.copy()
        theta+=dtheta(theta,H).reshape(theta.shape)*0.3
        v=E(theta)
        tmpn.append(mS(theta))
        print(tmpn[-1])#(w[:,GS],E(theta)))
        sf.append(EN(v,H))
    nsi.append(mS(theta))
    print('VITE done')
    return theta,tmpn
# d=[2,2,3,1]
# deep=list(range(1,4))
d=[2,2,2,0]
NSI=[]
na=6
nb=1
J1=1
J2=0.6
# J.append(J2)
H,edges,Hy,Hx=J1J2(na,nb,J1,J2)

# H2=H.dot(H)
# Hb=S(H)
nqu=na*nb
Hd=creatHd(nqu,edges)
# Hx=str2WeightedPaulis('1'+'X'*nqu).to_opflow().to_spmatrix()
u,w=sparse.linalg.eigs(H,k=3,which='SR')
GS=np.where(abs(u-min(u))<1e-5)[0]
wh=abs(w[:,GS].reshape(-1))
wh/=np.sqrt(wh.conj().dot(wh))
# GN.append(state_fidelity(wh,w[:,GS]))
# continue
h=convert_sparse_matrix_to_sparse_tensor(H)
epoch=1
Eny=[]
sf=[]
nsi=[]
C=[]
Q=[]
vqeinstance = VQNHE(
nqu,
h,
# {"width":2, "stddev": 0.01, "choose": "complex-rbm"},  # model parameter
{"d": d, "choose": "complex"},  # model parameter
# {"depth": 5, "width": 3, "choose": "real"},  # model parameter
{"filled_qubit": list(range(nqu)),"edge": edges, "stddev": 0.01,"channel":1 , "epochs":epoch, "choose": "hea"},  # circuit parameter
shortcut=True,  # enable shortcut for full Hamiltonian matrix evaluation
)
cir=vqeinstance.circuit
# theta=0.1*np.array(list(range(na*nb))).reshape([1,na*nb,1])
t=nqu+len(edges)
# for i in range(nqu):
#     for j in range(nqu):
#         dif=j-i
#         if dif!=0 and abs(dif)<4:
#             t+=1
cw=[]
for iII in range(50):
    theta=(np.random.rand(t)-0.5)*2*np.pi
    # theta=np.ones(2**nqu)+np.random.rand(2**nqu)*0.001
    # theta/=np.sqrt(theta.conj().dot(theta))
    # theta=A.x.copy()
    # initial_param(t, theta, 1)
    
    rs1 = vqeinstance.multi_training(
        tries=1,  # 10
        maxiter=300,  # 10000
        threshold=0,
        # optq=JointSchedule(200, 0.01, 800, 0.002, 800),
        # optc=JointSchedule(300, 0.03, 400, 0.01, 4000),
        onlyq=0,
        debug=500,
        qon=300,
        initialization_func=partial(initial_param, theta=theta, a=nqu)
    )
    # Eny.append((min(np.array(rs1[0]['history']))-min(u)).real)
    cw.append([mS(rs1[0]['circuit_weights'])])
    # nsi.append((mA(rs1[0]['circuit_weights'])))
    # if min(Eny)<1e-5:
    #     break
    # v=np.array(rs1[0]['cgrad'])[-1]
    # Y=rs1[0]['quantum_energy']
    # Q=np.array(rs1[0]['qgrad'])
    # C.append(np.array(rs1[0]['cgrad']))
    print(iII,cw[-1])
    if cw[-1]==max(cw):
        Q=np.array(rs1[0]['qgrad'])
    # nsi=[]
# cw=np.sort(np.array(cw).reshape(-1))
np.savetxt('/home/kesson/1D/Sign_Test/VQNHE',cw) 

# nsi=[]
# for iII in range(50):
#     theta=(np.random.rand(t)-0.5)*2*np.pi
#     theta,tmpn=initial_VITE(t, theta, 1)
#     if nsi[-1]==max(nsi):
#         histn=tmpn.copy()
#     # cw.append()
#     np.savetxt('/home/kesson/1D/Sign_Test/VITE',nsi) 

cw1=[]
for iII in range(50):
    theta=(np.random.rand(t)-0.5)*2*np.pi
    
    rs1 = vqeinstance.multi_training(
        tries=1,  # 10
        maxiter=300,  # 10000
        threshold=0,
        # optq=JointSchedule(200, 0.01, 800, 0.002, 800),
        # optc=JointSchedule(300, 0.03, 400, 0.01, 4000),
        onlyq=300,
        debug=500,
        qon=0,
        initialization_func=partial(initial_param, theta=theta, a=nqu)
    )
    # Eny.append((min(np.array(rs1[0]['history']))-min(u)).real)
    cw1.append([mS(rs1[0]['circuit_weights'])])
    # nsi.append((mA(rs1[0]['circuit_weights'])))
    # if min(Eny)<1e-5:
    #     break
    # v=np.array(rs1[0]['cgrad'])[-1]
    # Y=rs1[0]['quantum_energy']
    # Q=np.array(rs1[0]['qgrad'])
    # C.append(np.array(rs1[0]['cgrad']))
    print(iII,cw1[-1])
    if cw1[-1]==max(cw1):
        Q=np.array(rs1[0]['qgrad'])
    # nsi=[]
# cw=np.sort(np.array(cw).reshape(-1))
np.savetxt('/home/kesson/1D/Sign_Test/VQE',cw1)
#%%
qq=np.loadtxt('/home/kesson/1D/Sign_Test/VQNHE')
q=np.loadtxt('/home/kesson/1D/Sign_Test/VQE')
histn=np.loadtxt('/home/kesson/1D/Sign_Test/VITE')
plt.scatter(list(range(len(qq))),1-np.sort(qq),label='VQNHE',c='r',alpha=0.7)
plt.scatter(list(range(len(histn))),1-np.sort(histn),label='VITE',c='g',marker='*',alpha=0.7)
plt.scatter(list(range(len(q))),1-np.sort(q),label='VQE',c='b',marker='^',alpha=0.7)
plt.yscale('log')
plt.ylim([1e-2,2])
plt.legend(fontsize=15)
plt.xticks(fontsize=15)
plt.yticks(fontsize=15)
# plt.title('Sign')
plt.xlabel('Sorted Initial State', fontsize=20)
plt.ylabel('$1-F_s(\psi)$', fontsize=20)
# qq=np.loadtxt('/home/kesson/1D/Sign_Test/qq')
# q=np.loadtxt('/home/kesson/1D/Sign_Test/q')
# histn=np.loadtxt('/home/kesson/1D/Sign_Test/histn')
# plt.plot(1-np.array(qq),label='VQNHE',c='r',linewidth=3)
# plt.plot(1-np.array(histn),label='VITE',c='g',linewidth=3)
# plt.plot(1-np.array(q),label='VQE',c='b',linewidth=3)
# plt.yscale('log')
# plt.ylim([1e-2,1])
# plt.legend(fontsize=15)
# plt.xticks(fontsize=15)
# plt.yticks(fontsize=15)
# # plt.title('Sign')
# plt.xlabel('time steps', fontsize=20)
# plt.ylabel('$1-F_s(\psi)$', fontsize=20)
#%% Sign Sampling
def creatHd(n,edges):
    Hd=[]
    for i in range(nqu):
        ls=['I']*n
        ls[i]='Y'
        ls='1'+''.join(ls)
        Hd.append(str2WeightedPaulis(ls).to_opflow().to_spmatrix())
    return Hd

def initial_param(t, theta, a):
    v=E(theta)
    sf.append(EN(v,H))
    # maxiter=1
    # if di!=0:
    #     for i in range(maxiter):
    #         # Htmp=H.copy()
    #         theta+=dtheta(theta,H).reshape(theta.shape)*0.5
    #         v=E(theta)
    #         print(mS(theta),state_fidelity(E(theta), w[:,GS]))#(w[:,GS],E(theta)))
    #         print(EN(v,H))
    #         sf.append(EN(v,H))
    # nsi.append(mS(theta))
    print('VITE done')
    return {"q": tf.Variable(theta)}
# histn=0
# d=[2,2,3,1]
# deep=list(range(1,4))
d=[2,2,2,0]
NSI=[]
na=6
nb=1
J1=1
J2=0.6
# J.append(J2)
H,edges,Hy,Hx=J1J2(na,nb,J1,J2)

# H2=H.dot(H)
# Hb=S(H)
nqu=na*nb
Hd=creatHd(nqu,edges)
# Hx=str2WeightedPaulis('1'+'X'*nqu).to_opflow().to_spmatrix()
u,w=sparse.linalg.eigs(H,k=3,which='SR')
GS=np.where(abs(u-min(u))<1e-5)[0]
wh=abs(w[:,GS].reshape(-1))
wh/=np.sqrt(wh.conj().dot(wh))
# GN.append(state_fidelity(wh,w[:,GS]))
# continue
h=convert_sparse_matrix_to_sparse_tensor(H)
epoch=1
Eny=[]
sf=[]
nsi=[]
C=[]
Q=[]
vqeinstance = VQNHE(
nqu,
h,
# {"width":2, "stddev": 0.01, "choose": "complex-rbm"},  # model parameter
{"d": d, "choose": "complex"},  # model parameter
# {"depth": 5, "width": 3, "choose": "real"},  # model parameter
{"filled_qubit": list(range(nqu)),"edge": edges, "stddev": 0.01,"channel":1 , "epochs":epoch, "choose": "hea"},  # circuit parameter
shortcut=True,  # enable shortcut for full Hamiltonian matrix evaluation
)
cir=vqeinstance.circuit
# theta=0.1*np.array(list(range(na*nb))).reshape([1,na*nb,1])
t=nqu+len(edges)
cw=[]
# phi=[]
for iII in range(50):
    theta=(np.random.rand(t)-0.5)*2*np.pi
    # theta=np.ones(2**nqu)+np.random.rand(2**nqu)*0.001
    # theta/=np.sqrt(theta.conj().dot(theta))
    # theta=A.x.copy()
    # initial_param(t, theta, 1)
    
    rs1 = vqeinstance.multi_training(
        tries=1,  # 10
        maxiter=1000,  # 10000
        threshold=0,
        # optq=JointSchedule(200, 0.01, 800, 0.002, 800),
        # optc=JointSchedule(300, 0.03, 400, 0.01, 4000),
        onlyq=0,
        debug=500,
        qon=300,
        initialization_func=partial(initial_param, theta=theta, a=nqu)
    )
    # Eny.append((min(np.array(rs1[0]['history']))-min(u)).real)
    e=min(np.array(rs1[0]['history']))
    # phi=rs1[0]['model_weights']
    # cw.append(mS(rs1[0]['circuit_weights']))
    # nsi.append((rs1[0]['circuit_weights']))
    print(iII)
    if abs(e-u[0])<0.1:
        # phi.append(rs1[0]['model_weights'])
        cw.append(mS(rs1[0]['circuit_weights']))
        nsi.append((rs1[0]['circuit_weights']))
        print(cw[-1])
    
# theta=nsi[-1]
# Eny=[]
# cw=[]
# nsi=[]
# for iII in range(50):
#     a=theta+(np.random.rand(t)-0.5)*0.3
#     rs1 = vqeinstance.multi_training(
#         tries=1,  # 10
#         maxiter=2000,  # 10000
#         threshold=0,
#         # optq=JointSchedule(200, 0.01, 800, 0.002, 800),
#         # optc=JointSchedule(300, 0.03, 400, 0.01, 4000),
#         onlyq=0,
#         debug=500,
#         qon=0,
#         initialization_func=partial(initial_param, theta=a, a=nqu)
#     )
#     Eny.append((min(np.array(rs1[0]['history']))-e))
#     cw.append(mS(rs1[0]['circuit_weights']))
#     nsi.append(state_fidelity(E(a), E(theta)))
#     print(iII,Eny[-1],cw[-1],nsi[-1])
    
#     # if cw[-1]>0.99:
#     #     break
    np.savetxt('/home/kesson/1D/Sign_Test/Sampling_sf',cw)
    np.savetxt('/home/kesson/1D/Sign_Test/Sampling_f',nsi)
#     np.savetxt('/home/kesson/1D/Sign_Test/Sampling',Eny)
#%%
# qq=np.loadtxt('/home/kesson/1D/Sign_Test/Sampling')
s=np.argsort(cw)
gs=w[:,0]
gs[gs.conj()*gs<1e-1]=0
sgs=np.sign(gs)
sgs/=np.sqrt(sgs.dot(sgs))
# for i in s:
plt.bar(list(range(2**6)),w[:,0],label='Exact',alpha=0.8)
plt.bar(list(range(2**6)),E(nsi[s[-2]]),label='Case 1',alpha=0.8)
plt.bar(list(range(2**6)),-E(nsi[s[-1]]),label='Case 2',alpha=0.8)
# plt.yscale('log')
# plt.ylim([1e-2,2])
plt.legend(fontsize=15)
plt.xticks(fontsize=15)
plt.yticks(fontsize=15)
# # plt.title('Sign')
plt.xlabel('Computing Basis', fontsize=20)
plt.ylabel('Probability Amplitude', fontsize=20)
#%% Architecture Test
# Ene=[]
# J=[]
# SF=[]
# NSI=[]
# GN=[]
def creatHd(n,edges):
    Hd=[]
    for i in range(nqu):
        ls=['I']*n
        ls[i]='Y'
        ls='1'+''.join(ls)
        Hd.append(str2WeightedPaulis(ls).to_opflow().to_spmatrix())
    return Hd

def initial_param(t, theta, a):
    # v=E(theta)
    # sf.append(EN(v,H))
    # maxiter=1
    # if di!=0:
    #     for i in range(maxiter):
    #         # Htmp=H.copy()
    #         theta+=dtheta(theta,H).reshape(theta.shape)*0.5
    #         v=E(theta)
    #         print(mS(theta),state_fidelity(E(theta), w[:,GS]))#(w[:,GS],E(theta)))
    #         print(EN(v,H))
    #         sf.append(EN(v,H))
    # nsi.append(mS(theta))
    # print('VITE done')
    return {"q": tf.Variable(theta)}
    
# d=[2,2,3,1]
# deep=list(range(1,4))
deep=[3]
for di in deep:
    d=[2,2,di,di]
    NSI=[]
    # Ene=[]
    # for iii in range(50,100,3):
    for iii in [75]:
        na=6
        nb=1
        J1=1
        J2=iii/100
        # J.append(J2)
        H,edges,Hy,Hx=J1J2(na,nb,J1,J2)
        
        # H2=H.dot(H)
        # Hb=S(H)
        nqu=na*nb
        Hd=creatHd(nqu,edges)
        # Hx=str2WeightedPaulis('1'+'X'*nqu).to_opflow().to_spmatrix()
        u,w=sparse.linalg.eigs(H,k=3,which='SR')
        GS=np.where(abs(u-min(u))<1e-5)[0]
        wh=abs(w[:,GS].reshape(-1))
        wh/=np.sqrt(wh.conj().dot(wh))
        # GN.append(state_fidelity(wh,w[:,GS]))
        # continue
        h=convert_sparse_matrix_to_sparse_tensor(H)
        epoch=1
        Eny=[]
        sf=[]
        nsi=[]
        C=[]
        Q=[]
        vqeinstance = VQNHE(
        nqu,
        h,
        # {"width":2, "stddev": 0.01, "choose": "complex-rbm"},  # model parameter
        {"d": d, "choose": "complex"},  # model parameter
        # {"depth": 3, "width": di, "choose": "real"},  # model parameter
        {"filled_qubit": list(range(nqu)),"edge": edges, "stddev": 0.01,"channel":1 , "epochs":epoch, "choose": "hea"},  # circuit parameter
        shortcut=True,  # enable shortcut for full Hamiltonian matrix evaluation
        )
        cir=vqeinstance.circuit
        # theta=0.1*np.array(list(range(na*nb))).reshape([1,na*nb,1])
        t=(nqu+len(edges))*epoch
        # for i in range(nqu):
        #     for j in range(nqu):
        #         dif=j-i
        #         if dif!=0 and abs(dif)<4:
        #             t+=1
        print('na:',na,'iii',iii)
        
        for iII in range(100):
            theta=(np.random.rand(t)-0.5)*2*np.pi
            # theta=np.ones(2**nqu)+np.random.rand(2**nqu)*0.001
            # theta/=np.sqrt(theta.conj().dot(theta))
            # theta=A.x.copy()
            # initial_param(t, theta, 1)
            
            rs1 = vqeinstance.multi_training(
                tries=1,  # 10
                maxiter=2000,  # 10000
                threshold=1e-12,
                # optq=JointSchedule(200, 0.01, 800, 0.002, 800),
                # optc=JointSchedule(300, 0.03, 400, 0.01, 4000),
                onlyq=0,
                debug=500,
                qon=300,
                initialization_func=partial(initial_param, theta=theta, a=nqu)
            )
            Eny.append((min(np.array(rs1[0]['history']))-min(u)).real)
            # print(mS(rs1[0]['circuit_weights']))
            nsi.append((mS(rs1[0]['circuit_weights'])))
            # f2 = tf.reshape(vqeinstance.model(vqeinstance.base), [-1])
            # f2 -= tf.math.reduce_mean(f2)
            # f2 = tf.abs(
            #     tf.cast(tf.math.real(f2),
            #         tf.complex128,
            #     )
            # )
            # f2 = tf.exp(f2)
            # nsi.append(mA(np.sign(E(theta))))
            # if min(Eny)<1e-5:
            #     break
            # v=np.array(rs1[0]['cgrad'])[-1]
            # Y=rs1[0]['quantum_energy']
            # Q.append(np.array(rs1[0]['qgrad']))
            # C.append(np.array(rs1[0]['cgrad']))
            print(iII,Eny[-1],nsi[-1])
       # mini=np.argsort(Eny)[0]
        # Ene.append(min(Eny))   
       # NSI.append(nsi)
        # SF.append(sf)
        # Ene.append(Eny)
        # print(np.mean(Eny))
        # plt.plot(NSI[2],Ene[2])
    np.savetxt('/home/kesson/1D/J12_6/SJ0'+str(na)+str(di)+'E',Eny) 
    np.savetxt('/home/kesson/1D/J12_6/SJ0'+str(na)+str(di)+'S',nsi) 
#%% LiH VQE
# from qiskit_nature.algorithms import GroundStateEigensolver
# from qiskit.algorithms.minimum_eigen_solvers import NumPyMinimumEigensolver
# numpy_solver = NumPyMinimumEigensolver()
# def get_qubit_op(dist):
#     molecule = Molecule(
#         geometry=[["Li", [0, 0, .0]], ["H", [0, .0, dist]]],
#         charge=0, multiplicity=1
#     )
    
#     driver = ElectronicStructureMoleculeDriver(
#         molecule, basis="sto3g", driver_type=ElectronicStructureDriverType.PYSCF,
#     )
#     es_problem = ElectronicStructureProblem(driver, [ActiveSpaceTransformer(2,3)])#[FreezeCoreTransformer([-3,-2])])
#     second_q_op = es_problem.second_q_ops()
#     qubit_converter = QubitConverter(mapper=JordanWignerMapper())
#     calc = GroundStateEigensolver(qubit_converter, numpy_solver)
#     qubitOp = qubit_converter.convert(second_q_op[0])
#     res=calc.solve(es_problem)
#     Egs.append(res.total_energies)
#     Ehf.append(res.hartree_fock_energy)
#     return qubitOp, es_problem.num_spin_orbitals, res.extracted_transformer_energy+res.nuclear_repulsion_energy

# def initial_param(t, theta, a):
#     v=E(theta)
#     sf.append(EN(v,H))
#     # maxiter=1
#     # if di!=0:
#     #     for i in range(maxiter):
#     #         # Htmp=H.copy()
#     #         theta+=dtheta(theta,H).reshape(theta.shape)*0.5
#     #         v=E(theta)
#     #         print(mS(theta),state_fidelity(E(theta), w[:,GS]))#(w[:,GS],E(theta)))
#     #         print(EN(v,H))
#     #         sf.append(EN(v,H))
#     nsi.append(mS(theta))
#     print('VITE done')
#     return {"q": tf.Variable(theta)}
#     # return v
     
# deep=[1,2,3]
# shift=[]
# for di in deep:
#     d=[2,2,3,3]
#     NSI=[]
#     # Ene=[]
#     iters=[]
#     # for iii in [1.5]:
#     Ex=[]
#     Egs=[]
#     Ehf=[]
#     for iii in np.arange(0.5,4,0.2):
#         # H, qubits=molecule(symbols, iii)
#         qubitOp, nqu, tmp=get_qubit_op(iii)
#         shift.append(tmp)
#         H=qubitOp.to_spmatrix()
#         u,w=sparse.linalg.eigs(H,k=2,which='SR')
#         GS=np.where(abs(u-min(u))<1e-5)[0]
#         wh=abs(w[:,GS].reshape(-1))
#         wh/=np.sqrt(wh.conj().dot(wh))
#         h=convert_sparse_matrix_to_sparse_tensor(H)
#         epoch=di
#         Eny=[]
#         sf=[]
#         nsi=[]
#         C=[]
#         Q=[]
#         fq=list(range(nqu))
#         vqeinstance = VQNHE(
#         nqu,
#         h,
#         # {"width":2, "stddev": 0.01, "choose": "complex-rbm"},  # model parameter
#         {"d": d, "choose": "complex"},  # model parameter
#         # {"depth": 5, "width": 3, "choose": "real"},  # model parameter
#         {"filled_qubit": fq, "stddev": 0.01,"channel":1 , "epochs":epoch, "choose": "hea2"},  # circuit parameter
#         shortcut=True,  # enable shortcut for full Hamiltonian matrix evaluation
#         )
#         cir=vqeinstance.circuit
#         t=2*nqu*epoch+2*nqu
#         # t=len(edges)
#         # t=2*nqu*epoch
#         print('Qubit:',nqu,'iii',iii)
        
#         for iII in range(10):
#             theta=(np.random.rand(t*epoch)-0.5)*2*np.pi
#             rs1 = vqeinstance.multi_training(
#                 tries=1,  # 10
#                 maxiter=300,  # 10000
#                 threshold=0,
#                 onlyq=300,
#                 debug=100,
#                 qon=0,
#                 initialization_func=partial(initial_param, theta=theta, a=nqu)
#             )
#             Eny.append((min(np.array(rs1[0]['history']))).real)
#             # iters.append(rs1[0]['iterations'])
#             # print(mS(rs1[0]['circuit_weights']))
#             # nsi.append((mA(rs1[0]['circuit_weights'])))
#             # if min(Eny)<1e-5:
#             #     break
#             # v=np.array(rs1[0]['cgrad'])[-1]
#             # Y=rs1[0]['quantum_energy']
#             # Q.append(np.array(rs1[0]['qgrad']))
#             # C.append(np.array(rs1[0]['cgrad']))
#         Ex.append(min(Eny))
#         print(Ex[-1])
#     np.savetxt('/home/kesson/1D/LiH/LiHV'+str(di)+'E',Ex+shift)
# np.savetxt('/home/kesson/1D/LiH/LiH_Egs',Egs+shift)
# np.savetxt('/home/kesson/1D/LiH/LiH_Ehf',Ehf+shift)
#%% LiH sign
# from pennylane import qchem
# from pennylane.pauli import pauli_word_to_string
# import numpy as np
# -7.774848 NN -7.77327 CY -7.773919 YY -7.773877 NN2 -7.7736189
from qiskit_nature.algorithms import GroundStateEigensolver
from qiskit.algorithms.minimum_eigen_solvers import NumPyMinimumEigensolver
numpy_solver = NumPyMinimumEigensolver()
def get_qubit_op(dist):
    # pos=np.array([[-0.7396, -1.1953, .0],[0.7396, -1.1953, .0],[ 1.3620, .0, .0]
    #           ,[0.7396, 1.1953, .0],[-0.7396, 1.1953, .0], [-1.3620, .0, .0]])*dist
    pos=[[0,0,0,],[dist,0,0],[0,0,dist],[dist,0,dist]]
    molecule = Molecule(
    # geometry=[["C", [-0.7396, -1.1953, .0]], ["C", [0.7396, -1.1953, .0]],
    #           ["C", [ 1.3620, .0, .0]], ["C", [0.7396, 1.1953, .0]],
    #           ["C", [-0.7396, 1.1953, .0]], ["C", [-1.3620, .0, .0]],],
    #           # ["H", [1.1999, -2.1824, 0]], ["H", [-1.1999, 2.1824, 0]],
    #           # ["H", [1.1999, 2.1824, 0]], ["H", [-1.1999, -2.1824, 0]]],
    #     charge=0, multiplicity=1
    # )
    # geometry=[
    #           ["H", pos[0]], ["H", pos[1]],
    #           ["H", pos[2]], ["H", pos[3]],],#
    #           # ["H", pos[4]], ["H", pos[5]]],
    #     charge=0, multiplicity=1
    # )    
    geometry=[
              ["Li", pos[0]], ["H", pos[1]]],#
              # ["H", pos[4]], ["H", pos[5]]],
        charge=0, multiplicity=1
    )  
    driver = ElectronicStructureMoleculeDriver(
        molecule, basis="sto3g", driver_type=ElectronicStructureDriverType.PYSCF,
    )
    es_problem = ElectronicStructureProblem(driver, [ActiveSpaceTransformer(2,4)])#[FreezeCoreTransformer([-3,-2])])
    second_q_op = es_problem.second_q_ops()
    qubit_converter = QubitConverter(mapper=JordanWignerMapper())
    calc = GroundStateEigensolver(qubit_converter, numpy_solver)
    qubitOp = qubit_converter.convert(second_q_op[0])
    res=calc.solve(es_problem)
    Egs.append(res.total_energies)
    Ehf.append(res.hartree_fock_energy)
    return qubitOp, es_problem.num_spin_orbitals, res.extracted_transformer_energy+res.nuclear_repulsion_energy


def initial_param(t, theta, a):
    # maxiter=10
    # if di!=0:
    #     for i in range(maxiter):
    #         theta+=dtheta(theta,H).reshape(theta.shape)*0.3
    #         v=E(theta)
    #         print(mS(theta),state_fidelity(E(theta), w[:,GS]))#(w[:,GS],E(theta)))
    #         print(EN(v,H))
    #         sf.append(EN(v,H))
    return {"q": tf.Variable(theta)}
    # return v
     
deep=[2]
shift=[]
mw=[]
for di in deep:
    d=[1,1,1,1]
    NSI=[]
    # Ene=[]
    iters=[]
    Ex=[]
    Egs=[]
    Ehf=[]
    # for iii in np.arange(0.5,4,0.2):
    for iii in [2.5]:
        qubitOp, nqu, tmp=get_qubit_op(iii)
        shift.append(tmp)
        H=qubitOp.to_spmatrix()
        u,w=sparse.linalg.eigs(H,k=2,which='SR')
        GS=np.where(abs(u-min(u))<1e-5)[0]
        wh=abs(w[:,GS].reshape(-1))
        wh/=np.sqrt(wh.conj().dot(wh))
        h=convert_sparse_matrix_to_sparse_tensor(H)
        epoch=1
        Eny=[]
        sf=[]
        nsi=[]
        C=[]
        Q=[]
        fq=list(range(nqu))
        edges=[]
        for i in range(nqu-1):
            edges.append([i,(i+1)%nqu])
        # for i in range(nqu-1):
        #     edges.append([i,(i+2)%nqu])
        vqeinstance = VQNHE(
        nqu,
        h,
        # {"width":4, "stddev": 0.01, "choose": "complex-rbm"},  # model parameter
           {"d": d, "choose": "complex"},  # model parameter
        # {"depth": 10, "width": 2, "choose": "real"},  # model parameter
        {"filled_qubit": fq, "edge":edges, "stddev": 0.01,"channel":1 , "epochs":epoch, "choose": "hea"},  # circuit parameter
        shortcut=True,  # enable shortcut for full Hamiltonian matrix evaluation
        )
        cir=vqeinstance.circuit
        # t=2*nqu*epoch+2*nqu
        t=(len(edges)+nqu)*epoch
        # t=nqu*epoch
        print('Qubit:',nqu,'iii',iii)
        
        for iII in range(1):
            theta=(np.random.rand(t)-0.5)*np.pi*0
            rs1 = vqeinstance.multi_training(
                tries=1,  # 10
                maxiter=100,  # 10000
                threshold=0,
                onlyq=0,
                debug=100,
                qon=0,
                initialization_func=partial(initial_param, theta=theta, a=nqu)
            )
            Eny.append((min(np.array(rs1[0]['history']))).real)
        # # Ex.append(min(Eny))
        # # print(Ex[-1])
        #     Ex.append(mS(rs1[0]['circuit_weights']))
    # s=0
    # for i in np.array(rs1[0]['model_weights']):
    #     s+=len(i)
    # mw.append(s)
    np.savetxt('/home/kesson/1D/LiH/LiH_NN'+str(di)+'E',np.array(Eny)+np.array(shift)[0])
#%%J1-J2

def initial_param(t, theta, a):
    v=E(theta)
    sf.append(EN(v,H))
    nsi.append(mS(theta))
    print('VITE done')
    return {"q": tf.Variable(theta)}
     
# d=[2,2,3,1]
# deep=list(range(1,4))
# deep=[1,2,3]
deep=[10]
for di in deep:
    na=12
    d=[2,2,na,int(na/2)]
    NSI=[]
    # Ene=[]
    iters=[]
    for iii in [1.5]:
    # for iii in np.linspace(0.5,3,51):
        nb=1
        J1=1
        J2=0.6
        # J.append(J2)
        H,edges,Hy,Hx=J1J2(na,nb,J1,J2)
        nqu=na*nb
        # H, qubits=molecule(symbols, iii)
        # nqu=qubits
        # edges=[[0,2],[1,3],[4,1],[2,4],[3,5]]
        # edges=[]
        # for i in range(nqu-1):
        #     edges.append([i,(i+1)%nqu])
        # for i in range(nqu-2):
        #     edges.append([i,(i+2)%nqu])
            
        u,w=sparse.linalg.eigs(H,k=3,which='SR')
        GS=np.where(abs(u-min(u))<1e-5)[0]
        wh=abs(w[:,GS].reshape(-1))
        wh/=np.sqrt(wh.conj().dot(wh))
        h=convert_sparse_matrix_to_sparse_tensor(H)
        epoch=1
        Eny=[]
        sf=[]
        nsi=[]
        C=[]
        Q=[]
        fq=list(range(nqu))
        # fq=[]
        vqeinstance = VQNHE(
        nqu,
        h,
        {"width":int(na/2), "stddev": 0.01, "choose": "complex-rbm"},  # model parameter
        # {"d": d, "choose": "complex"},  # model parameter
        # {"depth": 5, "width": 3, "choose": "real"},  # model parameter
        {"filled_qubit": fq,"edge": edges, "stddev": 0.01,"channel":1 , "epochs":epoch, "choose": "hea"},  # circuit parameter
        shortcut=True,  # enable shortcut for full Hamiltonian matrix evaluation
        )
        cir=vqeinstance.circuit
        t=(nqu+len(edges))*epoch
        # t=len(edges)
        # t=2*nqu*epoch
        print('Qubit:',nqu,'iii',iii)
        
        for iII in range(1):
            theta=(np.random.rand(t)-0.5)*np.pi
            if di==0:
                theta*=0
           # theta=[]
            rs1 = vqeinstance.multi_training(
                tries=1,  # 10
                maxiter=3000,  # 10000
                threshold=0,
                # optq=JointSchedule(200, 0.01, 800, 0.002, 800),
                # optc=JointSchedule(300, 0.03, 400, 0.01, 4000),
                onlyq=0,
                debug=100,
                qon=di*10,
                initialization_func=partial(initial_param, theta=theta, a=nqu)
            )
            Eny.append((min(np.array(rs1[0]['history']))-min(u)).real)
            # iters.append(rs1[0]['iterations'])
            # print(mS(rs1[0]['circuit_weights']))
            # nsi.append((mA(rs1[0]['circuit_weights'])))
            # if min(Eny)<1e-5:
            #     break
            # v=np.array(rs1[0]['cgrad'])[-1]
            # Y=rs1[0]['quantum_energy']
            # Q.append(np.array(rs1[0]['qgrad']))
            # C.append(np.array(rs1[0]['cgrad']))
            print(Eny[-1])
    # np.savetxt('/home/kesson/1D/J12_'+str(na)+'/J12'+str(di)+'E',Eny)   # maxiter=30
#%% 9-Heisenberg Sign VQNHE
def initial_param(t, theta, a):
    v=E(theta)
    sf.append(EN(v,H))
    nsi.append(mS(theta))
    print('VITE done')
    return {"q": tf.Variable(theta)}

dist=[1,0.5,0.5,0.5]
d=dist[1:]
h=dist[0]
J=d*np.array(h)
na=3
nb=3
n=na*nb
edge=[]
perms=[]
for i in range(na):
    for j in range(nb-1):
        edge.append([i*nb+j,i*nb+np.mod(j+1,nb)])
for i in range(na-1):
    for j in range(nb):
        edge.append([i*nb+j,np.mod((i+1),na)*nb+j])
H2D=''
for i in range(n):
    # tmpX='+'+str(h)
    # tmpY='+'+str(h)
    tmpZ='+'+str(h)
    for j in range(n):
        if j==i:
            # tmpX+='X'
            # tmpY+='Y'
            tmpZ+='Z'
        else:
            # tmpX+='I'
            # tmpY+='I'
            tmpZ+='I'
    H2D=H2D+tmpZ
for i in edge:
    tmpX='-'+str(J[0])
    tmpY='-'+str(J[1])
    tmpZ='-'+str(J[2])
    for j in range(n):
        if j in i:
            tmpX+='X'
            tmpY+='Y'
            tmpZ+='Z'
        else:
            tmpX+='I'
            tmpY+='I'
            tmpZ+='I'
    H2D=H2D+tmpX+tmpY+tmpZ

H=str2WeightedPaulis(H2D).to_opflow().to_spmatrix()
deep=[0,3,6]
# deep=[0]
for di in deep:
    d=[2,2,3,3]
    NSI=[]
    # Ene=[]
    iters=[]
    u,w=sparse.linalg.eigs(H,k=3,which='SR')
    GS=np.where(abs(u-min(u))<1e-5)[0]
    wh=abs(w[:,GS].reshape(-1))
    wh/=np.sqrt(wh.conj().dot(wh))
    h=convert_sparse_matrix_to_sparse_tensor(H)
    epoch=1
    Eny=[]
    sf=[]
    nsi=[]
    C=[]
    Q=[]
    fq=list(range(n))
    # fq=[]
    vqeinstance = VQNHE(
    n,
    h,
    # {"width":2, "stddev": 0.01, "choose": "complex-rbm"},  # model parameter
    {"d": d, "choose": "complex"},  # model parameter
    # {"depth": 5, "width": 3, "choose": "real"},  # model parameter
    {"filled_qubit": fq,"edge": edge, "stddev": 0.01,"channel":1 , "epochs":epoch, "choose": "hea"},  # circuit parameter
    shortcut=True,  # enable shortcut for full Hamiltonian matrix evaluation
    )
    cir=vqeinstance.circuit
    t=(n+len(edge))*epoch
    # t=len(edges)
    # t=2*nqu*epoch
    # print('Qubit:',n,'iii',iii)
    
    for iII in range(50):
        theta=(np.random.rand(t*epoch)-0.5)*2*np.pi
        if di==0:
            theta*=0
       # theta=[]
        rs1 = vqeinstance.multi_training(
            tries=1,  # 10
            maxiter=2000,  # 10000
            threshold=1E-20,
            # optq=JointSchedule(200, 0.01, 800, 0.002, 800),
            # optc=JointSchedule(300, 0.03, 400, 0.01, 4000),
            onlyq=0,
            debug=100,
            qon=di*10,
            initialization_func=partial(initial_param, theta=theta, a=n)
        )
        Eny.append((min(np.array(rs1[0]['history']))-min(u)).real)
        print(Eny[-1])
        
    np.savetxt('/home/kesson/1D/Heisenberg/F_Heis'+str(n)+str(di)+'E',Eny)
#%% 9-Heisenberg VQE
def initial_param(t, theta, a):
    v=E(theta)
    sf.append(EN(v,H))
    nsi.append(mS(theta))
    print('VITE done')
    return {"q": tf.Variable(theta)}

dist=[1,0.5,0.5,0.5]
d=dist[1:]
h=dist[0]
J=d*np.array(h)
na=3
nb=3
n=na*nb
edge=[]
perms=[]
for i in range(na):
    for j in range(nb-1):
        edge.append([i*nb+j,i*nb+np.mod(j+1,nb)])
for i in range(na-1):
    for j in range(nb):
        edge.append([i*nb+j,np.mod((i+1),na)*nb+j])
H2D=''
for i in range(n):
    # tmpX='+'+str(h)
    # tmpY='+'+str(h)
    tmpZ='+'+str(h)
    for j in range(n):
        if j==i:
            # tmpX+='X'
            # tmpY+='Y'
            tmpZ+='Z'
        else:
            # tmpX+='I'
            # tmpY+='I'
            tmpZ+='I'
    H2D=H2D+tmpZ
for i in edge:
    tmpX='+'+str(J[0])
    tmpY='+'+str(J[1])
    tmpZ='+'+str(J[2])
    for j in range(n):
        if j in i:
            tmpX+='X'
            tmpY+='Y'
            tmpZ+='Z'
        else:
            tmpX+='I'
            tmpY+='I'
            tmpZ+='I'
    H2D=H2D+tmpX+tmpY+tmpZ

H=str2WeightedPaulis(H2D).to_opflow().to_spmatrix()
deep=[1,2,3,4,5]
for di in deep:
    d=[2,2,3,3]
    NSI=[]
    # Ene=[]
    iters=[]
    u,w=sparse.linalg.eigs(H,k=3,which='SR')
    GS=np.where(abs(u-min(u))<1e-5)[0]
    wh=abs(w[:,GS].reshape(-1))
    wh/=np.sqrt(wh.conj().dot(wh))
    h=convert_sparse_matrix_to_sparse_tensor(H)
    epoch=di
    Eny=[]
    sf=[]
    nsi=[]
    C=[]
    Q=[]
    fq=list(range(n))
    vqeinstance = VQNHE(
    n,
    h,
    # {"width":2, "stddev": 0.01, "choose": "complex-rbm"},  # model parameter
    {"d": d, "choose": "complex"},  # model parameter
    # {"depth": 5, "width": 3, "choose": "real"},  # model parameter
    {"filled_qubit": fq,"edge": edge, "stddev": 0.01,"channel":1 , "epochs":epoch, "choose": "hea2"},  # circuit parameter
    shortcut=True,  # enable shortcut for full Hamiltonian matrix evaluation
    )
    cir=vqeinstance.circuit
    t=2*n*epoch+2*n
    
    for iII in range(50):
        theta=(np.random.rand(t*epoch)-0.5)*2*np.pi
        rs1 = vqeinstance.multi_training(
            tries=1,  # 10
            maxiter=2000,  # 10000
            threshold=1E-20,
            # optq=JointSchedule(200, 0.01, 800, 0.002, 800),
            # optc=JointSchedule(300, 0.03, 400, 0.01, 4000),
            onlyq=2000,
            debug=100,
            qon=0,
            initialization_func=partial(initial_param, theta=theta, a=n)
        )
        Eny.append((min(np.array(rs1[0]['history']))-min(u)).real)
        print(Eny[-1])
        
    # np.savetxt('/home/kesson/1D/Heisenberg/Heis'+str(n)+str(di)+'V',Eny)
#%%
color=['r','g','b','purple','orange']
nqu=6
D=[1,2,3]
# for di in D:
#     Eny2=np.loadtxt('/home/kesson/1D/J12_6/SJ0'+str(nqu)+str(di)+'E')
#     NS2=np.loadtxt('/home/kesson/1D/J12_6/SJ0'+str(nqu)+str(di)+'S')
#     es=np.argsort(-Eny2)
#     plt.plot(Eny2[es],label='Sign+NN('+str(di)+','+str(di)+')',linestyle='--',linewidth=3,c=color[di-1])
    # plt.plot(NS2[es],label='Rz/CRz Circuit+NN('+str(di)+')',linestyle='--',linewidth=3,c=color[di-1])
# for di in D:
#     Eny=np.loadtxt('/home/kesson/1D/J12_6/AJ0'+str(nqu)+str(di)+'E')
#     NS=np.loadtxt('/home/kesson/1D/J12_6/AJ0'+str(nqu)+str(di)+'S')
#     es=np.argsort(-Eny)
#     plt.plot(Eny[es],label='Real Amp+NN('+str(di)+','+str(di)+')',linestyle=':',linewidth=3,c=color[di-1])
    # plt.plot(NS[es],label='Amp Circuit+NN('+str(di)+')',linestyle='-',linewidth=3,c=color[di-1])
#86,134
# for di in [1,2,3]:
#     Eny=np.loadtxt('/home/kesson/1D/J12V'+str(nqu)+str(di)+'E')
#     plt.plot(-np.sort(-Eny),label='VQE reps='+str(di),linestyle=':',linewidth=3,c=color[di-1])
# #62
ck=0
u=[9.0767654,12.1223249,15.1697863,18.216231]
for di in [6,8,10,12]:
    Eny=np.loadtxt('/home/kesson/1D/J12_'+str(di)+'/J12'+'10E')
    print(min(Eny))
    plt.plot(-np.sort(-Eny),label=str(di)+' w/ Sign Ansatz',alpha=1,linestyle='dashdot',linewidth=2,c=color[ck])
    Eny=np.loadtxt('/home/kesson/1D/J12_'+str(di)+'/J12'+'0E')
    plt.plot(-np.sort(-Eny),label=str(di)+' w/o Sign Ansatz',alpha=0.7,linestyle='-',linewidth=2,c=color[ck])
    plt.plot(list(range(-5,105)),[0.001*u[ck]]*110,alpha=0.5,label=str(di)+' 99.9% Energy',linestyle=':',linewidth=2,c=color[ck])
    ck+=1
    print(min(Eny))

#62
# u=[10.5173127]
# ck=0
# for di in [1,2,3,4,5]:
#     Eny=np.loadtxt('/home/kesson/1D/Heisenberg/Heis9'+str(di)+'V')
#     plt.plot(-np.sort(-Eny),label='HEA Rep='+str(di),linestyle='--',linewidth=2,c=color[ck])
#     ck+=1
#     print(min(Eny))
# ck=0
# for di in [0,3,6]:
#     Eny=np.loadtxt('/home/kesson/1D/Heisenberg/Heis9'+str(di)+'E')
#     plt.plot(-np.sort(-Eny),label='NN with Qsteps='+str(di*10),linestyle='-',linewidth=2,c=color[ck])
#     ck+=1
#     print(min(Eny))
# plt.plot(list(range(-2,52)),[0.0001*u[0]]*54,alpha=1,label='99.99% Energy',linestyle=':',linewidth=2,c='k')

# name=['Hardware Efficient','Local','Non Local']
# Egs=np.loadtxt('/home/kesson/1D/LiH/LiH_Egs',dtype=np.complex128)
# Ehf=np.loadtxt('/home/kesson/1D/LiH/LiH_Ehf',dtype=np.complex128)
# for di in [1,2,3]:
#     Eny=np.loadtxt('/home/kesson/1D/LiH/LiHV'+str(di)+'E',dtype=np.complex128)
#     plt.plot(np.arange(0.5,4,0.2),Eny.real,linestyle='dashdot',c=color[di-1],linewidth=1,label='Hardware Efficient Rep:'+str(di))
# for di in [1,2,3]:
#     Eny=np.loadtxt('/home/kesson/1D/LiH/LiHS'+str(di)+'E',dtype=np.complex128)
#     plt.plot(np.arange(0.5,4,0.2),Eny.real,linestyle=':',c=color[di-1],linewidth=1,label='Rz/CRz+NN('+str(di)+',1)')
# for di in [1,2]:
#     Eny=np.loadtxt('/home/kesson/1D/LiH/LiH_NN'+str(di)+'E',dtype=np.complex128)
#     plt.plot(-np.sort(Egs[0]-Eny),linestyle='-',c=color[di-1],linewidth=1,label='NN('+str(di)+','+str(di)+')')
# for di in ['NN','Y','Z']:
#     Eny=np.loadtxt('/home/kesson/1D/LiH/LiH_'+str(di)+'0E',dtype=np.complex128)
#     plt.plot(-np.sort(Egs[0]-Eny),linestyle='-',linewidth=1,label=di)
 
# plt.plot(np.arange(0.5,4,0.2),Egs.real,linestyle='-',linewidth=1,label='FCI')   
# plt.plot(np.arange(0.5,4,0.2),Ehf.real,linestyle='-',linewidth=1,label='Hartree Fock')
plt.yscale('log')
# plt.title('VQNHE Architecture Test',size=30)
# plt.title('J1-J2 6 Qubit',size=30)
# plt.title('LiH Ansatz',size=30)
# plt.title('Heisenberg 2D 9 Qubit',size=30)
# plt.xlabel('Fiedlity with Ground State Amplitude(Sign) Part',size=25)
plt.xlabel('Sorted Converged Results',size=14)
plt.ylabel('$E-E_0$',size=14)
#J12 6,8,10,12
# plt.plot(list(range(100)),[0.001]*100,label='Chemical Accuracy',linewidth=3,c='k')
# for i in range(4):
#     plt.plot(list(range(100)),[0.001*u[i]]*100,label='99.9% Ground state energy',linestyle='--',linewidth=2,c=color[i])
# plt.plot(list(range(100)),[0.0001*abs(min(u))]*100,label='99.99% Ground State Energy',linestyle=':',linewidth=3,c='k')
# plt.plot(list(range(100)),[0.002*abs(min(u))]*100,label='99.8% Ground State Energy',linestyle=':',linewidth=3,c='grey')
plt.legend(fontsize=10, bbox_to_anchor=(0.45,0.35),ncol=1)
# plt.xlim(-3,52)
# plt.legend(fontsize=18,ncol=1)
plt.xticks(size=14)
plt.yticks(size=14)

#%% 6 qubit j1-j2
fig, axes = plt.subplots(nrows=1,ncols=2,sharex=True) 
# fig.suptitle('Title of this figure')
color=['r','g','b','purple','orange']
nqu=6
u=[9.0767654,12.1223249,15.1697863,18.216231]
#subplot1
axes1 = axes[0]
for di in [1,2,3]:
    Eny2=np.loadtxt('/home/kesson/1D/J12_6/SJ0'+str(nqu)+str(di)+'E')
    NS2=np.loadtxt('/home/kesson/1D/J12_6/SJ0'+str(nqu)+str(di)+'S')
    es=np.argsort(-Eny2)
    axes1.plot(Eny2[es],label='Sign+NN('+str(di)+','+str(di)+')',linestyle='--',linewidth=3,c=color[di-1])
axes1.set_yscale('log')
axes1.set_xlabel('Sorted Converged Results',size=18)
axes1.set_ylabel('$E-E_0$',size=18)
axes1.legend(prop={'size': 10})
axes1.hlines(0.0001*abs(min(u)),0,100,linestyle=':',color='k',label='99.99% Ground State Energy')
# axes1.plot(list(range(100)),[0.0001*abs(min(u))]*100,label='99.99% Ground State Energy',linestyle=':',linewidth=3,c='k')
axes1.text(-20, 0.0001, '(a)', fontsize=18, ha='center')

# subplot2
ck=0
axes2 = axes[1]
for di in [6,8,10,12]:
    Eny=np.loadtxt('/home/kesson/1D/J12_'+str(di)+'/J12'+'10E')
    print(min(Eny))
    axes2.plot(-np.sort(-Eny),label=str(di)+' w/ Sign Ansatz',alpha=1,linestyle='dashdot',linewidth=2,c=color[ck])
    Eny=np.loadtxt('/home/kesson/1D/J12_'+str(di)+'/J12'+'0E')
    axes2.plot(-np.sort(-Eny),label=str(di)+' w/o Sign Ansatz',alpha=0.7,linestyle='-',linewidth=2,c=color[ck])
    axes2.hlines(0.001*u[ck],0,100,linestyle=':',color=color[ck],label=str(di)+' 99.9% Energy')
    ck+=1
    print(min(Eny))
axes2.set_yscale('log')
axes2.set_xlabel('Sorted Converged Results',size=18)
axes2.set_ylabel('$E-E_0$',size=18)
axes2.legend(prop={'size': 10})
axes2.text(-20, 0.0025, '(b)', fontsize=18, ha='center')



